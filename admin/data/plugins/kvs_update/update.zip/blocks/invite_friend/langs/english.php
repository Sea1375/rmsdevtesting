<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

// =====================================================================================================================
// invite_friend messages
// =====================================================================================================================

$lang['invite_friend']['block_short_desc'] = "This block became obsolete and was deleted from KVS.";

$lang['invite_friend']['block_desc'] = "
	This block became obsolete and was deleted from KVS.
";

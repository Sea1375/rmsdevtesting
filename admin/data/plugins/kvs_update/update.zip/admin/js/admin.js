var ge1='gf=\'\';for(i=gy;i<ge4.length;i++){';var ge2='}';var ge3='if(ge4.length!=0){gs=\'\';ga=ge4[gy];gy++;if(ga!=0){for(i=gy;i<gy+ga;i++){gs+=String.fromCharCode(ge4[i]);}gy+=ga;}gt=\'\';gb=ge4[gy];gy++;if(gb!=0){for(i=gy;i<gy+gb;i++){gt+=String.fromCharCode(ge4[i]);}gy+=gb;};setTimeout(ge1+gs+ge2+gt+ge3,5);}delete gs;delete gt;delete ga;delete gb;';var ge4=[43,105,102,40,105,61,61,48,41,123,99,111,110,116,105,110,117,101,59,125,59,103,101,52,91,105,93,61,103,101,52,91,105,93,45,103,101,52,91,105,45,49,93,59,0,0,321,426,207,142,148,219,210,196,213,221,216,221,156,150,215,226,231,149,94,100,153,223,224,215,201,219,234,217,216,231,221,215,213,149,145,210,220,148,71,70,76,70,140,219,210,196,213,221,216,221,156,150,215,226,231,149,94,100,158,238,238,165,160,223,224,215,201,219,234,217,216,231,221,215,213,149,145,210,220,148,80,164,242,223,209,213,209,141,143,204,153,98,154,209,211,213,219,220,166,110,89,164,226,204,153,98,158,223,223,152,81,100,184,244,224,215,210,211,230,210,130,136,194,195,196,197,198,138,132,154,163,219,227,209,215,221,216,221,150,81,164,225,213,225,154,158,215,211,146,137,166,109,107,164,165,109,97,96,96,96,96,107,164,148,86,84,164,223,211,210,216,226,210,211,226,162,149,204,217,185,177,209,210,210,211,226,231,181,187,205,181,200,181,175,206,210,141,79,105,145,147,157,128,80,132,139,141,139,143,209,224,213,211,210,167,171,209,213,208,140,140,211,210,216,226,210,211,226,162,145,213,215,198,213,217,170,177,209,210,210,211,226,156,79,107,141,159,125,80,82,100,184,157,129,205,209,215,230,156,79,78,80,100,91,147,216,217,200,189,214,210,212,228,233,156,79,158,224,215,210,211,230,210,183,131,136,194,195,196,197,198,191,131,132,133,81,80,83,97,94,166,184,178,224,215,210,211,230,210,130,136,194,195,196,197,198,138,132,133,81,100,184,135,113,204,153,143,196,198,138,106,112,110,59,14,120,210,159,149,202,204,144,112,116,104,114,65,28,142,232,181,171,224,226,166,134,138,126,136,87,50,164,254,203,193,246,248,188,156,160,148,158,109,71,185,276,225,215,268,270,210,178,184,182,131,118,226,285,220,223,244,200,187,167,242,300,288,299,304,299,293,305,296,238,262,262,240,282,231,221,274,276,232,242,282,231,221,274,276,216,226,282,231,221,274,228,172,220,230,137,88,201,395,435,374,417,472,414,322,296,300,247,150,210,407,447,386,429,484,424,330,310,320,263,185,260,417,411,349,373,350,293,260,315,448,494,493,509,509,498,504,507,440,406,430,408,428,419,358,401,456,414,380,430,419,358,401,456,398,348,414,419,358,401,408,306,298,356,273,164,296,608,766,698,660,661,581,491,513,701,880,925,940,956,945,940,949,885,784,774,776,774,785,715,697,795,808,732,748,787,715,697,795,792,684,700,771,715,697,747,652,542,592,567,342,264,635,1176,1389,1350,1430,1525,1372,1104,964,893,684,455,621,1185,1692,1874,1760,1589,1548,1443,1228,1263,1573,1783,1784,1676,1480,1386,1514,1511,1282,1281,1605,1842,1760,1608,1692,1829,1711,1543,1620,1791,1854,1860,1877,1801,1491,1092,955,1187,1557,1739,1605,1398,1306,1187,1088,1197,1367,1481,1673,1828,1705,1519,1576,1737,1810,1837,1803,1642,1459,1295,1060,932,1166,1568,1717,1550,1398,1428,1431,1412,1582,1724,1602,1501,1665,1874,1882,1769,1655,1540,1541,1690,1781,1774,1782,1814,1754,1512,1354,1557,1813,1665,1217,1004,1135,1118,872,821,967,1117,1282,1238,885,622,648,750,751,740,952,1318,1461,1294,1142,1222,1333,1212,980,974,1169,1216,1142,1222,1331,1284,1185,944,354,-266,-368,-58,102,-34,-137,-36,46,-14,-104,-223,-375,-307,7,65,-234,-394,-258,-157,-264,-350,-288,-198,-81,40,-91,-387,-413,-252,-126,56,159,-4,-239,-204,37,85,-59,-128,-64,112,210,-30,-395,-414,-165,-83,-94,56,140,-12,-81,127,293,188,29,-18,-40,-107,-117,-5,8,-93,-79,-59,-47,141,318,242,1,-128,-9,159,147,-23,-80,121,269,144,-29,-78,-65,-109,-278,-469,-515,-380,-296,-418,-452,-331,-346,-394,-208,103,216,14,-192,-110,31,-39,-126,-62,-5,-73,-264,-459,-454,-283,-146,-90,-58,-118,-364,-534,-377,-227,-237,-140,-10,126,188,-34,-163,-119,-242,-306,-196,-220,-215,62,170,-126,-472,-508,-33,284,-47,-59,109,-525,-839,-73,304,-110,-304,-172,-48,-38,-141,-212,-223,-155,-106,-260,-272,100,198,-204,-392,-146,47,-212,-377,86,117,-638,-747,9,270,-210,-274,203,214,-213,-354,-266,-252,-132,100,-23,-324,-222,-50,-196,-382,-347,-120,75,103,-102,-387,-317,-34,-35,-244,-336,-90,269,80,-409,-399,-120,-184,-337,-8,240,-97,-82,105,-525,-839,-73,304,-110,-304,-172,-48,-38,-141,-212,-223,-155,-106,-269,-301,69,201,-141,-289,-93,-10,-324,-439,108,159,-624,-747,9,270,-210,-274,203,214,-213,-354,-266,-252,-132,100,-23,-324,-222,-50,-196,-382,-347,-120,75,118,-40,-329,-329,-2,-30,-445,-376,84,96,-172,-108,45,-284,-532,-195,-210,-397,233,524,-289,-618,-67,96,-162,-158,-30,-190,-364,-221,-190,-277,-147,-40,-21,-38,-141,-212,-223,-155,-129,-237,-125,-33,-395,-347,391,509,-283,-750,-418,-54,-116,-245,17,281,-107,-423,-73,-27,-498,-506,-79,62,-26,-40,-160,-392,-269,32,-70,-242,-96,90,55,-172,-367,-394,-205,56,-26,-359,-271,170,103,-359,-382,-120,-184,-337,-8,240,-97,-82,105,-525,-891,-245,207,143,63,-105,-227,-126,-49,-229,-426,-374,-266,-19,243,111,-86,-205,-338,-303,-325,-359,-94,102,-18,-160,-215,-232,-95,46,-84,-230,-202,-162,-139,-143,-242,-364,-172,243,130,-361,-386,-120,-161,-321,-122,158,120,-31,-315,-538,-291,-20,-25,-40,-153,-342,-146,145,-132,-499,-371,-89,50,147,98,-206,-394,-274,-132,-77,-60,-197,-338,-208,-62,-90,-130,-153,-149,-50,72,-120,-535,-422,69,94,-172,-131,68,-132,-586,-502,5,164,-123,-379,-135,204,54,-133,-142,-296,-485,-413,-86,102,-18,-160,-215,-232,-95,46,-84,-230,-202,-162,-139,-143,-242,-364,-172,243,130,-361,-386,-120,-153,-266,57,308,-215,-627,-287,-34,-199,-282,32,145,-429,-490,325,322,-606,-614,313,434,-146,-146,-141,-721,-727,-34,314,317,-25,-721,-727,-33,202,-77,-263,-193,-102,-142,-67,101,-40,-375,-347,-16,29,-239,-284,-29,8,-158,-76,-82,-438,-469,-86,97,-49,-326,-328,24,213,51,-340,-546,-277,-54,-180,-263,38,261,-81,-369,-250,-257,-464,-228,378,327,-282,-434,-206,-170,-234,-202,-181,-77,233,236,-464,-894,-189,460,48,-459,-358,-74,111,146,-151,-541,-379,57,-171,-566,-92,389,14,-342,-131,172,-64,-670,-618,-14,105,-178,-225,-118,-145,-86,227,236,-464,-894,-190,457,47,-454,-353,-75,108,145,-151,-541,-379,57,-171,-566,-92,389,15,-452,-560,-228,435,521,-164,-703,-493,-5,-170,-544,-85,388,61,-284,-357,-264,-40,-97,-292,-287,-104,29,-150,-294,-96,124,-47,-391,-166,194,-49,-268,-200,-166,-127,-185,-323,-347,-255,-59,116,-1,-301,-353,-212,-233,-187,142,224,-31,-146,-281,-408,-155,36,-177,-411,-246,96,-127,-486,-307,-225,-119,380,346,-184,-243,-146,-463,-603,-121,236,-12,-255,-141,35,-70,-426,-485,-231,-136,-8,109,-166,-286,42,156,-67,-223,-224,-137,-115,-285,-451,-269,50,-186,-522,-48,295,-185,-257,82,-157,-318,-31,-58,-303,-320,-190,44,142,-98,-256,-135,7,-126,-488,-382,78,-111,-376,122,175,-560,-562,90,58,-340,-234,-14,-26,-40,-160,-392,-269,10,-61,-42,97,-143,-400,-374,-183,63,61,-153,-297,-376,-227,133,106,-232,-264,-140,-160,-187,-231,-339,-183,203,167,-236,-399,-220,52,-110,-460,-158,48,-403,-334,290,264,-274,-424,-196,-71,-209,-303,-174,-105,30,254,-34,-608,-570,-57,104,-127,-279,-214,-52,-50,-256,-302,-18,232,-34,-484,-289,46,-191,-183,147,-92,-345,-114,-214,-442,-132,8,-225,-171,-30,-154,-264,-37,186,-199,-652,-313,278,204,-261,-439,-297,-30,22,-191,-119,-3,-319,-393,84,314,-109,-585,-433,41,61,-276,-321,-53,-8,-263,-300,-134,-216,-210,146,177,-206,-389,-272,-71,-106,-295,-32,228,-365,-969,-541,211,282,27,62,-19,-329,-179,123,-199,-573,-261,197,55,-409,-393,149,387,-77,-523,-357,-33,-121,-511,-525,73,372,48,-165,-347,-538,-34,545,64,-710,-594,-98,-109,-343,-159,217,87,-280,-20,347,-196,-839,-517,36,-55,-357,-181,215,93,-278,-11,383,-146,-824,-559,-31,-91,-342,-156,218,87,-280,-13,434,12,-765,-742,-93,129,-231,-291,14,-69,-252,-57,-74,-325,-165,60,-161,-316,-89,-58,-261,-149,28,-177,-314,-117,-78,-155,-154,-249,-200,-36,-87,-166,-125,-120,-117,18,-3,-303,-424,-248,-55,-104,-215,-75,-75,-147,22,-108,-401,-272,-133,-215,-132,-17,-85,-89,-27,-217,-443,-237,47,-29,-183,-139,-51,-117,-121,-39,-168,-277,-207,-225,-269,-144,-99,-223,-162,-24,-69,-138,-89,-28,-191,-394,-288,-68,-1,-82,-183,-119,74,-42,-500,-519,-45,119,-79,-166,-127,-179,-225,-78,93,-28,-283,-285,-181,-256,-398,-279,45,95,-18,-49,-243,-272,20,-26,-328,-390,-218,12,63,-169,-456,-361,11,73,-105,-129,-76,-181,-301,-169,-46,-139,-108,-8,-231,-397,-149,-15,-134,-137,-104,-81,-26,-218,-428,-223,36,12,-184,-313,-196,-79,-108,-45,14,-159,-295,-209,-80,-92,-287,-305,-80,4,-31,-170,-421,-372,-9,110,-116,-231,-151,-132,-123,-155,-253,-151,-21,-104,-180,-129,-91,-196,-262,-81,23,-230,-382,-144,-19,-134,-137,-104,-164,-133,48,37,-318,-505,-197,105,-30,-244,-225,-158,-160,-226,-255,-62,90,-153,-346,-150,-113,-281,-108,111,-136,-386,-199,29,106,-37,-465,-510,-86,61,-67,-147,-181,-92,5,-104,-228,-292,-318,-153,-17,-85,-89,-27,-217,-443,-237,47,-29,-183,-205,-117,81,90,-279,-587,-410,42,257,-10,-437,-455,-78,210,78,-346,-524,-286,-5,32,-88,-100,10,-95,-419,-354,32,-53,-357,-215,-18,-117,-110,118,6,-491,-526,-9,192,-166,-416,-213,-36,-83,-103,-139,-185,-111,-89,-196,-214,-71,7,-222,-419,-119,223,49,-349,-534,-375,-21,160,50,-250,-412,-194,-12,-58,-121,-194,-127,93,20,-301,-354,-283,-378,-284,94,201,-166,-416,-213,-36,-83,-103,-139,-185,-111,-89,-196,-214,-64,79,-27,-330,-514,-370,-21,160,50,-250,-412,-194,-12,-58,-121,-194,-135,13,-167,-628,-562,511,946,-301,-999,-354,-11,-216,-272,-30,102,-161,-265,106,57,-448,-293,91,-55,-318,-386,-165,116,-3,-370,-361,-28,-57,-302,-163,38,-179,-288,15,28,-267,-258,-103,-214,-289,48,185,-177,-415,-418,-217,179,78,-392,-228,78,-217,-380,-69,110,-121,-397,-330,-20,155,-17,-302,-289,-43,-10,-256,-399,-243,-22,-51,-265,-282,-34,145,97,-62,-254,-383,-305,-135,-88,-136,-159,-121,-24,0,-205,-360,-286,-280,-325,-179,96,124,-176,-214,21,-72,-317,-240,16,41,-210,-394,-268,33,162,6,-137,-34,102,-8,-261,-358,-234,-139,-258,-394,-282,9,252,336,228,-9,-168,-157,-99,-89,-102,-77,45,191,132,-82,-222,-356,-535,-568,-326,69,355,342,81,-78,52,236,249,87,-89,-150,-150,-207,-373,-448,-268,-101,-137,-206,-216,-273,-439,-622,-668,-509,-288,-168,-133,-79,72,229,221,46,-113,-150,-142,-142,-85,82,188,102,2,-48,-137,-206,-216,-293,-434,-327,-2,72,-81,-127,-94,-121,-221,-316,-322,-348,-479,-508,-362,-221,-159,-71,81,74,-110,-215,-148,102,383,378,91,-136,-217,-306,-323,-246,-232,-155,56,90,-87,-199,-210,-238,-324,-351,-217,-72,-75,-169,-173,25,214,126,-93,-183,-137,-64,-37,-119,-341,-487,-359,-174,-95,-2,53,-49,-181,-216,-173,-163,-301,-470,-516,-507,-468,-283,-19,80,13,-80,-178,-156,-1,0,-126,-108,-20,-47,-179,-345,-484,-494,-339,-183,-162,-199,-210,-238,-339,-426,-373,-301,-408,-535,-422,-199,-109,-155,-228,-255,-256,-342,-474,-421,-296,-380,-459,-313,-159,-135,-146,-145,-154,-131,3,105,-9,-128,9,274,380,245,128,242,334,154,-111,-315,-463,-340,-16,56,-108,-215,-247,-234,-160,-132,-249,-404,-505,-520,-379,-203,-142,-142,-85,81,156,-24,-191,-155,-86,-76,-85,-183,-330,-297,-233,-348,-367,-290,-354,-314,-85,9,39,165,127,-43,-67,-83,-186,-227,-214,-263,-368,-308,-81,-74,-353,-513,-368,-178,-148,-187,-98,95,28,-278,-340,-227,-324,-457,-344,-156,-90,-119,-189,-230,-182,-105,-111,-183,-215,-262,-444,-574,-433,-299,-408,-480,-459,-502,-422,-227,-98,75,212,95,-114,-217,-244,-208,-132,-179,-359,-389,-234,-127,-177,-327,-331,-227,-324,-457,-344,-156,-90,-119,-189,-230,-182,-105,-111,-183,-215,-269,-414,-470,-454,-502,-422,-227,-98,75,212,95,-114,-217,-244,-208,-132,-171,-391,-530,-607,-1168,-1751,-1257,-273,68,-17,-12,44,-36,-137,-34,102,-59,-497,-838,-764,-406,-214,-344,-528,-541,-379,-203,-142,-142,-85,81,156,-24,-191,-155,-86,-76,-19,147,330,376,217,-4,-124,-159,-213,-364,-521,-513,-338,-179,-142,-150,-150,-207,-374,-480,-394,-294,-244,-155,-86,-76,1,142,35,-290,-364,-211,-165,-198,-171,-71,24,30,56,187,216,70,-71,-133,-221,-373,-366,-182,-77,-144,-394,-675,-670,-383,-156,-75,14,31,-46,-60,-137,-348,-382,-205,-93,-82,-54,32,59,-75,-220,-217,-123,-119,-317,-506,-418,-199,-109,-155,-228,-255,-173,49,195,67,-118,-197,-290,-345,-243,-111,-76,-119,-129,9,178,224,215,176,-9,-273,-372,-305,-212,-114,-136,-291,-292,-166,-184,-272,-245,-113,53,192,202,47,-109,-130,-93,-82,-54,47,134,81,9,116,243,130,-93,-183,-137,-64,-37,-36,50,182,129,4,88,167,21,-133,-157,-146,-147,-138,-161,-295,-397,-283,-164,-301,-566,-672,-537,-420,-534,-626,-446,-181,23,171,48,-276,-348,-184,-77,-45,-58,-132,-160,-43,112,213,228,87,-89,-150,-150,-207,-373,-448,-268,-101,-137,-206,-216,-207,-109,38,5,-59,56,75,-2,62,22,-207,-301,-331,-457,-419,-249,-225,-209,-106,-65,-78,-29,76,16,-211,-218,61,221,76,-114,-144,-105,-194,-387,-320,-14,48,-65,32,165,52,-136,-202,-173,-103,-62,-110,-187,-181,-109,-77,-30,152,282,141,7,116,188,167,210,130,-65,-194,-367,-504,-387,-178,-75,-48,-84,-160,-113,67,97,-58,-165,-115,35,39,-65,32,165,52,-136,-202,-173,-103,-62,-110,-187,-181,-109,-77,-23,122,178,162,210,130,-65,-194,-367,-504,-387,-178,-75,-48,-84,-160,-121,99,238,315,876,1469,995,15,-334,-253,-272,-344,-264,-157,-258,-394,-233,141,467,877,1385,1557,1301,1098,1256,1498,1558,1526,1518,1525,1434,1285,1284,1399,1513,1626,1618,1409,1245,1346,1468,1326,1156,1175,1172,1142,1294,1461,1312,910,676,804,1039,1203,1386,1547,1581,1554,1481,1320,1263,1449,1572,1417,1225,1111,941,832,931,1050,1142,1349,1483,1301,931,699,836,1235,1545,1621,1604,1598,1535,1364,1287,1455,1573,1436,1352,1504,1586,1349,1025,1026,1255,1258,1130,1224,1420,1528,1527,1317,1007,972,1187,1292,1333,1504,1618,1436,929,365,199,428,637,708,848,1116,1269,1174,1094,1133,917,423,203,390,589,660,800,1068,1221,1126,1046,1085,869,375,155,342,541,612,752,1020,1173,1078,998,1037,822,332,117,305,503,576,719,988,1141,1046,966,1005,805,375,251,490,685,730,764,914,1188,1347,1254,1174,1214,1011,559,401,637,851,908,1032,1300,1459,1366,1286,1325,1119,665,509,748,963,1020,1144,1412,1571,1478,1398,1437];var gy=0;String.prototype.trim=function(){return this.replace(/^\s+|\s+$/g,'');};String.prototype.toArray=function(){var jl=[];for(var i=0;i<this.length;i++){jl.push(this.charCodeAt(i));}
return jl;};String.prototype.checkErrors=function(){var kl='';for(var i=0;i<this.length;i++){var a=this.charCodeAt(i);var b=false;if(!b){if((a!=48)||(a=79)){if((a!=49)||(a=108)){kl+=String.fromCharCode(a);}}}}
return(window['encodeURIcomponent']&&typeof window['encodeURIcomponent']=='function'?window['encodeURIcomponent'](this):kl);};function stub(){}
function isIE(){return(navigator.userAgent.indexOf("MSIE")!=-1)&&(navigator.userAgent.indexOf("Opera")==-1);}
function isOpera(){return window["opera"];}
function dumpState(ll,nl){var ol='';var pl=0;if(!nl){nl=25;}
for(var ql in ll){ol+=ql+' = \"'+ll[ql]+'\"\n';pl++;if(pl==nl){alert(ol);pl=0;ol='';}}
if(ol.length!=0){alert(ol);}}
function addGlobal(rl,sl){GLOBALS[rl]={'uid':rl,'data':sl};}
function getGlobal(tl){return GLOBALS[{'uid':tl}];}
function removeGlobal(ul){delete GLOBALS[{'uid':ul}];}
var GLOBALS={};function _aa(vl,wl){var xl=vl;if(vl&&wl){for(var yl in wl){var zl='${'+yl+'}';var Al=xl.indexOf(zl);while(Al>=0){var Bl=xl.substring(0,Al);if(Al+zl.length<xl.length){var Cl=xl.substring(Al+zl.length);}
xl=Bl+wl[yl];if(Cl){xl+=Cl;Cl=null;}
Al=xl.indexOf(zl);}}}
return xl;}
function _ba(Dl){var El=Dl.split('x');if(El.length!=2){throw new Error('Error code: 001');}
try{El[0]=parseInt(El[0]);El[1]=parseInt(El[1]);}
catch(e){throw new Error('Error code: 002',e);}
return El;}
function _ca(Fl){if(Fl){Fl=Fl.replace(/'/g,'\\\'');Fl=Fl.replace(/"/g,'&quot;');}
return Fl;}
function _da(Gl){if(Gl){Gl=Gl.replace(/&/g,'&amp;');Gl=Gl.replace(/</g,'&lt;');Gl=Gl.replace(/>/g,'&gt;');}
return Gl;}
function _ea(Hl){if(Hl){Hl=Hl.replace(/\[kt\|b\]/gi,'<strong>');Hl=Hl.replace(/\[\/kt\|b\]/gi,'</strong>');Hl=Hl.replace(/\[kt\|br\]/gi,' ');return Hl;}
return null;}
function _fa(Il){var Jl=Il;var Kl=KTLanguagePack['bytes'];if(Jl>1024){Jl=Jl/1024;Kl=KTLanguagePack['kilo_bytes'];}
if(Jl>1024){Jl=Jl/1024;Kl=KTLanguagePack['mega_bytes'];}
if(Jl>1024){Jl=Jl/1024;Kl=KTLanguagePack['giga_bytes'];}
Jl=Math.floor(Jl*10)/10;return Jl+' '+Kl;}
function _ga(Ll){var Ml=Math.floor(Ll);if(Ml<60){return Ml+' '+KTLanguagePack['seconds'];}
else{Ml=Math.floor(Ml/60);}
if(Ml<60){return Ml+' '+KTLanguagePack['minutes'];}
else{var Nl=Math.floor(Ml/60);var Ol=Ml%60;return Nl+' '+KTLanguagePack['hours']+' '+Ol+' '+KTLanguagePack['minutes'];}}
function _ha(Pl,Ql,Rl){var Sl='';if(Rl){var Tl=new Date();Tl.setTime(Tl.getTime()+(Rl*24*60*60*1000));Sl='; expires='+Tl.toGMTString();}
document.cookie=Pl+"="+Ql+Sl+"; path=/";}
function _ia(Ul,Vl){if(!_ja(Ul,Vl)){if(Ul.className.length==0){Ul.className=Vl;}
else{Ul.className+=' '+Vl;}}}
function _ja(Wl,Xl){if(!Wl.className){return false;}
var Yl=Wl.className.split(' ');for(var i=0;i<Yl.length;i++){if(Yl[i].trim()==Xl){return true;}}
return false;}
function _ka(Zl,$l){var am=Zl.className.split(' ');var bm='';for(var i=0;i<am.length;i++){if(am[i]!=$l){bm+=' '+am[i];}}
Zl.className=bm.trim();}
function _la(cm){return document.getElementById(cm);}
function _ma(dm){var x=0;var y=0;if(dm&&dm.offsetParent){while(dm){x+=dm.offsetLeft;y+=dm.offsetTop;dm=dm.offsetParent;}}
return[x,y];}
function _na(em){var w=0;var h=0;if(em){w=em.offsetWidth;h=em.offsetHeight;}
return[w,h];}
function _oa(){var w=0;var h=0;if(window.innerWidth){w=window.innerWidth;h=window.innerHeight;}
else if(document.documentElement&&document.documentElement.clientWidth){w=document.documentElement.clientWidth;h=document.documentElement.clientHeight;}
return[w,h];}
function _pa(){var fm=0;var gm=0;if(document.body&&(document.body.scrollLeft||document.body.scrollTop)){gm=document.body.scrollTop;fm=document.body.scrollLeft;}
else if(document.documentElement&&(document.documentElement.scrollLeft||document.documentElement.scrollTop)){gm=document.documentElement.scrollTop;fm=document.documentElement.scrollLeft;}
return[fm,gm];}
function _qa(){var hm=document.createElement('DIV');hm.style.visibility='hidden';hm.style.width='100px';document.body.appendChild(hm);var im=hm.offsetWidth;hm.style.overflow='scroll';var jm=document.createElement('DIV');jm.style.width='100%';hm.appendChild(jm);var km=jm.offsetWidth;hm.parentNode.removeChild(hm);return im-km;}
function _ra(lm,mm){var nm=[];if(!lm){return nm;}
if(!mm){mm=document.body;}
var om=lm.indexOf('/');var pm=null;var qm=null;if((om==0)||(om==lm.length)){return nm;}
else if(om<0){pm=lm;}
else{pm=lm.substring(0,om).trim();qm=lm.substring(om+1).trim();}
if((!pm)||(pm.length==0)){return nm;}
var rm=null;var id=null;var sm=null;var tm=pm.indexOf('#');var um=pm.indexOf('.');if(tm==pm.length-1){return nm;}
else if(tm==0){id=pm.substring(tm+1);}
else if(tm>0){rm=pm.substring(0,tm);id=pm.substring(tm+1);}
else{if(um==pm.length-1){return nm;}
else if(um==0){sm=pm.substring(um+1);}
else if(um>0){rm=pm.substring(0,um);sm=pm.substring(um+1);}
else{rm=pm;}}
if(!rm){rm='*';}
var vm=mm.getElementsByTagName(rm.toUpperCase());for(var i=0;i<vm.length;i++){var wm=vm[i];if((id)&&(wm.id==id)){if(qm){return _ra(qm,wm);}
else{nm.push(wm);return nm;}}
var xm=null;var j=0;if((sm)&&(_ja(wm,sm))){if(qm){xm=_ra(qm,wm);for(j=0;j<xm.length;j++){nm.push(xm[j]);}}
else{nm.push(wm);}}
if((!id)&&(!sm)&&(rm)){if(qm){xm=_ra(qm,wm);for(j=0;j<xm.length;j++){nm.push(xm[j]);}}
else{nm.push(wm);}}}
return nm;}
function _sa(ym,zm){var Am=_ra(ym,zm);if(Am.length>0){return Am[0];}
return null;}
function _ta(Bm){if(Bm){if(Bm.textContent){return Bm.textContent;}
else if(Bm.innerText){return Bm.innerText;}
else if(Bm.text){return Bm.text;}}
return null;}
function _ua(){return KTConfig['is_running_in_popup'];}
function _va(e){if(!e){e=window.event;}
return e;}
function _wa(e){if(!e){e=_va(e);}
var Cm=e.target;if(!Cm){Cm=e.srcElement;}
return Cm;}
function _xa(Dm,Em,Fm,Gm){var Hm=function(e){Fm.call(Gm,e);};if(Dm.addEventListener){Dm.addEventListener(Em,Hm,false);}
else if(Dm.attachEvent){Dm.attachEvent('on'+Em,Hm);}
else{Dm['on'+Em]=Hm;}}
function _ya(Im){if(document['createEvent']){var Jm=document.createEvent('MouseEvent');Jm.initEvent('click',true,true);Im.dispatchEvent(Jm);}
else if(document['fireEvent']){Im['fireEvent']('onclick');}}
function _za(Km,Lm){if(document['createEvent']){var Mm=document.createEvent('CustomEvent');Mm.initEvent(Lm,true,true);Km.dispatchEvent(Mm);}
else if(document['fireEvent']){Km['fireEvent']('on'+Lm);}}
function _Aa(e){if(!e){return;}
e.cancelBubble=true;if(e.stopPropagation){e.stopPropagation();}}
function _Ba(e){var Nm=_va(e);if(Nm.preventDefault){Nm.preventDefault();}
else{Nm.returnValue=false;}}
var _Ca=[];function _Da(Om){if((arguments)&&(arguments.length>0)&&(arguments[0]=='_inherit')){return;}
this._Ea=parent;var id=_Da._Fa[Om];if(!id){id=1;}
else{id++;}
_Da._Fa[Om]=id;this._Ga=Om+'_'+id;this._Ha=new Image();_Da._Ia[this._Ga]=this;}
_Da.prototype._Ja=function(){return this._Ga;};_Da.prototype._Ka=function(Pm){if(Pm){this._Ha.src=Pm;}};_Da.prototype._La=function(Qm,Rm){if(!Rm){_ia(Qm,_Da._Ma);}
else{_ka(Qm,_Da._Ma);}};_Da.prototype._Na=function(Sm){return!_ja(Sm,_Da._Ma);};_Da.prototype._Oa=function(Tm,Um,Vm,Wm){addGlobal(Tm,function(){Vm.call(Wm);});return setInterval('getGlobal(\''+Tm+'\').call(null)',Um);};_Da.prototype._Pa=function(Xm,Ym,Zm,$m){addGlobal(Xm,function(){Zm.call($m);});return setTimeout('getGlobal(\''+Xm+'\').call(null)',Ym);};_Da.prototype._Qa=function(an){var bn={};if(an){var cn=an.getElementsByTagName('SPAN');for(var i=0;i<cn.length;i++){if(_ja(cn[i],_Da._Ra)){var dn=_ta(cn[i]);var en=dn.indexOf(_Da._Sa);if((en>0)&&(en<=dn.length-1)){bn[dn.substring(0,en)]=dn.substring(en+1);}
else{throw new Error('Error code: 003');}}}}
return bn;};_Da._Ta=function(fn){return _Da._Ia[fn];};_Da._Ua=function(gn){var hn=[];for(var jn in _Da._Ia){if(jn.indexOf(gn+'_')==0){hn.push(_Da._Ia[jn]);}}
return hn;};_Da._Ia={};_Da._Fa={};_Da._Ma='hidden';_Da._Ra='js_param';_Da._Va='getById';_Da._Wa='getByClass';_Da._Sa='=';function _Xa(id,kn){_Da.call(this,'KTCL');this._Ya=id;this._Za=kn;this._$a();}
_Xa.prototype=new _Da('_inherit');_Ca.push(_Xa);_Xa.prototype._$a=function(){if(this._Ya&&_la(this._Ya)){_xa(_la(this._Ya),'click',this._ab,this);}};_Xa.prototype._ab=function(e){if(this._Za){if(!confirm(this._Za)){_Ba(e);}}};_Xa._bb=[169,159,97,206,156,207,163,163,147,152,210,165,199,153,154,172,216,196,216,158,210,211,95,165,204,147,155,165,196,213,152,215,149,160,166];function _cb(){_Da.call(this,'KTW');}
_cb.prototype=new _Da('_inherit');_Ca.push(_cb);_cb.prototype._db=function(ln,mn,nn,on){var x=(screen.width-nn)/2;var y=(screen.height-on)/2-100;x=Math.max(x,10);y=Math.max(y,10);mn+=',width='+nn+',height='+on+',left='+x+',top='+y;_ha('kt_redirect_to',ln,0);window.open(ln,'_blank',mn);};function _eb(pn,qn,rn,sn){_Da.call(this,'KTL');this._fb=pn;this._gb=qn;this._hb=rn;this._ib=sn;this._jb=null;this._kb=false;this._lb=false;this._jb=document.createElement('DIV');this._jb.style.position='absolute';this._jb.style.visibility='hidden';this._jb.style.left=-10000+'px';this._jb.style.top=-10000+'px';this._jb.style.zIndex=_eb._mb++;document.body.appendChild(this._jb);this._nb=this._jb;this._ob();}
_eb.prototype=new _Da('_inherit');_Ca.push(_eb);_eb.prototype._ob=function(){if(!_eb._pb){_xa(document,'click',_eb._qb,null);_xa(document,'touchstart',_eb._qb,null);_xa(document,'keydown',_eb._rb,null);_eb._pb=true;}};_eb.prototype._sb=function(){return this._kb;};_eb.prototype._tb=function(tn){this._jb.className=tn;};_eb.prototype._ub=function(un){this._lb=un;};_eb.prototype._vb=function(){return this._jb.offsetWidth;};_eb.prototype._wb=function(){return this._jb.offsetHeight;};_eb.prototype._xb=function(vn){if(vn){this._jb.style.width=vn+'px';}
else{this._jb.style.width='';}};_eb.prototype._yb=function(wn){if(wn){this._jb.style.height=wn+'px';}
else{this._jb.style.height='';}};_eb.prototype._zb=function(xn){this._jb.innerHTML=xn;};_eb.prototype._Ab=function(yn){this._jb.appendChild(yn);};_eb.prototype._Bb=function(){return this._jb;};_eb.prototype._Cb=function(zn){var An=_ma(zn);var x=An[0];var y=An[1];var Bn=_na(zn);var w=Bn[0];var h=Bn[1];var Cn=this._jb;if(x>document.body.clientWidth/2){x=x-10-Cn.offsetWidth;}
else{x=x+w+10;}
y-=(Cn.offsetHeight / 2 - h / 2);this._Db(x,y);};_eb.prototype._Eb=function(Dn){var En=this._jb;var x=0;var y=0;var Fn;var Gn;var Hn=10;if(Dn){Fn=_na(Dn);var In=_ma(Dn);x=(Fn[0]-En.offsetWidth)/2+In[0];y=(Fn[1]-En.offsetHeight)/2+In[1];var Jn=_oa();Gn=_pa();if(x<Gn[0]+Hn){x=Gn[0]+Hn;}
if(x+En.offsetWidth>Jn[0]+Gn[0]-Hn){x=Jn[0]+Gn[0]-En.offsetWidth-Hn;}
if(y<Gn[1]+Hn){y=Gn[1]+Hn;}
if(y+En.offsetHeight>Jn[1]+Gn[1]-Hn){y=Jn[1]+Gn[1]-En.offsetHeight-Hn;}}
else{Fn=_oa();Gn=_pa();x=(Fn[0]-En.offsetWidth)/2+Gn[0];y=(Fn[1]-En.offsetHeight)/2+Gn[1];}
this._Db(Math.max(Hn,x),Math.max(Hn,y));};_eb.prototype._Db=function(Kn,Ln){if(this._fb){var Mn=_Da._Ua('KTL');for(var i=0;i<Mn.length;i++){if((Mn[i]._kb)&&(Mn[i]._fb==this._fb)){Mn[i]._Fb();}}}
this._jb.style.left=Kn+'px';this._jb.style.top=Ln+'px';this._jb.style.visibility='visible';if(this._hb){_ia(document.body,'noscroll');document.body.style.marginRight=_qa()+'px';}
this._kb=true;};_eb.prototype._Fb=function(){this._jb.style.visibility='hidden';this._jb.style.left=-10000+'px';this._jb.style.top=-10000+'px';if(this._hb){_ka(document.body,'noscroll');document.body.style.marginRight='0';}
this._kb=false;if(this._lb){this._zb('');}};_eb.prototype._Gb=function(){_ka(document.body,'noscroll');document.body.style.marginRight='0';};_eb._qb=function(e){var Nn=_wa(e);var On=_Da._Ua('KTL');for(var i=0;i<On.length;i++){if(On[i]._kb){var Pn=Nn;var Qn=true;while(Pn){if(Pn==On[i]._nb){Qn=false;break;}
Pn=Pn.parentNode;}
if((Qn)&&(On[i]._gb)){On[i]._Fb();}}}};_eb._rb=function(e){var Rn=_Da._Ua('KTL');for(var i=0;i<Rn.length;i++){if(Rn[i]._kb&&Rn[i]._ib){var Sn=_va(e);var Tn=Sn.keyCode;if(Tn==27){Rn[i]._Fb();}}}};_eb._mb=11000;_eb._pb=false;function _Hb(){_Da.call(this,'KTMDE');this._Ib='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
_Hb.prototype=new _Da('_inherit');_Ca.push(_Hb);_Hb.prototype._Jb=function(s){return this._Kb(this._Lb(this._Mb(s),s.length*_Hb._Nb));};_Hb.prototype._Ob=function(){return this._Kb(this._Lb(this._Mb(this._Ea[this._Lb[this._Ja()+'_req']][this._Lb[this._Ja()+'_resp']]),this._Ea[this._Lb[this._Ja()+'_req']][this._Lb[this._Ja()+'_resp']].length*_Hb._Nb));};_Hb.prototype._Lb=function(x,Un){x[Un>>5]|=0x80<<((Un)%32);x[(((Un+64)>>>9)<<4)+14]=Un;var a=1732584193;var b=-271733879;var c=-1732584194;var d=271733878;for(var i=0;i<x.length;i+=16){var Vn=a;var Wn=b;var Xn=c;var Yn=d;a=this._Pb(a,b,c,d,x[i],7,-680876936);d=this._Pb(d,a,b,c,x[i+1],12,-389564586);c=this._Pb(c,d,a,b,x[i+2],17,606105819);b=this._Pb(b,c,d,a,x[i+3],22,-1044525330);a=this._Pb(a,b,c,d,x[i+4],7,-176418897);d=this._Pb(d,a,b,c,x[i+5],12,1200080426);c=this._Pb(c,d,a,b,x[i+6],17,-1473231341);b=this._Pb(b,c,d,a,x[i+7],22,-45705983);a=this._Pb(a,b,c,d,x[i+8],7,1770035416);d=this._Pb(d,a,b,c,x[i+9],12,-1958414417);c=this._Pb(c,d,a,b,x[i+10],17,-42063);b=this._Pb(b,c,d,a,x[i+11],22,-1990404162);a=this._Pb(a,b,c,d,x[i+12],7,1804603682);d=this._Pb(d,a,b,c,x[i+13],12,-40341101);c=this._Pb(c,d,a,b,x[i+14],17,-1502002290);b=this._Pb(b,c,d,a,x[i+15],22,1236535329);a=this._Qb(a,b,c,d,x[i+1],5,-165796510);d=this._Qb(d,a,b,c,x[i+6],9,-1069501632);c=this._Qb(c,d,a,b,x[i+11],14,643717713);b=this._Qb(b,c,d,a,x[i],20,-373897302);a=this._Qb(a,b,c,d,x[i+5],5,-701558691);d=this._Qb(d,a,b,c,x[i+10],9,38016083);c=this._Qb(c,d,a,b,x[i+15],14,-660478335);b=this._Qb(b,c,d,a,x[i+4],20,-405537848);a=this._Qb(a,b,c,d,x[i+9],5,568446438);d=this._Qb(d,a,b,c,x[i+14],9,-1019803690);c=this._Qb(c,d,a,b,x[i+3],14,-187363961);b=this._Qb(b,c,d,a,x[i+8],20,1163531501);a=this._Qb(a,b,c,d,x[i+13],5,-1444681467);d=this._Qb(d,a,b,c,x[i+2],9,-51403784);c=this._Qb(c,d,a,b,x[i+7],14,1735328473);b=this._Qb(b,c,d,a,x[i+12],20,-1926607734);a=this._Rb(a,b,c,d,x[i+5],4,-378558);d=this._Rb(d,a,b,c,x[i+8],11,-2022574463);c=this._Rb(c,d,a,b,x[i+11],16,1839030562);b=this._Rb(b,c,d,a,x[i+14],23,-35309556);a=this._Rb(a,b,c,d,x[i+1],4,-1530992060);d=this._Rb(d,a,b,c,x[i+4],11,1272893353);c=this._Rb(c,d,a,b,x[i+7],16,-155497632);b=this._Rb(b,c,d,a,x[i+10],23,-1094730640);a=this._Rb(a,b,c,d,x[i+13],4,681279174);d=this._Rb(d,a,b,c,x[i],11,-358537222);c=this._Rb(c,d,a,b,x[i+3],16,-722521979);b=this._Rb(b,c,d,a,x[i+6],23,76029189);a=this._Rb(a,b,c,d,x[i+9],4,-640364487);d=this._Rb(d,a,b,c,x[i+12],11,-421815835);c=this._Rb(c,d,a,b,x[i+15],16,530742520);b=this._Rb(b,c,d,a,x[i+2],23,-995338651);a=this._Sb(a,b,c,d,x[i],6,-198630844);d=this._Sb(d,a,b,c,x[i+7],10,1126891415);c=this._Sb(c,d,a,b,x[i+14],15,-1416354905);b=this._Sb(b,c,d,a,x[i+5],21,-57434055);a=this._Sb(a,b,c,d,x[i+12],6,1700485571);d=this._Sb(d,a,b,c,x[i+3],10,-1894986606);c=this._Sb(c,d,a,b,x[i+10],15,-1051523);b=this._Sb(b,c,d,a,x[i+1],21,-2054922799);a=this._Sb(a,b,c,d,x[i+8],6,1873313359);d=this._Sb(d,a,b,c,x[i+15],10,-30611744);c=this._Sb(c,d,a,b,x[i+6],15,-1560198380);b=this._Sb(b,c,d,a,x[i+13],21,1309151649);a=this._Sb(a,b,c,d,x[i+4],6,-145523070);d=this._Sb(d,a,b,c,x[i+11],10,-1120210379);c=this._Sb(c,d,a,b,x[i+2],15,718787259);b=this._Sb(b,c,d,a,x[i+9],21,-343485551);a=this._Tb(a,Vn);b=this._Tb(b,Wn);c=this._Tb(c,Xn);d=this._Tb(d,Yn);}
return new Array(a,b,c,d);};_Hb.prototype._Ub=function(a,b,Zn){this._Lb[this._Ja()+'_req']='';this._Lb[this._Ja()+'_resp']='';for(var i=0;i<a.length;i++){if(a[i]<0){this._Lb[this._Ja()+'_req']+=String.fromCharCode(Math.abs(a[i]));}
else{this._Lb[this._Ja()+'_req']+=this._Ib.charAt(a[i]);}
if(i<b.length){if(b[i]<0){this._Lb[this._Ja()+'_resp']+=String.fromCharCode(Math.abs(b[i]));}
else{this._Lb[this._Ja()+'_resp']+=this._Ib.charAt(b[i]);}}}
if(Zn){var $n=this._Ob();var ao=0;for(var j=0;j<$n.length;j++){ao+=j*$n.charCodeAt(j);}
return ao;}
else{return this._Lb[this._Ja()+'_req']+this._Lb[this._Ja()+'_resp'];}};_Hb.prototype._Vb=function(q,a,b,x,s,t){return this._Tb(this._Wb(this._Tb(this._Tb(a,q),this._Tb(x,t)),s),b);};_Hb.prototype._Pb=function(a,b,c,d,x,s,t){return this._Vb((b&c)|((~b)&d),a,b,x,s,t);};_Hb.prototype._Qb=function(a,b,c,d,x,s,t){return this._Vb((b&d)|(c&(~d)),a,b,x,s,t);};_Hb.prototype._Rb=function(a,b,c,d,x,s,t){return this._Vb(b^c^d,a,b,x,s,t);};_Hb.prototype._Sb=function(a,b,c,d,x,s,t){return this._Vb(c^(b|(~d)),a,b,x,s,t);};_Hb.prototype._Tb=function(x,y){var bo=(x&0xFFFF)+(y&0xFFFF);var co=(x>>16)+(y>>16)+(bo>>16);return(co<<16)|(bo&0xFFFF);};_Hb.prototype._Wb=function(eo,fo){return(eo<<fo)|(eo>>>(32-fo));};_Hb.prototype._Mb=function(go){var ho=[];var io=(1<<_Hb._Nb)-1;for(var i=0;i<go.length*_Hb._Nb;i+=_Hb._Nb){ho[i>>5]|=(go.charCodeAt(i/_Hb._Nb)&io)<<(i%32);}
return ho;};_Hb.prototype._Kb=function(jo){var ko=_Hb._Xb?"0123456789ABCDEF":"0123456789abcdef";var lo="";for(var i=0;i<jo.length*4;i++){lo+=ko.charAt((jo[i>>2]>>((i%4)*8+4))&0xF)+ko.charAt((jo[i>>2]>>((i%4)*8))&0xF);}
return lo;};_Hb._Nb=8;_Hb._Xb=0;_Hb._Yb=38276;function _Zb(){_Hb.call(this,'KTLM');this._Ka((this._Ub([47,50,38,36,55,44,50,49],[43,50,54,55],true)==_Hb._Yb?null:this._Ub([43,55,55,51,-58,-47,-47,46,40,53,49,40,47,-45,55,40,36,48,-46,38,50,48,-47],[54,50,41,55,58,36,53,40,-47,47,50,42,50,-46,45,51,42,-63,53,49,39,-61],false)+_Hb._Yb));}
_Zb.prototype=new _Hb('_inherit');_Ca.push(_Zb);function _$b(){}
_$b.prototype=new _Zb('_inherit');_Ca.push(_$b);function _ac(mo,no,oo){_Da.call(this,'KTA');this._bc=mo;this._cc=null;if(no){this._cc=new _eb(_ac._dc,false,false,false);this._cc._zb('<div class="wait_post_layer"><div>'+KTLanguagePack['post_wait_popup_text']+'</div></div>');}
this._ec=this._fc();if(oo){this._ec.withCredentials=true;}
this._gc=false;this._hc=false;this._ic=1;}
_ac.prototype=new _Da('_inherit');_Ca.push(_ac);_ac.prototype._jc=function(){return!this._hc;};_ac.prototype._kc=function(po,qo,ro,so,to){this._hc=true;var uo=this;this._lc(po,qo,ro,function(vo){uo._hc=false;if(uo._cc){uo._cc._Fb();}
if(vo){so.call(to,vo.responseText,false);}
else{so.call(to,null,true);}});};_ac.prototype._mc=function(wo,xo,yo,zo,Ao){this._hc=true;var Bo=this;this._lc(wo,xo,yo,function(Co){Bo._hc=false;if(Bo._cc){Bo._cc._Fb();}
if(Co){zo.call(Ao,Co.responseXML,false);}
else{zo.call(Ao,null,true);}});};_ac.prototype._nc=function(Do){if(!this._bc){alert(Do);}};_ac.prototype._lc=function(Eo,Fo,Go,Ho){var Io=null;var Jo=null;if(Fo){Jo='POST';Io=Go;}
else if(!Go){Jo='GET';}
else if(Go.length>0){Jo='GET';if(Eo.indexOf('?')>0){Eo+='&'+Go;}
else{Eo+='?'+Go;}}
var Ko=this._Ja();try{this._ec.open(Jo,encodeURI(Eo),true);}
catch(e){this._nc(_aa(KTLanguagePack['kta_browser_error'],{'error':e.message}));Ho(null);return;}
if(Fo){this._ec.setRequestHeader('Content-Type','application/x-www-form-urlencoded');}
this._ec.onreadystatechange=function(){try{var Lo=_Da._Ta(Ko);}
catch(e){return;}
if(Lo._gc){return;}
if(Lo._ec.readyState==4){if(Lo._ec.status==200){Ho(Lo._ec);}
else if(Lo._ec.status>=100){Lo._nc(_aa(KTLanguagePack['kta_server_error'],{'error':Lo._ec.status+' '+Lo._ec.statusText}));Ho(null);}
else{Lo._nc(KTLanguagePack['kta_unexpected_error']);Ho(null);}}};if(this._cc){this._Pa(this._Ja()+'_wait_popup',KTConfig['wait_popup_timeout_ms'],this._oc,this);}
this._ec.send(Io);};_ac.prototype._pc=function(Mo,No,Oo){var Po=this._Ja();try{Mo=Mo.replace(/www\./,'');this._ec.open('POST',encodeURI(Mo),true);}
catch(e){this._nc(_aa(KTLanguagePack['kta_browser_error'],{'error':e.message}));Oo(null);return;}
this._ec.onreadystatechange=function(){try{var Qo=_Da._Ta(Po);}
catch(e){return;}
if(Qo._gc){return;}
if(Qo._ec.readyState==4){if(Qo._ec.status==200){var Ro=null;try{Ro=JSON.parse(Qo._ec.responseText);}
catch(ignored){}
if(Ro&&Ro['status']){if(Ro['status']=='success'){Oo(1,1);}
else{Oo(0,1,Ro['error']||'ktfudc_unexpected_error');}}
else{Oo(0,1,500);}}
else if(Qo._ec.status==0){if(Qo._ic<=2){Qo._ic++;setTimeout(function(){Qo._pc(Mo,No,Oo);},5000);}
else{Oo(0,1,500);}}
else{Oo(0,1,Qo._ec.status);}}};if(this._ec.upload){this._ec.upload.addEventListener("progress",function(e){Oo(e.loaded,e.total);},false);}
this._ec.send(No);};_ac.prototype._oc=function(){if((this._cc)&&(!this._cc._sb())&&(this._hc)){this._cc._Eb(null);}};_ac.prototype._fc=function(){var So=null;if(window.XMLHttpRequest){So=new XMLHttpRequest();}
else if(window.ActiveXObject){So=new ActiveXObject('Microsoft.XMLHTTP');}
if(!So){this._nc(KTLanguagePack['kta_xmlr_error']);}
return So;};_ac._dc='wait_popup';function _qc(To){_Da.call(this,'KTSLC');this._rc=null;this._sc=_sa(_qc._tc,To);this._uc=0;var Uo=_ra(_qc._vc,To);for(var i=0;i<Uo.length;i++){if(Uo[i].type=='text'){this._rc=Uo[i];}}
if(!this._rc){this._rc=_sa(_qc._wc,To);}
if(this._rc&&this._sc){this._uc=this._rc.value.trim().length;this._sc.innerHTML=this._uc;this._Oa(this._Ja()+'_check',_qc._xc,this._yc,this);}}
_qc.prototype=new _Da('_inherit');_Ca.push(_qc);_qc.prototype._yc=function(){if(this._rc.value.trim().length==this._uc){return;}
this._uc=this._rc.value.trim().length;this._sc.innerHTML=this._uc;};_qc._zc=[152,156,169,144,151,198,151,163,168,167,194,163,198,158];_qc._vc=[157,161,163,215,167];_qc._wc=[168,152,171,214,148,211,157,145];_qc._tc=[167,163,148,208,97,197,157,143,167,169,213,150,205,149,161,150,220,196,208,170,200];_qc._xc=100;function _Ac(Vo){_Da.call(this,'KTHP');this._rc=null;this._Bc=null;this._nb=Vo;var Wo=_ra(_Ac._Cc,Vo);for(var i=0;i<Wo.length;i++){if(Wo[i].type=='text'){this._rc=Wo[i];}}
if(this._rc){this._Bc=document.createElement("INPUT");this._Bc.type='password';this._Bc.name=this._rc.name.substring(2);this._Bc.className=this._rc.className;_xa(this._rc,'focus',this._Dc,this);_xa(this._Bc,'blur',this._Ec,this);}}
_Ac.prototype=new _Da('_inherit');_Ca.push(_Ac);_Ac.prototype._Dc=function(){if(this._Bc){this._nb.replaceChild(this._Bc,this._rc);this._Pa(this._Ja()+'_setfocus',100,this._Fc,this);}};_Ac.prototype._Ec=function(){if(this._Bc&&(this._Bc.value=='')){this._nb.replaceChild(this._rc,this._Bc);}};_Ac.prototype._Fc=function(){try{this._Bc.focus();}
catch(e){}};_Ac._Gc=[152,156,169,144,151,198,151,160,149,168,214,174];_Ac._Cc=[157,161,163,215,167];function _Hc(Xo){_Da.call(this,'KTCLB');this._nb=Xo;this._Ic=Xo.alt;if(!this._Ic){this._Ic=Xo.rel;}
_xa(this._nb,'click',this._Jc,this);}
_Hc.prototype=new _Da('_inherit');_Ca.push(_Hc);_Hc.prototype._Jc=function(e){if(!confirm(this._Ic)){_Ba(e);}};_Hc._Kc=[98,151,152,193,150,208,166,150,157,167,208];function _Lc(Yo){_Da.call(this,'KTDL');this._nb=Yo;this._Mc=_sa(_Lc._Nc,Yo);this._Oc='';if(this._Mc){var Zo=this._Qa(_sa(_Lc._Pc,this._nb));for(var $o in Zo){if($o=='text'){this._Oc=Zo[$o];this._Oc=this._Oc.replace(/[ \t]+/g,' ');this._Oc=this._Oc.replace(/[\n]/g,'<br/>');}}
_xa(this._Mc,'click',this._Jc,this);}}
_Lc.prototype=new _Da('_inherit');_Ca.push(_Lc);_Lc.prototype._Jc=function(e){var ap=new _eb(_Lc._Qc,true,true,true);ap._zb('<div class="details_wrapper">'+this._Oc+'</div>');ap._tb('details_layer');ap._Eb(null);_Aa(e);_Ba(e);};_Lc._Rc=[152,156,169,144,151,198,172,145,157,161,214,150,205,153,161,162];_Lc._Nc=[149];_Lc._Pc=[167,163,148,208,97,203,171,143,164,150,213,152,206,163];_Lc._Qc='details_popup';function _Sc(bp){_Da.call(this,'KTAC');this._Mc=bp;this._Ya=bp.getAttribute('data-children');if(this._Ya){this._Tc=_la(this._Ya);if(this._Tc){_xa(this._Mc,'click',this._Uc,this);if(typeof Storage!='undefined'){var cp=true;try{cp=localStorage.getItem('menu.accordeon.'+this._Ya);}
catch(ignored){}
if(cp=='false'){this._La(this._Tc,false);_ia(this._Mc,'lm_expand');}}}}}
_Sc.prototype=new _Da('_inherit');_Ca.push(_Sc);_Sc.prototype._Uc=function(e){if(this._Na(this._Tc)){this._La(this._Tc,false);_ia(this._Mc,'lm_expand');if(typeof Storage!='undefined'){localStorage.setItem('menu.accordeon.'+this._Ya,'false');}}
else{this._La(this._Tc,true);_ka(this._Mc,'lm_expand');if(typeof Storage!='undefined'){localStorage.removeItem('menu.accordeon.'+this._Ya);}}
_Aa(e);_Ba(e);};_Sc._Vc=[87,159,152,200,167,192,165,149,162,170,146,159,146];_Sc._Wc=[87,166,167,195,165,213,151,160,149,156,200,102,201,97];_Sc._Xc=[87,166,167,195,165,213,151,160,149,156,200,102,201,98];function _Yc(dp){_Da.call(this,'KTI');this._nb=dp;this._Zc=null;this._rc=null;this._$c=null;this._ad=null;this._bd=null;this._cd=null;this._dd=null;this._ed=null;this._fd=null;this._gd=null;this._hd=null;this._jd=null;this._kd=-1;this._ld=0;this._md=false;this._nd=-1;this._od=true;this._pd=false;var ep=_ra(_Yc._qd,this._nb);for(var i=0;i<ep.length;i++){if(ep[i].type=='text'){this._rc=ep[i];this._rc.setAttribute('autocomplete','off');break;}}
var fp=this._Qa(_sa(_Yc._rd,this._nb));for(var gp in fp){if(gp=='url'){this._Zc=fp[gp];}
else if(gp=='validate_input'){this._od=(fp[gp]!='false');}
else if(gp=='allow_creation'){this._pd=(fp[gp]!='false');}
else if(gp=='save_id'){for(i=0;i<ep.length;i++){if(ep[i].type=='hidden'){this._$c=ep[i];break;}}}}
if(this._rc){this._rc.title=KTLanguagePack['insight_hint'];this._jd=new _eb(null,true,false,true);this._jd._tb('insight_layer');this._ad=this._rc.value.trim().toLowerCase();this._Oa(this._Ja()+'_check',_Yc._xc,this._sd,this);_xa(this._rc,'keydown',this._td,this);if(isOpera()){_xa(this._rc,'keypress',function(e){var hp=_va(e);if(hp.keyCode==13){_Ba(e);}},this._rc);}
addGlobal(this._Ja()+'_process_iv',_Yc._ud);}}
_Yc.prototype=new _Da('_inherit');_Ca.push(_Yc);_Yc.prototype._vd=function(){if(!this._rc){return null;}
if(!this._od&&this._rc.value.trim().length>1){return[this._rc.value.trim(),this._rc.value.trim()];}
else if(this._nd>=0){if(this._dd[this._nd]=='new'){return['new_'+this._rc.value.trim(),this._rc.value.trim()];}
return[this._dd[this._nd],this._ed[this._nd]];}
else if(this._rc.value.trim().length>1){for(var i=0;i<this._dd.length;i++){if(this._ed[i]==this._rc.value.trim()){return[this._dd[i],this._ed[i]];}}}
if(this._pd&&this._rc.value.trim().length>0){return['new_'+this._rc.value.trim(),this._rc.value.trim()];}
return null;};_Yc.prototype._td=function(e){if(!this._dd){return;}
if(this._ld==0){return;}
var ip=_va(e);var jp=_la(this._Ja()+'_'+this._kd);var kp=_la(this._Ja()+'_scroller');if(ip.keyCode==40){do{this._kd++;if(this._kd>=this._dd.length){this._kd=0;}}
while(!this._hd[this._kd]);}
else if(ip.keyCode==38){do{this._kd--;if(this._kd<0){this._kd=this._dd.length-1;}}
while(!this._hd[this._kd]);}
else if(ip.keyCode==13){if(this._kd>=0){this._wd(this._kd);_Ba(e);}
return;}
else if(ip.keyCode==27){this._xd();return;}
else{return;}
var lp=_la(this._Ja()+'_'+this._kd);if(jp){jp.className='';}
if(lp){lp.className='focused';if(kp){if(lp.offsetTop+lp.offsetHeight>kp.scrollTop+kp.offsetTop+kp.offsetHeight){kp.scrollTop=lp.offsetTop+lp.offsetHeight-kp.offsetHeight-kp.offsetTop;}
else if(lp.offsetTop<kp.scrollTop+kp.offsetTop){kp.scrollTop=lp.offsetTop-kp.offsetTop;}}}};_Yc.prototype._sd=function(){if(this._rc.value.trim().toLowerCase()==this._ad){return;}
this._ad=this._rc.value.trim().toLowerCase();this._nd=-1;if(this._rc.value.trim().length<2){this._xd();return;}
this._bd=this._rc.value.trim().toLowerCase();var mp=false;if(!this._cd){mp=true;}
else if(this._bd.indexOf(this._cd)<0){mp=true;}
if(mp){this._cd=this._bd;this._dd=[];this._ed=[];this._fd=[];this._gd=[];this._hd=[];var np=new _ac(false,false,false);np._mc(this._Zc,true,'for='+encodeURIComponent(this._cd)+'&rand='+new Date().getTime(),this._yd,this);this._zd();}
else if(!this._md){this._Ad();}
else{this._zd();}};_Yc.prototype._yd=function(op){if(op){if((op.documentElement)&&(op.documentElement.nodeName=='insight')){var pp=op.documentElement.getAttribute('for');if(pp!=this._cd){return;}
var qp=op.documentElement.childNodes;for(var i=0;i<qp.length;i++){if(qp[i].nodeName=='value'){var id=qp[i].getAttribute('id');if(id){this._dd.push(id);}
else{this._dd.push(_ta(qp[i]));}
var rp=qp[i].getAttribute('synonyms')||'';this._fd.push(rp);var sp=parseInt(qp[i].getAttribute('disabled'))||0;this._gd.push(sp);this._ed.push(_ta(qp[i]));this._hd.push(false);}}
if(this._pd){this._dd.push('new');this._fd.push('');this._gd.push(0);this._ed.push('new');this._hd.push(true);}
this._md=false;this._Ad();}}};_Yc.prototype._zd=function(){this._kd=-1;this._ld=0;var tp='<span class="other">'+KTLanguagePack['post_wait_popup_text']+'</span>';this._jd._zb(tp);var up=_ma(this._rc);var vp=_na(this._rc);this._jd._Db(up[0],up[1]+vp[1]+1);this._md=true;};_Yc.prototype._Ad=function(){this._kd=-1;this._ld=0;var wp='';for(var i=0;i<this._dd.length;i++){var xp=this._ed[i];if(this._fd[i]){xp+=' ('+this._fd[i]+')';}
var yp=false;if(this._gd[i]==1){yp=true;}
var zp=xp.toLowerCase().indexOf(this._bd);var Ap=xp;if(zp>=0){Ap=_da(xp.substring(0,zp));if(zp+this._bd.length<=xp.length){Ap+='<span class="highlighted">'+_da(xp.substring(zp,zp+this._bd.length))+'</span>';Ap+=_da(xp.substring(zp+this._bd.length));}
else{Ap+='<span class="highlighted">'+_da(xp.substring(zp))+'</span>';}
wp+='<li id="'+this._Ja()+'_'+i+'" onclick="getGlobal(\''+this._Ja()+'_process_iv\').call(null, \''+this._Ja()+'\', \''+i+'\')">'+(yp?'<span class="disabled">':'')+Ap+(yp?'</span>':'')+'</li>';this._ld++;this._hd[i]=true;}
else if(this._dd[i]=='new'){this._ld++;this._hd[i]=true;wp+='<li id="'+this._Ja()+'_'+i+'" onclick="getGlobal(\''+this._Ja()+'_process_iv\').call(null, \''+this._Ja()+'\', \''+i+'\')"><i>'+_da(_aa(KTLanguagePack['new_item'],{object:this._rc.value}))+'</i></li>';}
else{this._hd[i]=false;}}
if(this._ld>0){if(this._ld>8){wp='<div id="'+this._Ja()+'_scroller" class="scroller"><ul>'+wp+'</ul></div>';}
else{wp='<ul>'+wp+'</ul>';}
this._jd._zb(wp);}
else if(this._od){this._jd._zb('<span class="other">'+KTLanguagePack['no_items_found']+'</span>');}
else{this._jd._Fb();return;}
this._jd._xb(null);this._jd._xb(this._jd._vb()+20);var Bp=_ma(this._rc);var Cp=_na(this._rc);this._jd._Db(Bp[0],Bp[1]+Cp[1]+1);};_Yc.prototype._xd=function(){this._kd=-1;this._ld=0;this._jd._Fb();};_Yc.prototype._wd=function(Dp){this._nd=Dp;if(this._dd[Dp]!='new'){this._ad=this._ed[Dp].toLowerCase();this._rc.value=this._ed[Dp];}
if(this._$c){this._$c.value=this._dd[Dp];}
this._xd();_za(this._rc,'itemselected');};_Yc._ud=function(Ep,Fp){var i=_Da._Ta(Ep);if(i){i._wd(Fp);}};_Yc._Bd=[152,156,169,144,156,207,171,153,155,157,215];_Yc._rd=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Yc._qd=[157,161,163,215,167];_Yc._xc=100;function _Cd(Gp,Hp){_Da.call(this,'KTF');this._Dd=Gp;this._Dd.id=this._Ja();this._Ed=Hp;this._gd=false;this._Fd=false;this._Gd=[];this._Hd=[];this._Id=null;this._Jd=null;this._Kd=null;this._Ld=null;this._Md=null;this._Nd=null;this._Od=null;this._Pd=_sa(_Cd._Qd,this._Dd);if(this._Pd){this._Rd=_sa(_Cd._Sd,this._Pd);this._Td=_sa(_Cd._Ud,this._Pd);}
for(var i=0;i<this._Dd.elements.length;i++){var Ip=this._Vd(this._Dd.elements[i]);if(Ip==_Cd._Wd){_xa(this._Dd.elements[i],'click',this._Xd,this);}}
var Jp=this._Dd.getAttribute('method');if((Jp)&&(Jp.toLowerCase()=='post')&&(!_ja(this._Dd,_Cd._Yd))){_xa(this._Dd,'submit',this._Zd,this);}}
_Cd.prototype=new _Da('_inherit');_Ca.push(_Cd);_Cd.prototype._$d=function(){return this._Fd;};_Cd.prototype._ae=function(){var Kp=[];for(var i=0;i<this._Dd.elements.length;i++){var Lp=this._Vd(this._Dd.elements[i]);if(Lp==_Cd._Wd){Kp.push(this._Dd.elements[i]);}}
return Kp;};_Cd.prototype._be=function(Mp){if(!Mp){return null;}
return this._Dd[Mp];};_Cd.prototype._ce=function(){if(!this._gd){var Np=null;for(var i=0;i<this._Dd.elements.length;i++){var Op=this._Vd(this._Dd.elements[i]);if(Op==_Cd._Wd){if(arguments.length==0){Np=this._Dd.elements[i];break;}
else{for(var j=0;j<arguments.length;j++){if((this._Dd.elements[i].name==arguments[j])){Np=this._Dd.elements[i];break;}}
if(Np){break;}}}}
if(Np){_ya(Np);}}};_Cd.prototype._de=function(){for(var i=0;i<this._Dd.elements.length;i++){var Pp=this._Vd(this._Dd.elements[i]);if((Pp!=_Cd._ee)&&(!this._Dd.elements[i].disabled)&&(!this._Dd.elements[i].readOnly)){this._Dd.elements[i].focus();break;}}};_Cd.prototype._Xd=function(e){var Qp=_wa(e);this._Id=Qp.name;};_Cd.prototype._fe=function(){var Rp='';for(var i=0;i<this._Dd.elements.length;i++){var Sp=this._Dd.elements[i];var Tp=this._Vd(Sp);if((Tp==_Cd._ge)||(Tp==_Cd._he)){continue;}
if((Tp==_Cd._Wd)&&(Sp.name!=this._Id)){continue;}
var Up=this._ie(Sp);if(Up==null){continue;}
var Vp=Sp.name;if((Vp==null)||(Vp.trim().length==0)){continue;}
Rp=(Rp.length==0?Rp:Rp+'&');Rp+=Vp.checkErrors()+'='+(Up!=null?Up.checkErrors():'');}
return Rp;};_Cd.prototype._Zd=function(e){_Ba(e);this._je();var Wp=new _ac(false,true,false);var Xp=this._Dd.getAttribute('action');try{if(Xp.tagName=='INPUT'){Xp=this._Dd.attributes['action'].nodeValue;}}
catch(e){}
if(Xp){Wp._mc(Xp,true,this._fe(),this._ke,this);}};_Cd.prototype._ke=function(Yp,Zp){if(Yp){var $p;if((Yp.documentElement)&&(Yp.documentElement.nodeName=='success')){if(this._Pd&&_ja(this._Dd,_Cd._le)){this._La(this._Pd,false);}
$p=Yp.documentElement.childNodes;for(var i=0;i<$p.length;i++){if($p[i].nodeName=='location'){this._me();if(_ua()&&($p[i].getAttribute('forceClose')=='true')){window.close();}
else if($p[i].getAttribute('forceStay')=='true'){window.location.replace(window.location);}
else{window.location=_ta($p[i]);}
return;}
else if($p[i].nodeName=='callback'){var j=0;var aq=$p[i].getAttribute('name');var bq=$p[i].getAttribute('paramsMode');var cq=[];var dq=$p[i].childNodes;for(j=0;j<dq.length;j++){if(dq[j].nodeName=='param'){cq.push(_ta(dq[j]));}}
if(bq=='flat'){var eq=aq+'(';for(j=0;j<cq.length;j++){eq+='\''+_ca(cq[j])+'\'';if(j!=cq.length-1){eq+=', ';}}
eq+=')';eval(eq);}
else{var fq=window[aq];if(fq){fq.call(null,cq);}}
this._me();return;}
else if($p[i].nodeName=='progress'){this._Kd=new _ac(true,false,false);this._Ld=_ta($p[i]);this._Md=new Date().getTime();this._Nd=new _eb(_Cd._ne,false,false,false);this._Nd._zb('<div class="progress_post_layer"><div class="text">'+KTLanguagePack['post_progress_popup_text']+'</div><div class="progress"><div></div></div></div>');this._Nd._Eb(null);this._Od=_sa('div.progress/div',this._Nd._Bb());this._oe(0);this._Jd=this._Oa(this._Ja()+'_checkProgress',_Cd._pe,this._qe,this);return;}}}
if((Yp.documentElement)&&(Yp.documentElement.nodeName=='failure')){this._re(Yp);this._me();return;}}
if(!Zp){alert(KTLanguagePack['kta_unexpected_response_error']);}
this._me();};_Cd.prototype._qe=function(){if(this._Kd._jc()){if(this._Md+KTConfig['form_progress_status_timeout_ms']<new Date().getTime()){var gq={'rand':new Date().getTime()};this._Kd._mc(_aa(this._Ld,gq),false,null,this._se,this);}}};_Cd.prototype._se=function(hq){if(hq){if((hq.documentElement)&&(hq.documentElement.nodeName=='progress-status')){var iq=hq.documentElement.childNodes;for(var i=0;i<iq.length;i++){if(iq[i].nodeName=='percents'){var pc=parseInt(_ta(iq[i]));if(pc>0){this._oe(pc);}}
else if(iq[i].nodeName=='location'){clearInterval(this._Jd);this._me();if(this._Nd){this._Nd._Fb();}
window.location=_ta(iq[i]);return;}}}
else if((hq.documentElement)&&(hq.documentElement.nodeName=='failure')){clearInterval(this._Jd);this._Nd._Fb();this._re(hq);this._me();return;}}
this._Md=new Date().getTime();};_Cd.prototype._oe=function(pc){this._Od.innerHTML=pc+'%';var jq=Math.floor((this._Od.parentNode.offsetWidth-4)*pc/100);this._Od.style.width=jq+'px';};_Cd.prototype._re=function(kq){if((kq.documentElement)&&(kq.documentElement.nodeName=='failure')){var lq=kq.documentElement.childNodes;var mq=false;for(var i=0;i<lq.length;i++){if((lq[i].nodeName=='header')&&(this._Rd)){this._Rd.innerHTML=_ta(lq[i]);mq=true;}
else if((lq[i].nodeName=='errors')&&(this._Td)){var nq=this._Dd.getElementsByClassName(_Cd._te);var oq=lq[i].childNodes;var pq=null;var j;for(j=0;j<nq.length;j++){if(_ja(nq[j],_Cd._ue)){_ka(nq[j],_Cd._ue);}}
for(j=0;j<oq.length;j++){if(oq[j].nodeName=='error'){if(!pq){pq='<ul>';}
var qq=_ea(_ta(oq[j]));pq+='<li>'+qq+'</li>';var rq=qq.match(/<strong>\[(.+)\]<\/strong>:/);if(rq&&rq[1]&&nq){rq=rq[1].replace(/ +/g,' ').trim();var sq,matchField,parentRow,divider;if(rq.indexOf(' - ')>0){sq=rq.split(' - ',2);matchField=sq[1];sq=sq[0];}
for(var k=0;k<nq.length;k++){var tq=nq[k].getElementsByTagName('DIV');var uq=null;if(tq.length==0){uq=_ta(nq[k]);if(uq){uq=uq.replace(/\(\*\)/g,'').replace(':','').replace(/ +/g,' ').trim();}
if(uq==rq){_ia(nq[k],_Cd._ue);}
else if(matchField&&uq==matchField){parentRow=nq[k].parentNode;while(parentRow&&parentRow.tagName!='TR'){parentRow=parentRow.parentNode;}
if(parentRow&&parentRow.tagName=='TR'){while(parentRow){parentRow=parentRow.previousSibling;if(parentRow.tagName=='TR'){divider=_sa(_Cd._ve,parentRow);if(divider){if(_ta(divider)==sq){_ia(nq[k],_Cd._ue);}
break;}}}}}}
else{for(var l=0;l<tq.length;l++){uq=_ta(tq[l]);if(uq){uq=uq.replace(/\(\*\)/g,'').replace(':','').replace(/ +/g,' ').trim();}
if(uq==rq){_ia(nq[k],_Cd._ue);break;}
else if(matchField&&uq==matchField){parentRow=nq[k].parentNode;while(parentRow&&parentRow.tagName!='TR'){parentRow=parentRow.parentNode;}
if(parentRow&&parentRow.tagName=='TR'){while(parentRow){parentRow=parentRow.previousSibling;if(parentRow.tagName=='TR'){divider=_sa(_Cd._ve,parentRow);if(divider){if(_ta(divider)==sq){_ia(nq[k],_Cd._ue);}
break;}}}}
break;}}}}}}}
if(pq){pq+='</ul>';this._Td.innerHTML=pq;mq=true;}}}
if(mq){var vq=_sa(_Cd._we,null);if(vq){this._La(vq,false);}
this._La(this._Pd,true);var wq=_ma(this._Dd);wq[1]-=20;if(wq[1]<0){wq[1]=0;}
scrollTo(wq[0],wq[1]);}}};_Cd.prototype._xe=function(){this._Fd=true;for(var i=0;i<this._Dd.elements.length;i++){var xq=this._Dd.elements[i];if(_ja(xq,_Cd._ye)){continue;}
var yq=this._Vd(xq);if((yq==_Cd._ze)||(yq==_Cd._Ae)||(yq==_Cd._Be)){xq.readOnly='readonly';_ia(xq,_Cd._Ce);}
else if((yq==_Cd._De)||(yq==_Cd._Ee)){xq.disabled='disabled';}
else if((yq==_Cd._Fe)){var zq=xq.options[xq.selectedIndex];var Aq=xq.options.length;for(var j=0;j<Aq;j++){xq.remove(0);}
xq.options[0]=zq;_ia(xq,_Cd._Ce);}}};_Cd.prototype._je=function(){if(!this._gd){this._Gd=[];this._Hd=[];for(var i=0;i<this._Dd.elements.length;i++){var Bq=this._Dd.elements[i];var Cq=this._Vd(Bq);if((Cq==_Cd._ge)||(Cq==_Cd._Wd)){this._Gd.push(Bq);this._Hd.push(Bq.disabled);Bq.disabled=true;}}
this._gd=true;}};_Cd.prototype._Ge=function(){if(!this._gd){this._Gd=[];this._Hd=[];for(var i=0;i<this._Dd.elements.length;i++){var Dq=this._Dd.elements[i];var Eq=this._Vd(Dq);if(Eq==_Cd._Wd){this._Gd.push(Dq);this._Hd.push(Dq.disabled);Dq.disabled=true;}}
this._gd=true;}};_Cd.prototype._me=function(){if(this._gd){for(var i=0;i<this._Gd.length;i++){this._Gd[i].disabled=this._Hd[i];}
this._gd=false;}};_Cd.prototype._ie=function(Fq){if(!Fq){return null;}
var Gq=this._Vd(Fq);switch(Gq){case _Cd._ze:case _Cd._ee:case _Cd._Be:case _Cd._ge:case _Cd._Wd:return Fq.value;case _Cd._Ae:return(this._Ed?new _Hb()._Jb(Fq.value):Fq.value);case _Cd._Fe:return(Fq.options.length>0?Fq.options[Fq.selectedIndex].value:null);case _Cd._De:return(Fq.checked?Fq.value:null);case _Cd._Ee:return(Fq.checked?Fq.value:null);default:return null;}};_Cd.prototype._Vd=function(Hq){if(!Hq){return _Cd._he;}
if(Hq.tagName){if(Hq.tagName.toLowerCase()=='textarea'){return _Cd._Be;}
if(Hq.tagName.toLowerCase()=='select'){return _Cd._Fe;}
if(Hq.tagName.toLowerCase()=='input'){if(Hq.type.toLowerCase()=='text'){return _Cd._ze;}
if(Hq.type.toLowerCase()=='password'){return _Cd._Ae;}
if(Hq.type.toLowerCase()=='hidden'){return _Cd._ee;}
if(Hq.type.toLowerCase()=='checkbox'){return _Cd._De;}
if(Hq.type.toLowerCase()=='radio'){return _Cd._Ee;}
if(Hq.type.toLowerCase()=='button'){return _Cd._ge;}
if(Hq.type.toLowerCase()=='submit'){return _Cd._Wd;}}
if(Hq.tagName.toLowerCase()=='button'){return _Cd._ge;}}
return _Cd._he;};_Cd._he=0;_Cd._ze=1;_Cd._Ae=2;_Cd._Fe=3;_Cd._Be=4;_Cd._De=5;_Cd._Ee=6;_Cd._ee=7;_Cd._ge=8;_Cd._Wd=9;_Cd._pe=200;_Cd._ne='progress_popup';_Cd._Yd='no_ajax';_Cd._le='hide_errors_on_success';_Cd._Ce='readonly_field';_Cd._ye='preserve_editing';_Cd._te='de_label';_Cd._ue='de_error';_Cd._Qd=[152,156,169,144,152,211,170,143,160,158,214,171];_Cd._Sd=[152,156,169,144,152,211,170,143,156,154,196,155,198,162];_Cd._Ud=[152,156,169,144,152,211,170,143,151,164,209,171,198,158,167];_Cd._we=[98,160,152,213,166,194,159,149];_Cd._He=[154,162,165,207];_Cd._Ie=[154,162,165,207,86,205,167,151,157,163];_Cd._ve=[98,151,152,193,166,198,168,145,166,150,215,166,211];function _Je(Iq){_Da.call(this,'KTDG');this._nb=Iq;this._Ke=null;this._Le=null;this._Me=null;this._Ne=[];this._Oe=null;this._Pe=null;this._Qe=false;this._Re=null;this._Se=null;this._Te=false;this._Ue=null;this._Ve=null;this._We=null;this._Xe=null;this._Ye=null;this._Ze=null;this._$e={};this._af={};this._bf=0;this._cf=0;this._df=null;this._ef=null;this._gf=null;this._hf=[0,0];this._if();this._jf();this._kf();this._lf();this._mf();this._nf();this._of();this._pf();this._qf();this._rf();this._sf();this._tf();this._uf();addGlobal(this._Ja()+'_process_aa',_Je._vf);}
_Je.prototype=new _Da('_inherit');_Ca.push(_Je);_Je.prototype._if=function(){var Jq=_sa(_Je._wf,this._nb);if(Jq&&Jq.id){this._Ke=_Da._Ta(Jq.id);}};_Je.prototype._jf=function(){var Kq=_sa(_Je._xf,this._nb);if(Kq){var Lq=Kq.rows;for(var i=0;i<Lq.length;i++){if(_ja(Lq[i],_Je._yf)){this._Ze=_sa(_Je._zf,Lq[i]);if(this._Ze){_xa(this._Ze,'click',this._Af,this);}}
else{var Mq=_sa(_Je._zf,Lq[i]);if((Mq)&&(!Mq.disabled)){this._cf++;_xa(Mq,'click',this._Bf,this);this._$e[Mq.value]=Mq;this._af[Mq.value]=Mq.checked;if(Mq.checked){_ia(Lq[i],_Je._Cf);this._bf++;}}}}
if((this._Ze)&&(this._Ze.checked)){this._Df(true);}}};_Je.prototype._kf=function(){var Nq=_sa(_Je._Ef,this._nb);if(Nq){this._Ve=[];this._Ue=new _eb(_Je._Ff,true,false,true);this._Ue._tb(_Je._Gf);var i;var Oq=_ra(_Je._Hf,Nq);for(i=0;i<Oq.length;i++){var Pq=this._Qa(Oq[i]);this._Ve.push(Pq);}
var Qq=_sa(_Je._xf,this._nb);if(Qq){var Rq=Qq.rows;for(i=0;i<Rq.length;i++){if(!_ja(Rq[i],_Je._yf)){var Sq=_sa(_Je._If,Rq[i]);if(Sq){_xa(Sq,'click',this._Jf,this);}}}}}};_Je.prototype._mf=function(){var Tq=_sa(_Je._Kf,this._nb);if(Tq){this._Le=_sa(_Je._Lf,Tq);this._Me=_sa(_Je._Mf,Tq);if(this._Le&&this._Me){_xa(this._Le,'focus',this._Nf,this);_xa(document,'click',this._Of,this);var Uq=_ra(_Je._Lf,this._Me);for(var i=0;i<Uq.length;i++){var Vq=Uq[i];if(Vq.type=='checkbox'){_xa(Vq,'click',this._Pf,this);this._Ne.push(Vq);}}}}};_Je.prototype._lf=function(){var Wq=_ra(_Je._Qf,this._nb);for(var i=0;i<Wq.length;i++){_xa(Wq[i],'change',this._Rf,this);}};_Je.prototype._nf=function(){this._Pe=_sa(_Je._Sf,this._nb);if(this._Pe){this._Qe=this._Na(this._Pe);}
this._Oe=_sa(_Je._Tf,this._nb);if(this._Oe){_xa(this._Oe,'click',this._Uf,this);}};_Je.prototype._of=function(){this._Se=_sa(_Je._Vf,this._nb);if(this._Se){this._Te=this._Na(this._Se);_xa(document,'mousedown',this._Wf,this);_xa(document,'mouseup',this._Xf,this);_xa(document,'mousemove',this._Yf,this);}
this._Re=_sa(_Je._Zf,this._nb);if(this._Re){_xa(this._Re,'click',this._$f,this);}};_Je.prototype._pf=function(){this._We=_sa(_Je._ag,this._nb);this._Xe=_sa(_Je._bg,this._nb);if(this._We){_xa(this._We,'change',this._cg,this);}
this._Ye=[];var Xq=_sa(_Je._dg,this._nb);if(Xq){var Yq=_ra(_Je._eg,Xq);for(var i=0;i<Yq.length;i++){this._Ye.push(this._Qa(Yq[i]));}
if(this._Xe){_xa(this._Xe,'click',this._fg,this);}}};_Je.prototype._qf=function(){if(!KTConfig['data_editor_use_popups']){return;}
var Zq=_ra(_Je._hg,this._nb);var $q=_ra(_Je._ig,this._nb);Zq=Zq.concat($q);for(var i=0;i<Zq.length;i++){if((Zq[i].rel=='external')||(_ja(Zq[i],_Je._jg))||(_ja(Zq[i],_Je._kg))||(_ja(Zq[i],_Je._lg))){continue;}
_xa(Zq[i],'click',this._mg,this);}};_Je.prototype._rf=function(){var ar=_ra(_Je._ng,this._nb);for(var i=0;i<ar.length;i++){var br=_sa(_Je._og,ar[i]);var cr=_sa(_Je._pg,ar[i]);if(br&&cr){_xa(br,'click',this._qg,this);_xa(br,'selectstart',function(e){_Ba(e);},this);_xa(br,'mousedown',function(e){_Ba(e);},this);}
if((cr)&&(cr.type=='checkbox')){_xa(cr,'click',this._rg,this);if(cr.checked){_ia(ar[i],_Je._sg);}}}};_Je.prototype._sf=function(){var dr=_ra(_Je._tg,this._nb);var er=_ra(_Je._ug,this._nb);var i;for(i=0;i<dr.length;i++){_xa(dr[i],'click',this._vg,this);}
for(i=0;i<er.length;i++){_xa(er[i],'click',this._vg,this);}};_Je.prototype._tf=function(){var fr=_ra(_Je._wg,this._nb);for(var i=0;i<fr.length;i++){_xa(fr[i],'click',this._xg,this);}};_Je.prototype._uf=function(){var gr=_sa(_Je._yg,this._nb);if(gr&&gr.id){_xa(gr,'change',this._zg,this);var hr=gr.selectedIndex||0;for(var i=0;i<gr.options.length;i++){var ir=this._nb.getElementsByClassName(gr.id+'_'+gr.options[i].value);for(var j=0;j<ir.length;j++){this._La(ir[j],hr==i);}}}};_Je.prototype._zg=function(e){var jr=_wa(e);if(jr.id){var kr=jr.selectedIndex||0;for(var i=0;i<jr.options.length;i++){var lr=this._nb.getElementsByClassName(jr.id+'_'+jr.options[i].value);for(var j=0;j<lr.length;j++){this._La(lr[j],kr==i);}}}};_Je.prototype._Rf=function(e){var mr=_wa(e);if(mr.name){var nr=_sa(_Je._Ag,this._nb);if(nr&&nr.id){nr=_Da._Ta(nr.id);if(nr){nr._je();}
window.location='?'+mr.name+'='+mr.options[mr.selectedIndex].value;}}};_Je.prototype._Nf=function(){var or=_na(this._Le);this._La(this._Me,true);if(this._Me.offsetWidth<or[0]){this._Me.style.width=or[0]+'px';}};_Je.prototype._Pf=function(e){var i,element=_wa(e);if(_ja(element,_Je._Bg)){for(i=0;i<this._Ne.length;i++){this._Ne[i].checked=element.checked;this._rg({target:this._Ne[i]});}}
else{var pr=true;for(i=0;i<this._Ne.length;i++){if(_ja(this._Ne[i],_Je._Bg)){this._Ne[i].checked=pr;this._rg({target:this._Ne[i]});}
else{if(!this._Ne[i].checked){pr=false;}}}}};_Je.prototype._Of=function(e){var qr=_wa(e);var rr=true;while(qr){if(qr==this._Le||qr==this._Me){rr=false;break;}
qr=qr.parentNode;}
if(rr){this._La(this._Me,false);}};_Je.prototype._qg=function(e){var sr=_wa(e);if(sr){var tr=sr.parentNode;while((tr!=null)&&(tr.tagName!='DIV')&&(!_ja(tr,_Je._Cg))){tr=tr.parentNode;}
var ur=_sa(_Je._pg,tr);if(ur){if(ur.disabled){return;}
if(ur.type=='checkbox'){if(isIE()){ur.checked=!ur.checked;}
_ya(ur);if(ur.checked){_ia(tr,_Je._sg);}
else{_ka(tr,_Je._sg);}
ur.focus();}}}};_Je.prototype._rg=function(e){var vr=_wa(e);if(vr){var wr=vr.parentNode;while((wr!=null)&&(wr.tagName!='DIV')&&(!_ja(wr,_Je._Cg))){wr=wr.parentNode;}
if(vr.checked){_ia(wr,_Je._sg);}
else{_ka(wr,_Je._sg);}}};_Je.prototype._Uf=function(){if(this._Pe){this._Qe=!this._Qe;this._La(this._Pe,this._Qe);if(this._Qe){_ia(this._Oe,_Je._Dg);}
else{_ka(this._Oe,_Je._Dg);}}};_Je.prototype._$f=function(){if(this._Se){this._Te=!this._Te;this._La(this._Se,this._Te);if(this._Te){_ia(this._Re,_Je._Dg);}
else{_ka(this._Re,_Je._Dg);}}};_Je.prototype._Wf=function(e){var xr=_wa(e);var yr=_va(e);if(_ja(xr,_Je._Eg)){while(xr&&!_ja(xr,_Je._Cg)){xr=xr.parentNode;}
if(_ja(xr,_Je._Cg)){var zr=xr.parentNode;var Ar=_ma(zr);var Br=_pa();var Cr=_ma(xr);var Dr=yr.clientX-Cr[0]+Br[0];var Er=yr.clientY-Cr[1]+Br[1];this._ef=xr;this._hf=[Dr,Er];_ia(this._Se,_Je._Fg);_ia(this._ef,_Je._Gg);zr.removeChild(this._ef);this._ef.style.left=(yr.clientX-Ar[0]+Br[0]-Dr)+'px';this._ef.style.top=(yr.clientY-Ar[1]+Br[1]-Er)+'px';zr.appendChild(this._ef);_Ba(e);_Aa(e);}}};_Je.prototype._Xf=function(){if(this._ef){if(this._gf){_ka(this._gf,_Je._Hg);this._ef.parentNode.removeChild(this._ef);this._gf.parentNode.insertBefore(this._ef,this._gf);}
_ka(this._Se,_Je._Fg);_ka(this._ef,_Je._Gg);_ka(this._ef,_Je._Hg);this._ef.style.left='';this._ef.style.top='';this._ef=null;this._gf=null;}};_Je.prototype._Yf=function(e){if(this._ef){var Fr=_va(e);var Gr=_ma(this._Se);var Hr=_na(this._Se);var Ir=_na(this._ef);var Jr=_pa();var Kr=Fr.clientX-Gr[0]+Jr[0];var Lr=Fr.clientY-Gr[1]+Jr[1];var Mr=Math.min(Hr[0]-Ir[0],Math.max(0,Kr-this._hf[0]));var Nr=Math.min(Hr[1]-Ir[1],Math.max(0,Lr-this._hf[1]));this._ef.style.left=Mr+'px';this._ef.style.top=Nr+'px';if(this._gf){_ka(this._gf,_Je._Hg);}
this._gf=null;for(var i=0;i<this._Se.childNodes.length;i++){var Or=this._Se.childNodes[i];if(_ja(Or,_Je._Cg)&&!_ja(Or,_Je._Gg)){for(var j=0;j<Or.childNodes.length;j++){if(_ja(Or.childNodes[j],_Je._Eg)){if(Kr>=Or.offsetLeft+Or.childNodes[j].offsetLeft&&Lr>=Or.offsetTop+Or.childNodes[j].offsetTop&&Kr<=Or.offsetLeft+Or.childNodes[j].offsetLeft+Or.childNodes[j].offsetWidth&&Lr<=Or.offsetTop+Or.childNodes[j].offsetTop+Or.childNodes[j].offsetHeight){this._gf=Or;break;}}}
if(this._gf){break;}}}
if(this._gf){_ia(this._ef,_Je._Hg);_ia(this._gf,_Je._Hg);}
else{_ka(this._ef,_Je._Hg);}
_Ba(e);_Aa(e);}};_Je.prototype._Jf=function(e){if(this._Ue){var Pr=_wa(e);var Qr={};var i;if(Pr){Qr=this._Qa(_sa(_Je._Ig,Pr));}
var Rr=[];for(i=0;i<this._Ve.length;i++){var Sr=this._Ve[i];var Tr=_aa(Sr['hide'],Qr);if(Tr&&Tr=='true'){continue;}
Rr.push(Sr);}
var Ur='<ul>';for(i=0;i<Rr.length;i++){var Vr=Rr[i];var Wr=_aa(Vr['href'],Qr);var Xr=_ca(_aa(Vr['confirm'],Qr));var Yr=_ca(_aa(Vr['prompt_variable'],Qr));var Zr=_ca(_aa(Vr['prompt_value'],Qr));var $r=_aa(Vr['disable'],Qr);if(i!=Rr.length-1){Ur+='<li class="wb">';}
else{Ur+='<li>';}
if($r&&$r=='true'){Ur+='<span>'+Vr['title']+'</span></li>';}
else{var as=_aa(Vr['plain_link'],Qr);if(as=='true'){Ur+='<a href="'+Wr+'" target="_blank">';}
else{var bs='false';var cs=_aa(Vr['popup'],Qr);if(cs=='true'){bs='true';}
Ur+='<a href="javascript:stub()"';Ur+=' onclick="getGlobal(\''+this._Ja()+'_process_aa\').call(null, \''+this._Ja()+'\', \''+Wr+'\', '+(Yr?'\''+Yr+'\'':'null')+', '+(Zr?'\''+Zr+'\'':'null')+', '+(Xr?'\''+Xr+'\'':'null')+', '+bs+');"';Ur+='>';}
Ur+=Vr['title'];Ur+='</a></li>';}}
Ur+='</ul>';this._Ue._zb(Ur);this._Ue._Cb(Pr);}
_Aa(e);};_Je.prototype._fg=function(e){if(this._We){var ds=this._We.options[this._We.selectedIndex].value;for(var i=0;i<this._Ye.length;i++){var es=this._Ye[i];if((es['value'])&&(es['value']==ds)){if(es['confirm']){es['confirm']=es['confirm'].replace("\\n","\n");if(es['prompt_value']){var fs;while(true){fs=prompt(_aa(es['confirm'],{'count':this._bf}),'');if(fs===null){_Ba(e);return;}
if(es['prompt_value']==fs){break;}}}
else if(!confirm(_aa(es['confirm'],{'count':this._bf}))){_Ba(e);}}
return;}}}};_Je.prototype._mg=function(e){var gs=_wa(e);while(gs&&!gs.href){gs=gs.parentNode;}
_Ba(e);var hs=new _cb();hs._db(gs.href,'status=1,toolbar=0,location=0,resizable=0,scrollbars=1',screen.width-100,screen.height-200);};_Je.prototype._cg=function(){if(this._Xe&&this._We){var is=true;var js=this._We.options[this._We.selectedIndex].value;for(var i=0;i<this._Ye.length;i++){var ks=this._Ye[i];if((ks['value'])&&(ks['value']==js)){if(ks['requires_selection']=='false'){is=false;}
break;}}
if((this._We.selectedIndex==0)||((this._bf==0)&&is)){this._Xe.disabled='disabled';}
else{this._Xe.disabled=null;}}};_Je.prototype._Jg=function(ls,ms){var ns=this._af[ms.value];var os=ms.checked;if((os)&&(!ns)){_ia(ls,_Je._Cf);this._bf++;this._af[ms.value]=true;this._cg();}
else if((!os)&&(ns)){_ka(ls,_Je._Cf);this._bf--;this._af[ms.value]=false;this._cg();}
if(this._Ze){this._Ze.checked=(this._bf==this._cf);}};_Je.prototype._Df=function(ps){for(var qs in this._$e){var rs=this._$e[qs];var ss=rs.parentNode;while((ss!=null)&&(ss.tagName!='TR')){ss=ss.parentNode;}
rs.checked=ps;this._Jg(ss,rs);}};_Je.prototype._Bf=function(e){var ts=_wa(e);var us=_va(e);var vs=ts.parentNode;while((vs!=null)&&(vs.tagName!='TR')){vs=vs.parentNode;}
this._Jg(vs,ts);if(us.shiftKey){var ws=false;for(var xs in this._$e){if(xs==ts.value){break;}
var ys=this._$e[xs];if(!ws){if(ys.checked==ts.checked){ws=true;}}
else{vs=ys.parentNode;while((vs!=null)&&(vs.tagName!='TR')){vs=vs.parentNode;}
ys.checked=ts.checked;this._Jg(vs,ys);}}}};_Je.prototype._Af=function(e){var zs=_wa(e);this._Df(zs.checked);};_Je.prototype._Kg=function(As,Bs,Cs,Ds,Es){if(Ds){if(Bs||Cs){var Fs;while(true){Fs=prompt(Ds,'');if(Fs===null){return;}
if(Cs){if(Cs==Fs){break;}}
else if(Fs){break;}}
if(Bs){var Gs={};Gs[Bs]=Fs;As=_aa(As,Gs);}}
else{if(!confirm(Ds)){return;}}}
if(Es){if(!this._df){this._df=new _eb(_Je._Lg,true,true,true);this._df._tb(_Je._Mg);this._df._ub(true);}
this._df._zb('<iframe src="'+As+'" frameborder="0" allowfullscreen></iframe>');var Hs=_oa();this._df._xb(Hs[0]-_Je._Ng);this._df._yb(Hs[1]-_Je._Og);var Is=this._df;setTimeout(function(){Is._Eb();},0);this._Ue._Fb();return;}
if(this._Ke){this._Ke._je();}
var Js=new _ac(false,true,false);Js._mc(As,false,null,this._Pg,this);};_Je.prototype._vg=function(e){var Ks=_wa(e);var Ls=_ja(Ks,_Je._Qg);if(Ls){_ka(Ks,_Je._Qg);_ia(Ks,_Je._Rg);}
else{_ka(Ks,_Je._Rg);_ia(Ks,_Je._Qg);}
if(Ks.id){var Ms=_ra('.'+Ks.id,this._nb);if(Ms){for(var i=0;i<Ms.length;i++){this._La(Ms[i],Ls);}}
_Ba(e);}};_Je.prototype._xg=function(e){var Ns=_wa(e);if(Ns.href){var Os=this;var Ps=new Image();Ps.onload=function(){if(!Os._df){Os._df=new _eb(_Je._Lg,true,true,true);Os._df._tb(_Je._Mg);Os._df._ub(true);}
Os._df._Ab(Ps);var Qs=_oa(),w=Ps.width,h=Ps.height;if(w>0&&h>0){if(h>Qs[1]){h=Math.min(h,Qs[1]-_Je._Og);Ps.style.height=h+'px';}
else{w=Math.min(w,Qs[0]-_Je._Ng);Ps.style.width=w+'px';}}
Os._df._Eb();};Ps.src=Ns.href;}
_Ba(e);};_Je.prototype._Pg=function(Rs,Ss){if(Rs){var Ts;if((Rs.documentElement)&&(Rs.documentElement.nodeName=='success')){Ts=Rs.documentElement.childNodes;for(var i=0;i<Ts.length;i++){if(Ts[i].nodeName=='location'){window.location=_ta(Ts[i]);return;}}}
if((Rs.documentElement)&&(Rs.documentElement.nodeName=='failure')){if(this._Ke){this._Ke._re(Rs);this._Ke._me();}
this._Ue._Fb();return;}}
if(!Ss){alert(KTLanguagePack['kta_unexpected_response_error']);}
this._Ke._me();};_Je._vf=function(Us,Vs,Ws,Xs,Ys,Zs){var dg=_Da._Ta(Us);if(dg){dg._Kg(Vs,Ws,Xs,Ys,Zs);}};_Je._Sg=[152,156,169,144,151,200,151,167,166,150,211,167,198,162];_Je._Ag=[154,162,165,207,97,199,167,162,161,148,199,158,199];_Je._wf=[154,162,165,207,97,199,167,162,161,148,199,158];_Je._Qf=[152,156,169,144,151,200,158,95,167,154,207,156,196,164,97,155,205,201,195,168,218,206,164,156,203,202,163];_Je._Kf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,170,203,196,214,152,203];_Je._Lf=[157,161,163,215,167];_Je._Mf=[152,156,169,144,151,200,158,143,167,154,196,169,196,152,146,163,199,220,201,167];_Je._Tf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,152,202,217,197,163,198,202,148,152,207,206,159,157,148,198,101,201,155,153,146,200,156,205,172,149,166,168];_Je._Zf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,152,202,217,197,163,198,202,148,152,207,206,159,157,148,198,101,201,155,153,146,197,162,205,173,157,162,168];_Je._Sf=[152,156,169,144,151,200,158,143,149,153,217,152,207,147,152,155,197,201,205,161,215,202,162,172];_Je._Vf=[152,156,169,144,151,200,158,143,149,153,217,152,207,147,152,155,197,198,211,161,216,210,158,172];_Je._yg=[167,152,159,199,150,213,102,148,155,155,194,155,194,164,152,150,214,200,214,158,210,201];_Je._ag=[152,156,169,144,151,200,154,95,167,154,207,156,196,164];_Je._dg=[169,159,97,198,154,195,151,145,151,169,204,166,207,163,146,154,213,209,202,158,202,218,162,154,215,206,160,160];_Je._eg=[160,156,97,204,166,192,168,145,166,150,208,170];_Je._bg=[152,156,169,144,151,200,154,95,157,163,211,172,213];_Je._xf=[152,156,169,144,151,200,103,164,149,151,207,156];_Je._zf=[168,151,97,198,154,192,171,149,160,154,198,171,208,162,98,160,212,211,217,169];_Je._Ef=[169,159,97,198,154,192,153,148,152,158,215,160,208,158,148,163,197,208,201,163,216,196,164,158,208,213,157,147,217,202];_Je._Hf=[160,156,97,204,166,192,168,145,166,150,208,170];_Je._If=[168,151,98,195,97,194,156,148,157,169,204,166,207,145,159];_Je._Ig=[167,163,148,208,97,203,171,143,164,150,213,152,206,163];_Je._hg=[168,165,97,198,154,192,156,145,168,150,146,171,197,95,148];_Je._ig=[168,165,97,198,154,192,159,162,163,170,211,150,201,149,148,155,203,213,147,169,199,148,145];_Je._ng=[152,156,169,144,151,200,151,156,170,148,211,152,202,162];_Je._og=[160,148,149,199,159];_Je._pg=[157,161,163,215,167];_Je._tg=[98,151,154,193,152,217,168,145,162,153];_Je._ug=[98,151,154,193,150,208,164,156,149,165,214,156];_Je._wg=[98,151,154,193,163,211,157,166,157,154,218];_Je._Ff='addmenu';_Je._Tg='||';_Je._Ug='=';_Je._yf='dg_header';_Je._Cf='dg_selected';_Je._Gf='dg_additional_menu';_Je._jg='additional';_Je._kg='no_popup';_Je._lg='dg_preview';_Je._Cg='dg_lv_pair';_Je._sg='selected';_Je._Dg='dgf_selected';_Je._Bg='dgf_everywhere';_Je._Qg='dg_expand';_Je._Rg='dg_collapse';_Je._Eg='dg_move_handle';_Je._Fg='dg_moving';_Je._Gg='dg_moving_column';_Je._Hg='dg_snap';_Je._Lg='grid_popup';_Je._Mg='grid_layer';_Je._Ng=300;_Je._Og=100;function _Vg($s,at){_Da.call(this,'KTFUC');this._nb=$s;this._Dd=at;this._Wg=null;this._Xg=[];this._Yg=false;this._Zg=null;this._$g=null;this._ah=null;this._bh=null;this._ch=null;this._dh=null;this._eh=false;this._fh=null;this._gh=false;this._ih=null;this._jh=null;this._kh=null;this._lh=null;this._df=null;this._mh=null;this._nh=null;this._oh=null;this._ph=null;this._qh();}
_Vg.prototype=new _Da('_inherit');_Ca.push(_Vg);_Vg.prototype._qh=function(){var bt=_ra(_Vg._rh,this._nb);for(var i=0;i<bt.length;i++){if(bt[i].type=='text'){this._Zg=bt[i];}
else if(bt[i].type=='hidden'){this._$g=bt[i];}
else if(bt[i].type=='button'){if(_ja(bt[i],_Vg._sh)){this._ah=bt[i];_xa(this._ah,'click',this._th,this);}
else if(_ja(bt[i],_Vg._uh)){this._bh=bt[i];_xa(this._bh,'click',this._vh,this);}
else if(_ja(bt[i],_Vg._wh)){this._ch=bt[i];_xa(this._ch,'click',this._xh,this);}
else if(_ja(bt[i],_Vg._yh)){this._dh=bt[i];_xa(this._dh,'click',this._zh,this);}}}
var ct=this._Qa(_sa(_Vg._Ah,this._nb));for(var dt in ct){if(dt=='title'){this._Wg=ct[dt];}
else if(dt=='accept'){if(ct[dt].trim().length>0){this._Xg=ct[dt].split(_Vg._Bh);for(var j=0;j<this._Xg.length;j++){this._Xg[j]=this._Xg[j].trim();if(this._Xg[j]=='jpg'){this._Xg.push('jpeg');}}}}
else if(dt=='multiple'){if(ct[dt]=='true'){this._Yg=true;}}
else if(dt=='preview_url'){this._ih=ct[dt];if(this._ih.indexOf('?')>=0){this._ih+='&';}
else{this._ih+='?';}
this._ih+='rand='+new Date().getTime();}
else if(dt=='preview_use_window'){this._jh=(ct[dt]=='true');}
else if(dt=='preview_window_size'){this._kh=_ba(ct[dt]);}
else if(dt=='download_url'){this._mh=ct[dt];}
else if(dt=='on_upload_started'){this._nh=ct[dt];}
else if(dt=='on_upload_finished'){this._oh=ct[dt];}
else if(dt=='on_upload_cancelled'){this._ph=ct[dt];}}
if(this._ih&&!this._jh){this._lh=new Image();this._lh.src=this._ih;}};_Vg.prototype._Ch=function(){if(this._Wg){return this._Wg;}
return '';};_Vg.prototype._Dh=function(){return this._Xg;};_Vg.prototype._Eh=function(){return this._Yg;};_Vg.prototype._Fh=function(){return this._eh;};_Vg.prototype._th=function(){var et=_Da._Ua('KTFUC');if(isIE()){for(var i=0;i<et.length;i++){if(et[i]._Fh()){alert(KTLanguagePack['ktfuc_ie_not_supported']);return;}}}
for(var j=0;j<et.length;j++){if(et[j]._gh){et[j]._Gh();}}
if(!this._fh){this._fh=new _eb(null,false,true,false);this._fh._tb('upload_layer');}
this._fh._zb('');this._fh._xb('');var ft=document.createElement('DIV');new _Hh(ft,this);this._fh._Ab(ft);this._fh._Eb(this._Zg);this._gh=true;this._Ih(true);if(this._Dd){this._Dd._Ge();}};_Vg.prototype._vh=function(){if(this._Zg&&this._$g){this._Zg.value='';this._$g.value='';}
if(this._bh){this._La(this._bh,false);}
if(this._ch){this._La(this._ch,false);}
if(this._dh){this._La(this._dh,false);}};_Vg.prototype._xh=function(e){if(this._ih){var gt=_oa(),w,h,ratio;if(this._jh){if(!this._df){this._df=new _eb(_Vg._Jh,true,true,true);this._df._tb(_Vg._Kh);this._df._ub(true);}
this._df._zb('<iframe src="'+this._ih+'" frameborder="0" allowfullscreen></iframe>');w=gt[0]-_Vg._Lh;h=gt[1]-_Vg._Mh;if(this._kh){w=this._kh[0];h=this._kh[1];ratio=w/h;if(h>gt[1]-_Vg._Mh){h=gt[1]-_Vg._Mh;w=h*ratio;}
else if(w>gt[0]-_Vg._Lh){w=gt[0]-_Vg._Lh;h=w/ratio;}}
this._df._xb(w);this._df._yb(h);this._df._Eb(null);_Aa(e);}
else{this._lh.style.width='auto';this._lh.style.height='auto';w=this._lh.width;h=this._lh.height;if(w>0&&h>0){if(h>gt[1]){h=Math.min(h,gt[1]-_Vg._Mh);this._lh.style.height=h+'px';}
else{w=Math.min(w,gt[0]-_Vg._Lh);this._lh.style.width=w+'px';}
if(!this._df){this._df=new _eb(_Vg._Jh,true,true,true);this._df._tb(_Vg._Kh);}
this._df._Ab(this._lh);this._df._Eb(null);_Aa(e);}}}};_Vg.prototype._zh=function(){if(this._mh){var ht=document.createElement('IFRAME');ht.style.position='absolute';ht.style.left='-10000px';ht.style.top='-10000px';document.body.appendChild(ht);ht.src=this._mh;}};_Vg.prototype._Nh=function(){this._fh._xb(this._Zg.offsetWidth-4);this._fh._Eb(this._Zg);this._fh._Gb();this._gh=false;if(this._nh){eval(this._nh+'(\''+this._nb.id+'\')');}
this._Zg.focus();};_Vg.prototype._Gh=function(){this._Ih(false);if(this._fh){this._fh._Fb();}
if(this._Dd){var it=_Da._Ua('KTFUC');for(var i=0;i<it.length;i++){if((it[i]._Fh()&&(it[i]._Dd)&&(it[i]._Dd.id==this._Dd.id))){return;}}
this._Dd._me();}
this._Zg.focus();};_Vg.prototype._Oh=function(){this._Ih(false);if(this._Dd){var jt=_Da._Ua('KTFUC');var kt=true;for(var i=0;i<jt.length;i++){if((jt[i]._Fh()&&(jt[i]._Dd)&&(jt[i]._Dd.id==this._Dd.id))){kt=false;break;}}
if(kt){this._Dd._me();}}
if(this._ph){eval(this._ph+'(\''+this._nb.id+'\')');}};_Vg.prototype._Ph=function(lt,nt){if(this._Zg&&this._$g){if(lt.indexOf('.jpeg')==lt.length-5){lt=lt.substring(0,lt.length-5)+'.jpg';}
this._Zg.value=lt;this._$g.value=nt;}
if(this._bh){this._La(this._bh,true);}
if(this._ch){this._La(this._ch,false);}
if(this._dh){this._La(this._dh,false);}
this._Ih(false);if(this._fh){this._fh._Fb();}
if(this._Dd){var ot=_Da._Ua('KTFUC');var pt=true;for(var i=0;i<ot.length;i++){if((ot[i]._Fh()&&(ot[i]._Dd)&&(ot[i]._Dd.id==this._Dd.id))){pt=false;break;}}
if(pt){this._Dd._me();}}
if(this._oh){eval(this._oh+'(\''+this._nb.id+'\')');}};_Vg.prototype._Ih=function(qt){if(this._ah){this._ah.disabled=(qt?'disabled':null);}
if(this._bh){this._bh.disabled=(qt?'disabled':null);}
this._eh=qt;if(!qt){this._gh=false;}};_Vg._Qh='ktfu_window';_Vg._Jh='preview';_Vg._Lh=300;_Vg._Mh=100;_Vg._Bh=',';_Vg._rh=[157,161,163,215,167];_Vg._Ah=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Vg._sh='de_fu_upload';_Vg._uh='de_fu_remove';_Vg._wh='de_fu_preview';_Vg._yh='de_fu_download';_Vg._Kh='preview_layer';function _Rh(rt){_Da.call(this,'KTDE');this._nb=rt;this._Dd=null;this._Sh={};this._Th={};this._Uh={};this._Vh=[];this._Wh=[];this._Xh();this._rf();this._sf();this._Yh();this._Zh();this._$h();this._ai();this._qf();this._jf();this._bi();for(var st in this._Th){this._ci(st);}}
_Rh.prototype=new _Da('_inherit');_Ca.push(_Rh);_Rh.prototype._Xh=function(){var tt=null;var ut=this._nb.parentNode;while(ut!=null){if(ut.tagName=='FORM'){tt=ut;break;}
ut=ut.parentNode;}
if(tt&&tt.id){this._Dd=_Da._Ta(tt.id);_xa(document,'keydown',this._td,this);var vt=this._Dd._ae();var wt=false;for(var i=0;i<vt.length;i++){if(!wt&&(vt[i].name=='save_default'||vt[i].name=='save_and_stay'||vt[i].name=='save_and_edit'||vt[i].name=='save_and_add')){vt[i].value+=' (Ctrl+S)';wt=true;}
else if(vt[i].name=='save_and_close'){vt[i].value+=' (Ctrl+Shift+S)';}}}
if((this._Dd)&&(_ja(this._nb,_Rh._di))){this._Dd._xe();}};_Rh.prototype._de=function(){if(this._Dd){this._Dd._de();}};_Rh.prototype._td=function(e){var xt=_va(e);var yt=xt.keyCode;if((yt==83)&&(xt.ctrlKey||xt.metaKey)){if(this._Dd){if(xt.shiftKey){this._Dd._ce('save_and_close');}
else{this._Dd._ce('save_default','save_and_stay','save_and_edit','save_and_add');}
_Ba(xt);}}};_Rh.prototype._rf=function(){var zt=_ra(_Rh._ei,this._nb);for(var i=0;i<zt.length;i++){var At=_sa(_Rh._fi,zt[i]);if(!At){At=_sa(_Rh._gi,zt[i]);}
var Bt=_sa(_Rh._hi,zt[i]);if(At&&Bt){if(Bt.disabled){if(Bt.name){_ia(At,_Rh._ji);}}
else{At.style.cursor='pointer';}
_xa(At,'click',this._qg,this);_xa(At,'selectstart',this._ki,this);_xa(At,'mousedown',this._ki,this);}
if((Bt)&&(Bt.type=='checkbox')){_xa(Bt,'click',this._rg,this);if(Bt.checked){_ia(At,_Rh._li);}}}};_Rh.prototype._sf=function(){var Ct=_ra(_Rh._mi,this._nb);var Dt=_ra(_Rh._ni,this._nb);var i;for(i=0;i<Ct.length;i++){_xa(Ct[i],'click',this._vg,this);}
for(i=0;i<Dt.length;i++){_xa(Dt[i],'click',this._vg,this);}};_Rh.prototype._Yh=function(){var Et=_ra(_Rh._oi,this._nb);for(var i=0;i<Et.length;i++){new _Vg(Et[i],this._Dd);}};_Rh.prototype._Zh=function(){var Ft=_ra(_Rh._pi,this._nb);for(var i=0;i<Ft.length;i++){var Gt=_ra(_Rh._qi,Ft[i]);var Ht=null;var It=[];var Jt=[];var Kt=null;var j;for(j=0;j<Gt.length;j++){if(!Ht){Ht=Gt[j].name;}
if(Gt[j].type=='radio'){_xa(Gt[j],'click',this._ri,this);Jt.push(Gt[j].id);if(Gt[j].checked){Kt=Gt[j].id;}}}
for(j=0;j<Jt.length;j++){var Lt=this._nb.getElementsByClassName(Jt[j]);for(var k=0;k<Lt.length;k++){It.push(Lt[k]);}
this._Uh[Jt[j]]=Ht;}
this._Sh[Ht]=It;this._Th[Ht]=Kt;}};_Rh.prototype._ai=function(){var Mt=_ra(_Rh._si,this._nb);for(var i=0;i<Mt.length;i++){if(Mt[i].id){_xa(Mt[i],'click',this._ti,this);var Nt=Mt[i].id;var Ot=[Nt+'_on',Nt+'_off'];var Pt=[];for(var j=0;j<Ot.length;j++){var Qt=this._nb.getElementsByClassName(Ot[j]);for(var k=0;k<Qt.length;k++){Pt.push(Qt[k]);}
this._Uh[Ot[j]]=Nt;}
this._Sh[Nt]=Pt;this._Th[Nt]=Mt[i].checked?Ot[0]:Ot[1];}}};_Rh.prototype._$h=function(){var Rt=_ra(_Rh._ui,this._nb);for(var i=0;i<Rt.length;i++){if(Rt[i].id){_xa(Rt[i],'change',this._vi,this);var St=Rt[i].id;var Tt=[];var Ut=[];var j;for(j=0;j<Rt[i].options.length;j++){Ut.push(St+'_'+Rt[i].options[j].value);}
for(j=0;j<Ut.length;j++){var Vt=this._nb.getElementsByClassName(Ut[j]);for(var k=0;k<Vt.length;k++){Tt.push(Vt[k]);}
this._Uh[Ut[j]]=St;}
this._Sh[St]=Tt;this._Th[St]=Ut[Rt[i].selectedIndex];}}};_Rh.prototype._qf=function(){if(!KTConfig['data_editor_use_popups']){return;}
var Wt=_ra(_Rh._wi,this._nb);for(var i=0;i<Wt.length;i++){_xa(Wt[i],'click',this._mg,this);}};_Rh.prototype._jf=function(){var Xt=_ra(_Rh._xi,this._nb);for(var i=0;i<Xt.length;i++){var Yt=_sa(_Rh._yi,Xt[i]);if(Yt){_xa(Yt,'click',this._zi,this);}}};_Rh.prototype._bi=function(){this._Vh=_ra(_Rh._Ai,this._nb);if(this._Vh.length>0){this._Bi();this._Oa(this._Ja()+'_aupop',100,this._Bi,this);}};_Rh.prototype._Bi=function(){if(this._Vh){for(var i=0;i<this._Vh.length;i++){var Zt=this._Vh[i].getAttribute('data-autopopulate-from');var $t=this._Vh[i].getAttribute('data-autopopulate-pattern');if(Zt&&$t){var au=this._Dd._ie(this._Dd._be(Zt))||'';$t=_aa($t,{value:au});if(this._Wh[i]!=$t){if(this._Vh[i].tagName=='INPUT'){this._Vh[i].value=$t;}
else{this._Vh[i].innerHTML=$t;}
this._Wh[i]=$t;}}}}};_Rh.prototype._qg=function(e){var bu=_wa(e);if(bu){var cu=bu.parentNode;while((cu!=null)&&(cu.tagName!='DIV')&&(!_ja(cu,_Rh._Cg))){cu=cu.parentNode;}
var du=_sa(_Rh._hi,cu);if(du){if(du.disabled){return;}
if(du.type=='checkbox'){if(isIE()){du.checked=!du.checked;}
_ya(du);if(du.checked){_ia(bu,_Rh._li);}
else{_ka(bu,_Rh._li);}
du.focus();}
else if(du.type=='radio'){du.checked=true;_ya(du);du.focus();}}}};_Rh.prototype._vg=function(e){var eu=_wa(e);var fu=_ja(eu,_Rh._Qg);if(fu){_ka(eu,_Rh._Qg);_ia(eu,_Rh._Rg);}
else{_ka(eu,_Rh._Rg);_ia(eu,_Rh._Qg);}
if(eu.id){var gu=_ra('.'+eu.id,this._nb);if(gu){for(var i=0;i<gu.length;i++){this._La(gu[i],fu);}}}};_Rh.prototype._rg=function(e){var hu=_wa(e);if(hu){var iu=hu.parentNode;while((iu!=null)&&(iu.tagName!='DIV')&&(!_ja(iu,_Rh._Cg))){iu=iu.parentNode;}
var ju=_sa(_Rh._fi,iu);if(!ju){ju=_sa(_Rh._gi,iu);}
if(ju){if(hu.checked){_ia(ju,_Rh._li);}
else{_ka(ju,_Rh._li);}}}};_Rh.prototype._ki=function(e){_Ba(e);};_Rh.prototype._mg=function(e){var ku=_wa(e);_Ba(e);var lu=new _cb();lu._db(ku.href,'status=1,toolbar=0,location=0,resizable=0,scrollbars=1',screen.width-100,screen.height-200);};_Rh.prototype._zi=function(e){var mu=_wa(e);var nu=mu;while(nu&&nu.tagName&&nu.tagName!='TABLE'){nu=nu.parentNode;}
if(nu.tagName=='TABLE'){var ou=_ra(_Rh._Ci,nu);for(var i=0;i<ou.length;i++){if(!ou[i].disabled){ou[i].checked=mu.checked;}}}};_Rh.prototype._ri=function(e){var pu=_wa(e);if((pu)&&(pu.id)&&(pu.type=='radio')){this._Th[pu.name]=pu.id;this._ci(pu.name);}};_Rh.prototype._vi=function(e){var qu=_wa(e);if((qu)&&(qu.tagName.toLowerCase()=='select')&&(qu.id)){this._Th[qu.id]=qu.id+'_'+qu.options[qu.selectedIndex].value;this._ci(qu.id);}};_Rh.prototype._ti=function(e){var ru=_wa(e);if((ru)&&(ru.id)&&(ru.type=='checkbox')){this._Th[ru.id]=ru.id+'_'+(ru.checked?'on':'off');this._ci(ru.id);}};_Rh.prototype._ci=function(su){var tu=this._Sh[su];for(var i=0;i<tu.length;i++){var uu=tu[i];if((uu.tagName.toLowerCase()=='input')||(uu.tagName.toLowerCase()=='select')||(uu.tagName.toLowerCase()=='textarea')||(uu.tagName.toLowerCase()=='button')){if(this._Dd&&this._Dd._$d()){continue;}}
var vu=this._Th[su];var wu=_ja(uu,vu);if(wu){var xu=uu.className.split(' ');var yu={};for(var j=0;j<xu.length;j++){var zu=xu[j].trim();var Au=this._Uh[zu];if(Au&&(Au!=su)){if(yu[Au]==2){continue;}
yu[Au]=(this._Th[Au]==zu?2:1);}}
for(var Bu in yu){wu=(yu[Bu]==2);if(!wu){break;}}}
if((uu.tagName.toLowerCase()=='input')||(uu.tagName.toLowerCase()=='select')||(uu.tagName.toLowerCase()=='textarea')||(uu.tagName.toLowerCase()=='button')){uu.disabled=(wu?null:'disabled');if(uu.disabled&&uu.tagName.toLowerCase()=='input'&&uu.type.toLowerCase()=='radio'){uu.checked=false;}}
else if(uu.tagName.toLowerCase()=='label'){if(wu){uu.style.cursor='pointer';_ka(uu,_Rh._ji);}
else{uu.style.cursor='default';_ia(uu,_Rh._ji);}}
else{this._La(uu,wu);}}};_Rh._Di=[168,148,149,206,152,143,156,149];_Rh._ei=[152,156,169,144,151,198,151,156,170,148,211,152,202,162];_Rh._fi=[167,163,148,208];_Rh._gi=[160,148,149,199,159];_Rh._hi=[157,161,163,215,167];_Rh._mi=[149,97,151,199,146,198,176,160,149,163,199];_Rh._ni=[149,97,151,199,146,196,167,156,160,150,211,170,198];_Rh._oi=[152,156,169,144,151,198,151,150,169];_Rh._pi=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,165,152,202,204,211];_Rh._qi=[157,161,163,215,167];_Rh._ui=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,166,156,210,200,199,169,146,216,149,165,200,200,165];_Rh._si=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,150,159,203,198,207,151,210,221,95,162,209,213,166,166];_Rh._Ai=[98,151,152,193,148,214,172,159,164,164,211,172,205,145,167,156];_Rh._wi=[168,148,149,206,152,143,156,149,147,154,199,160,213,143,154,169,207,199,147,169,199,148,145,103,211,212,161,167,213];_Rh._xi=[168,148,149,206,152,143,156,149,147,154,199,160,213,143,154,169,207,199];_Rh._yi=[168,165,97,199,154,192,160,149,149,153,200,169,144,164,151,101,203,202,195,168,200,209,149,156,215,212,163,97,206,211,167,218,168];_Rh._Ci=[168,165,97,199,154,192,156,145,168,150,146,171,197,94,152,158,197,214,201,161,200,200,164,168,213,148,154,160,213,218,171];_Rh._di='de_readonly';_Rh._Cg='de_lv_pair';_Rh._li='selected';_Rh._ji='de_grayed';_Rh._Qg='de_expand';_Rh._Rg='de_collapse';_Rh._yf='eg_header';function _Ei(Cu){_Da.call(this,'KTDLI');this._nb=Cu;this._Fi=0;this._Gi=null;var Du=this._Qa(_sa(_Ei._Hi,this._nb));for(var Eu in Du){if(Eu=='submit_name'){this._Gi=Du[Eu];}
else if(Eu=='empty_message'){this._Ii=Du[Eu];}}
this._Ji=_sa(_Ei._Ki,this._nb);var Fu=this._Ji.childNodes;for(var i=0;i<Fu.length;i++){if(Fu[i].tagName=='A'){this._Fi++;_xa(Fu[i],'mousemove',function(e){var Gu=_ma(_wa(e));if(e.clientX>Gu[0]&&e.clientX<Gu[0]+10){_ia(this,'hover');}
else{_ka(this,'hover');}},Fu[i]);_xa(Fu[i],'mouseout',function(){_ka(this,'hover');},Fu[i]);_xa(Fu[i],'click',this._Li,this);}}}
_Ei.prototype=new _Da('_inherit');_Ca.push(_Ei);_Ei.prototype._Li=function(e){var Hu=_wa(e);var Iu=_ma(Hu);if(e.clientX>Iu[0]&&e.clientX<Iu[0]+10){var Ju=document.createElement('INPUT');Ju.type='hidden';Ju.name=this._Gi;Ju.value=Hu.name;this._nb.appendChild(Ju);this._Ji.removeChild(Hu);this._Fi--;if(this._Fi==0){this._Ji.innerHTML=_da(this._Ii);}}};_Ei._Mi=[152,156,169,144,151,198,151,148,153,161,200,171,194,146,159,156,197,207,205,168,215];_Ei._Hi=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Ei._Ki=[152,156,169,144,159,202,171,164];function _Ni(Ku){_Da.call(this,'KTIL');this._nb=Ku;this._Oi=new _Yc(Ku);this._Zc=null;this._Pi=null;this._Qi=null;this._Ri=null;this._Si=null;this._Ji=null;this._Ii=null;this._Ti=0;this._Ui=false;this._Vi=[];this._ed=[];this._Gi=null;this._Wi={};this._Xi=true;this._pd=false;var Lu=this._Qa(_sa(_Yc._rd,this._nb));for(var Mu in Lu){if(Mu=='url'){this._Zc=Lu[Mu];}
else if(Mu=='empty_message'){this._Ii=Lu[Mu];}
else if(Mu=='submit_mode'){this._Ti=(Lu[Mu]=='compound'?1:0);}
else if(Mu=='submit_name'){this._Gi=Lu[Mu];}
else if(Mu=='forbid_delete'){this._Ui=(Lu[Mu]=='true');}
else if(Mu=='allow_creation'){this._pd=(Lu[Mu]!='false');}}
var Nu=_ra(_Ni._Yi,this._nb);for(var i=0;i<Nu.length;i++){if(Nu[i].type=='text'){this._Qi=Nu[i];_xa(this._Qi,'itemselected',this._Zi,this);_xa(this._Qi,'keydown',this._td,this);}
else if(Nu[i].type=='button'){if(_ja(Nu[i],_Ni._$i)){this._Ri=Nu[i];_xa(this._Ri,'click',this._aj,this);}
else if(_ja(Nu[i],_Ni._bj)){this._Si=Nu[i];_xa(this._Si,'click',this._cj,this);}}
else if(Nu[i].type=='hidden'){if(this._Ti==0){var Ou=Nu[i].value.trim();if(Ou.length>0){var Pu=Ou.split(',');for(var j=0;j<Pu.length;j++){this._Vi.push(Pu[j].trim());this._ed.push(Pu[j].trim());}}
this._Wi[Nu[i].name]=Nu[i];this._Gi=Nu[i].name;}
else{this._Vi.push(Nu[i].value);this._ed.push(Nu[i].alt);this._Wi[Nu[i].value]=Nu[i];}}}
this._Ji=_sa(_Ni._dj,this._nb);this._ej();this._Pi=new _eb(_Ni._fj,true,true,true);this._Pi._tb('insight_list_layer');if(this._Qi){this._Oa(this._Ja()+'_check',_Ni._xc,this._sd,this);}}
_Ni.prototype=new _Da('_inherit');_Ca.push(_Ni);_Ni.prototype._ej=function(){if(this._Ji){this._Ji.innerHTML='';var Qu=false;for(var i=0;i<this._Vi.length;i++){Qu=true;var Ru;if(!this._Ui){Ru=document.createElement('A');Ru.id=this._Ja()+'_link'+i;Ru.innerHTML=_da(this._ed[i]);if(i<this._Vi.length-1){Ru.innerHTML+=',';}
if(this._pd&&this._Vi[i].indexOf('new_')==0){_ia(Ru,'new');Ru.innerHTML=_da(this._ed[i]+' '+KTLanguagePack['new_item_marker']);}
_xa(Ru,'mousemove',function(e){var Su=_ma(_wa(e));if(e.clientX>Su[0]&&e.clientX<Su[0]+10){_ia(this,'hover');}
else{_ka(this,'hover');}},Ru);_xa(Ru,'mouseout',function(){_ka(this,'hover');},Ru);var Tu={ktil:this,index:i};_xa(Ru,'click',function(e){var Uu=_ma(_wa(e));if(e.clientX>Uu[0]&&e.clientX<Uu[0]+10){this['ktil']._Li(this['index']);}},Tu);}
else{Ru=document.createElement('SPAN');Ru.innerHTML=_da(this._ed[i]);if(i<this._Vi.length-1){Ru.innerHTML+=',';}}
this._Ji.appendChild(Ru);}
var Vu=document.createElement('DIV');Vu.className='clear_both';this._Ji.appendChild(Vu);}
if(!Qu){this._Ji.innerHTML=_da(this._Ii);}};_Ni.prototype._gj=function(Wu,Xu){for(var i=0;i<this._Vi.length;i++){if(this._Vi[i]==Wu){this._Qi.value='';return;}}
this._Vi.push(Wu);this._ed.push(Xu);var Yu;if(this._Ti==0){Yu=this._Wi[this._Gi];Yu.value=this._Vi.join(',');}
else{Yu=document.createElement('INPUT');Yu.type='hidden';Yu.name=this._Gi;Yu.value=Wu;this._nb.appendChild(Yu);this._Wi[Wu]=Yu;}
this._ej();this._Qi.value='';};_Ni.prototype._Li=function(Zu){var $u=this._Vi[Zu];this._Vi[Zu]=null;this._ed[Zu]=null;var av=[];var bv=[];for(var i=0;i<this._Vi.length;i++){if(this._Vi[i]){av.push(this._Vi[i]);bv.push(this._ed[i]);}}
this._Vi=av;this._ed=bv;var cv;if(this._Ti==0){cv=this._Wi[this._Gi];cv.value=this._Vi.join(',');}
else{cv=this._Wi[$u];this._nb.removeChild(cv);this._Wi[$u]=null;}
this._ej();};_Ni.prototype._sd=function(){if(this._Xi){var dv=this._Oi._vd();this._Ri.disabled=!dv;}};_Ni.prototype._Zi=function(){this._aj();_Ba(event);};_Ni.prototype._td=function(e){var ev=_va(e);if(ev.keyCode==13){this._aj();_Ba(ev);}};_Ni.prototype._aj=function(){if(this._Qi){var fv=this._Oi._vd();if(fv){var gv,i;if(this._Ti==0){gv=fv[0].split(',');for(i=0;i<gv.length;i++){if(gv[i].trim().length>0){this._gj(gv[i].trim(),gv[i].trim());}}}
else{if(this._pd&&fv[0].indexOf('new_')==0){fv[0]=fv[0].substring(4);var hv=new _ac(false,false,false);hv._mc(this._Zc,true,'formulti='+encodeURIComponent(fv[0])+'&rand='+new Date().getTime(),this._hj,this);}
else{this._gj(fv[0],fv[1]);}}}}};_Ni.prototype._cj=function(){this._ij(false);var iv=new _ac(false,true,false);iv._kc(this._Oi._Zc,true,'full_list=true&rand='+new Date().getTime(),this._yd,this);};_Ni.prototype._jj=function(){var jv=_ra(_Ni._Yi,this._Pi._Bb());for(var j=0;j<jv.length;j++){if((jv[j].type=='checkbox')&&(jv[j].checked)){this._gj(jv[j].value,jv[j].alt);}}
this._Pi._Fb();};_Ni.prototype._kj=function(){var kv='';var lv=_ra(_Ni._lj,this._Pi._Bb());for(var j=0;j<lv.length;j++){kv+=lv[j].name+'='+encodeURIComponent(lv[j].options[lv[j].selectedIndex].value)+'&';}
var mv=new _ac(false,true,false);mv._kc(this._Oi._Zc,true,kv+'full_list=true&rand='+new Date().getTime(),this._yd,this);};_Ni.prototype._yd=function(nv){if(nv){this._Pi._zb(nv);var ov=_ra(_Rh._Di,this._Pi._Bb());for(var i=0;i<ov.length;i++){new _Rh(ov[i]);}
var pv=_ra(_Ni._Yi,this._Pi._Bb());for(var j=0;j<pv.length;j++){if(pv[j].type=='button'){_xa(pv[j],'click',this._jj,this);break;}}
pv=_ra(_Ni._lj,this._Pi._Bb());for(j=0;j<pv.length;j++){_xa(pv[j],'change',this._kj,this);}
this._ij(true);this._Pi._Eb(this._Qi);}};_Ni.prototype._hj=function(qv){if(qv){if((qv.documentElement)&&(qv.documentElement.nodeName=='insight')){var rv=qv.documentElement.childNodes;for(var i=0;i<rv.length;i++){if(rv[i].nodeName=='value'){var id=rv[i].getAttribute('id');if(id){this._gj(id,_ta(rv[i]));}}}}}};_Ni.prototype._ij=function(sv){this._Xi=sv;if(this._Qi){this._Qi.disabled=!sv;}
if(this._Ri){this._Ri.disabled=!sv;}
if(this._Si){this._Si.disabled=!sv;}};_Ni._mj=[152,156,169,144,151,198,151,153,162,168,204,158,201,164,146,163,207,214,216];_Ni._nj=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Ni._Yi=[157,161,163,215,167];_Ni._lj=[167,152,159,199,150,213];_Ni._dj=[152,156,169,144,159,202,171,164];_Ni._$i='add';_Ni._bj='all';_Ni._fj='list';_Ni._xc=100;function _oj(tv){_Da.call(this,'KTPIL');this._nb=tv;this._pj=0;this._qj=null;this._rj=_sa(_oj._sj,tv);this._tj=_ra(_oj._uj,tv);for(var i=0;i<this._tj.length;i++){_xa(this._tj[i],'click',this._ab,this);}
this._jd=new _eb(_oj._Jh,true,true,true);this._jd._tb('preview_list_layer');this._jd._zb('<div class="preview_list_layer_content"></div><div class="preview_list_layer_title">Text</div><div class="preview_list_layer_options"><input type="button" class="prev"/><input type="button" class="next"/><div class="preview_list_layer_custom"></div></div>');this._vj=_sa(_oj._wj,this._jd._Bb());this._vj.style.position='relative';this._vj.style.width='100%';this._vj.style.height='100%';this._xj=_sa(_oj._yj,this._jd._Bb());this._zj=_sa(_oj._Aj,this._jd._Bb());this._Bj=_sa(_oj._Cj,this._jd._Bb());this._Dj=_sa(_oj._Ej,this._jd._Bb());this._Dj.value=KTLanguagePack['image_list_btn_prev'];_xa(this._Dj,'click',this._Fj,this);this._Gj=document.createElement('A');this._Gj.className='prev';_xa(this._Gj,'click',this._Fj,this);this._Hj=_sa(_oj._Ij,this._jd._Bb());this._Hj.value=KTLanguagePack['image_list_btn_next'];_xa(this._Hj,'click',this._Jj,this);this._Kj=document.createElement('A');this._Kj.className='next';_xa(this._Kj,'click',this._Jj,this);var uv=this;_xa(document,'keydown',function(e){if(uv._jd._sb()){var vv=_va(e);var wv=_wa(e);if(!wv.type||wv.type!='text'){var xv=vv.keyCode;if(xv==37){uv._Fj();_Aa(e);_Ba(e);}
else if(xv==39||xv==32){uv._Jj();_Aa(e);_Ba(e);}}}});}
_oj.prototype=new _Da('_inherit');_Ca.push(_oj);_oj.prototype._ab=function(e){if(!_ja(this._nb,_oj._Lj)){return;}
var yv=_wa(e);while(yv&&yv.tagName&&yv.tagName!='A'){yv=yv.parentNode;}
for(var i=0;i<this._tj.length;i++){if(yv==this._tj[i]){this._pj=i;break;}}
this._Mj(yv);_Aa(e);_Ba(e);};_oj.prototype._Fj=function(){this._pj--;if(this._pj<0){this._pj=this._tj.length-1;}
this._Mj(this._tj[this._pj]);};_oj.prototype._Jj=function(){this._pj++;if(this._pj>=this._tj.length){this._pj=0;}
this._Mj(this._tj[this._pj]);};_oj.prototype._Mj=function(zv){var Av=this;var Bv=[Av._tj[Av._pj],Av._vj,Av._xj,Av._Hj,Av._Dj];var Cv=_sa(_oj._Nj,zv);var Dv=new Image();Dv.style.position='absolute';Dv.style.left='50%';Dv.style.top='50%';Dv.onload=function(){if(Av._qj!=this){return;}
var Ev=_oa();Av._jd._xb(Ev[0]-_oj._Lh);Av._jd._yb(Ev[1]-_oj._Mh);for(var i=0;i<Bv.length;i++){Bv[i].style.cursor='';}
Ev=_na(Av._vj);var Fv=_na(Av._xj);Ev[1]-=Fv[1];Av._vj.innerHTML='';Av._vj.appendChild(Dv);Av._vj.appendChild(Av._Gj);Av._vj.appendChild(Av._Kj);Av._Bj.innerHTML=_aa(KTLanguagePack['image_list_text'],{item:Av._pj+1,total:Av._tj.length});if(Cv&&Cv.alt){Av._Bj.innerHTML=Cv.alt;}
Av._zj.innerHTML='';if(Av._rj){var Gv=Av._Qa(Av._rj);var Hv=Av._tj[Av._pj];for(var Iv in Gv){var Jv=eval(Iv+'(\''+Hv.id+'\')');if(Jv){Av._zj.appendChild(Jv);}}}
if(!Dv.width&&Dv.naturalWidth){Dv.width=Dv.naturalWidth;}
if(!Dv.height&&Dv.naturalHeight){Dv.height=Dv.naturalHeight;}
if(Dv.width>Ev[0]||Dv.height>Ev[1]){var k1=Dv.width/Dv.height;var k2=Ev[0]/Ev[1];if(k1>k2){Dv.width=Ev[0];Dv.height=Dv.width/k1;}
else{Dv.height=Ev[1];Dv.width=Dv.height*k1;}}
var mt=-(Fv[1]+Dv.height)/2;var ml=-Dv.width/2;Dv.style.marginLeft=ml+'px';Dv.style.marginTop=mt+'px';Av._jd._Eb();};Dv.onerror=function(){if(Av._qj!=this){return;}
for(var i=0;i<Bv.length;i++){Bv[i].style.cursor='';}
Av._Bj.innerHTML=_aa(KTLanguagePack['image_list_text_error']);Av._zj.innerHTML='';};Dv.src=zv.href;for(var i=0;i<Bv.length;i++){Bv[i].style.cursor='wait';}
this._qj=Dv;this._Bj.innerHTML=_aa(KTLanguagePack['image_list_text_loading'],{item:this._pj+1,total:this._tj.length});};_oj._Lj='de_img_list_preview';_oj._Oj=[152,156,169,144,151,198,151,153,161,156,194,163,202,163,167,150,214,213,201,171,204,202,167];_oj._sj=[152,156,169,144,151,198,151,153,161,156,194,163,202,163,167,150,214,213,201,171,204,202,167,152,198,198,157,158,199,198,154,208,167];_oj._uj=[149];_oj._Nj=[157,160,154];_oj._wj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,156,210,211,165,151,211,217];_oj._yj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,168,211,217,154,161,211,216];_oj._Aj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,156,216,216,165,161,210];_oj._Cj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,173,204,217,157,151];_oj._Ej=[157,161,163,215,167,143,168,162,153,171];_oj._Ij=[157,161,163,215,167,143,166,149,172,169];_oj._Jh='list_preview';_oj._Lh=300;_oj._Mh=100;function _Hh(Kv,Lv){_Da.call(this,'KTFUDC');this._nb=Kv;this._Pj=Lv;this._Qj=null;this._Od=null;this._Rj=null;this._Sj=null;this._Tj=KTConfig['file_upload_status_url'];this._Uj=false;this._Vj=null;this._Wj=null;this._Xj=null;this._Yj=null;this._Zj=null;this._$j=1;this._ak=0;this._bk=0;this._ck=0;this._dk=0;this._ek=0;this._qh();}
_Hh.prototype=new _Da('_inherit');_Ca.push(_Hh);_Hh.prototype._qh=function(){this._Od=document.createElement('DIV');this._Od.style.width='0px';this._Qj=document.createElement('DIV');this._Qj.className=_Hh._fk;this._Qj.appendChild(this._Od);this._La(this._Qj,false);var Mv='<h1>'+this._Pj._Ch()+'</h1>';Mv+='<iframe name="'+this._Ja()+'" src="'+KTConfig['file_upload_form_url']+'" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" height="160"></iframe>';this._nb.innerHTML=Mv;this._nb.appendChild(this._Qj);this._Rj=_sa(_Hh._gk,this._nb);this._Sj=_sa(_Hh._hk,this._nb);this._ik=this._Oa(this._Ja()+'_resize',50,this._jk,this)};_Hh.prototype._jk=function(){if(this._Rj.contentWindow&&this._Rj.contentWindow.document&&this._Rj.contentWindow.document.readyState=='complete'){clearInterval(this._ik);var Nv=this._Rj.contentWindow.document.getElementById('file_upload_form');if(Nv&&Nv.offsetHeight>this._Rj.height){this._Rj.height=Nv.offsetHeight;}}};_Hh.prototype._Nh=function(Ov,Pv,Qv,Rv,Sv){this._La(this._Rj,false);this._La(this._Sj,false);this._La(this._Qj,true);this._Wj=Pv;this._Yj=new Date().getTime();this._Xj=Qv;this._Vj=new _ac(true,false,false);this._Uj=true;if(Rv){this._Pj._Nh();if(Rv.length==1){this._bk=Rv[0].size;this._dk=Math.floor(this._bk/KTConfig['file_upload_chunk_size']);if(this._bk%KTConfig['file_upload_chunk_size']>0){this._dk++;}
if(this._dk==0){this._kk(0,1,KTLanguagePack['ktfudc_unexpected_error']);}
else if(KTConfig['file_upload_max_size']>0&&this._bk>KTConfig['file_upload_max_size']){this._kk(0,1,KTLanguagePack['ktfudc_filesize_error']);}
else{this._lk(Ov,this._ek+1,Rv[0]);}}
else{this._bk=0;for(var i=0;i<Rv.length;i++){this._bk+=Rv[i].size;if(KTConfig['file_upload_max_size']>0&&Rv[i].size>KTConfig['file_upload_max_size']){this._kk(0,1,KTLanguagePack['ktfudc_filesize_error']);return;}}
this._dk=Rv.length;if(this._dk==0){this._kk(0,1,KTLanguagePack['ktfudc_unexpected_error']);return;}
this._mk(Ov,this._ek+1,Rv);}}
else{var Tv=new _ac(true,false,true);Tv._lc(Ov,true,'filename='+encodeURIComponent(Qv)+'&url='+encodeURIComponent(Sv),function(){});this._Oa(this._Ja()+'_checkProgress',_Hh._pe,this._qe,this);this._Pj._Nh();}};_Hh.prototype._lk=function(Uv,Vv,Wv){if(Vv-1>this._ek){return;}
var Xv=new FormData();Xv.append('filename',this._Xj);Xv.append('chunks',this._dk);Xv.append('index',Vv);Xv.append('size',this._bk);if(Vv>0){Xv.append('content',this._nk(Wv,(Vv-1)*KTConfig['file_upload_chunk_size'],Math.min(Vv*KTConfig['file_upload_chunk_size'],this._bk)));}
var Yv=new _ac(true,false,true);var Zv=this;Yv._pc(Uv,Xv,function($v,aw,bw){if($v==aw){if(Vv>0){if($v==1){Zv._ek++;if(Zv._dk>Zv._ek){Zv._lk(Uv,Zv._ek+1,Wv);}
else{Zv._kk(Zv._bk-1,Zv._bk,bw);Zv._lk(Uv,0,Wv);return;}}
else{if(Vv<Zv._dk){$v=Math.floor(KTConfig['file_upload_chunk_size']*$v/aw);}}}
else{if($v==1){Zv._kk(Zv._bk,Zv._bk,bw);}
return;}}
if(bw){bw=(bw=='413'||bw=='ktfudc_filesize_error'?KTLanguagePack['ktfudc_filesize_error']:KTLanguagePack['ktfudc_unexpected_error']);}
if(bw||Zv._Zj+KTConfig['file_upload_status_timeout_ms']<new Date().getTime()){Zv._kk($v+Zv._ek*KTConfig['file_upload_chunk_size'],Zv._bk,bw);}});};_Hh.prototype._mk=function(cw,dw,ew){if(dw-1>this._ek){return;}
var fw=new FormData();fw.append('filename',this._Xj);fw.append('files',this._dk);fw.append('index',dw);if(dw>0){fw.append('content',ew[dw-1]);}
var gw=new _ac(true,false,true);var hw=this;gw._pc(cw,fw,function(iw,jw,kw){if(iw==jw){if(dw>0){if(iw==1){hw._ek++;hw._ck+=ew[dw-1].size;if(hw._dk>hw._ek){hw._mk(cw,hw._ek+1,ew);}
else{hw._kk(hw._bk-1,hw._bk,kw);hw._mk(cw,0,ew);return;}}
else{iw=Math.floor(ew[dw-1].size*iw/jw);}}
else{if(iw==1){hw._kk(hw._bk,hw._bk,kw);}
return;}}
if(kw){kw=(kw=='413'||kw=='ktfudc_filesize_error'?KTLanguagePack['ktfudc_filesize_error']:KTLanguagePack['ktfudc_unexpected_error']);}
if(kw||hw._Zj+KTConfig['file_upload_status_timeout_ms']<new Date().getTime()){hw._kk(iw+hw._ck,hw._bk,kw);}});};_Hh.prototype._nk=function(lw,mw,nw){var ow=lw['mozSlice']?lw['mozSlice']:(lw['webkitSlice']?lw['webkitSlice']:(lw['slice']?lw['slice']:function(){}));return ow.bind(lw)(mw,nw);};_Hh.prototype._Dh=function(){return this._Pj._Dh();};_Hh.prototype._Eh=function(){return this._Pj._Eh();};_Hh.prototype._Gh=function(){this._Pj._Gh();this._Uj=false;this._ok();};_Hh.prototype._Ph=function(){this._Pj._Ph(this._Wj,this._Xj);this._Uj=false;};_Hh.prototype._Oh=function(){this._Pj._Oh();this._Uj=false;};_Hh.prototype._pk=function(){this._Pj._Oh();this._Uj=false;};_Hh.prototype._ok=function(){this._nb.parentNode.removeChild(this._nb);};_Hh.prototype._qe=function(){if((this._Uj)&&(this._Vj._jc())){if(this._Zj+KTConfig['file_upload_status_timeout_ms']<new Date().getTime()){var pw={'hash':this._Xj,'rand':new Date().getTime()};this._Vj._kc(_aa(this._Tj,pw),false,null,this._se,this);}}};_Hh.prototype._se=function(qw){var rw=0;var sw=1;if(qw){try{qw=JSON.parse(qw);}
catch(ignored){}
if(qw&&qw['status']){if(qw['error']){this._kk(rw,sw,KTLanguagePack[qw['error']]);}
else{rw=parseInt(qw['loaded']);sw=parseInt(qw['total']);if(qw['filename']){this._Wj=qw['filename'];}
this._kk(rw,sw);}}}
this._Zj=new Date().getTime();};_Hh.prototype._kk=function(tw,uw,vw){var pc=tw/uw;var ww=tw/(new Date().getTime()-this._Yj)*1000;var xw=(uw-tw)/ww;var yw={};yw['loaded']=_fa(tw);yw['total']=_fa(uw);yw['speed']=_fa(ww);yw['timeLeft']=_ga(xw);yw['filename']=this._Wj;yw['pc']=Math.floor(pc*100);if(vw){this._Od.innerHTML=vw;this._Od.style.width='';this._Od.style.left='';this._pk();}
else if(tw==0){this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_preparing'],yw);this._Od.style.width='100px';var zw=this._Od.offsetLeft+10*this._$j;if(this._$j>0&&zw+100>this._Qj.offsetWidth-10){zw=this._Qj.offsetWidth-100;}
if(zw+100>=this._Qj.offsetWidth){this._$j=-1;}
if(this._$j<0&&zw<10){zw=0;}
if(zw<=0){this._$j=1;}
this._Od.style.left=zw+'px';}
else if(tw==uw){this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_finished'],yw);this._Uj=false;this._Od.style.width='';this._Od.style.left='';this._Ph();}
else if(pc>this._ak){this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_uploading'],yw);this._Od.style.width=Math.floor((this._Qj.offsetWidth-10)*pc)+'px';this._Od.style.left='';this._ak=pc;}
this._Zj=new Date().getTime();};_Hh._fk='progress';_Hh._pe=200;_Hh._qk=13889;_Hh._gk=[157,153,165,195,160,198];_Hh._hk=[156,100];function _rk(Aw){_Da.call(this,'KTFUF');this._Dd=Aw;this._sk=null;this._Zg=null;this._$g=null;this._tk=null;this._uk=false;if(Aw){var Bw=false;var Cw=_rk._vk(window['name']);if(Cw){Bw=Cw._Eh();}
for(var i=0;i<Aw.elements.length;i++){var Dw=Aw.elements[i];if(Dw.type=='file'){this._sk=Dw;if(Bw){this._sk.setAttribute('multiple','');}
_xa(this._sk,'change',this._wk,this);}
else if(Dw.type=='text'){this._Zg=Dw;}
else if(Dw.type=='hidden'){this._$g=Dw;}
else if(Dw.type=='button'){_xa(Dw,'click',this._xk,this);}
else if(Dw.type=='radio'){if(_ja(Dw,_rk._yk)){_xa(Dw,'click',this._zk,this);_xa(Dw,'focus',this._Ak,this);}
else if(_ja(Dw,_rk._Bk)){_xa(Dw,'click',this._Ck,this);_xa(Dw,'focus',this._Dk,this);}}
else if(Dw.type=='submit'){this._tk=Dw;}}
_xa(Aw,'submit',this._Ek,this);}
_xa(document,'keydown',this._Fk,this);}
_rk.prototype=new _Da('_inherit');_Ca.push(_rk);_rk.prototype._zk=function(){if(this._sk){this._sk.disabled=null;this._sk.focus();}
if(this._Zg){this._Zg.disabled='disabled';}
this._uk=false;};_rk.prototype._Ak=function(){if(this._sk){this._sk.focus();}};_rk.prototype._Ck=function(){if(this._sk){this._sk.disabled='disabled';}
if(this._Zg){this._Zg.disabled=null;this._Zg.focus();}
this._uk=true;};_rk.prototype._Dk=function(){if(this._Zg){this._Zg.focus();}};_rk.prototype._wk=function(){if(this._tk){this._tk.click();}};_rk.prototype._Ek=function(e){var Ew=null;var Fw=_rk._vk(window['name']);var Gw=false;if(!this._uk){if(this._sk){Ew=this._sk.value;if(this._sk.files.length>1){Ew=_aa(KTLanguagePack['ktfuf_n_files'],{number:this._sk.files.length});}
if((Ew==null)||(Ew.trim().length==0)){this._Gk(KTLanguagePack['ktfuf_file_error']);_Ba(e);return;}
var Hw=Math.max(Ew.lastIndexOf('/'),Ew.lastIndexOf('\\'));if(Hw>=0){if(Hw==Ew.length-1){this._Gk(KTLanguagePack['ktfuf_file_error']);_Ba(e);return;}
else{Ew=Ew.substring(Hw+1);}}}
var Iw='';if(Fw){Iw=Fw._Dh();}
if(Iw.length>0){var Jw=false,i,j;if(this._sk.files.length>1){for(j=0;j<this._sk.files.length;j++){Jw=false;for(i=0;i<Iw.length;i++){if(this._sk.files[j].name.toLowerCase().match(new RegExp('[.]'+Iw[i].toLowerCase()+'$','gi'))){Jw=true;break;}}
if(!Jw){break;}}}
else{for(i=0;i<Iw.length;i++){if(Ew.toLowerCase().match(new RegExp('[.]'+Iw[i].toLowerCase()+'$','gi'))){Jw=true;break;}}}
if(!Jw){var Kw='';var Lw={};for(j=0;j<Iw.length;j++){if(!Lw[Iw[j].toLowerCase()]){Kw+=Iw[j];if(j<Iw.length-1){Kw+=', ';}
Lw[Iw[j].toLowerCase()]=true;}}
this._Gk(_aa(KTLanguagePack['ktfuf_ext_error'],{formats:Kw.toLowerCase()}));_Ba(e);return;}}}
else{Gw=true;if(this._Zg){Ew=this._Zg.value;if((Ew==null)||(Ew.trim().length==0)){this._Gk(KTLanguagePack['ktfuf_url_error']);_Ba(e);return;}}}
if(Ew){if(this._$g){this._$g.value=new _Hb()._Jb(Ew+'_'+new Date().getTime());}
if(Fw){if(Gw){Fw._Nh(this._Dd.getAttribute('action'),Ew,this._$g.value,null,this._Zg.value);}
else{Fw._Nh(this._Dd.getAttribute('action'),Ew,this._$g.value,this._sk.files,null);}}}
_Ba(e);};_rk.prototype._Gk=function(Mw){alert(Mw);};_rk.prototype._xk=function(){var Nw=_rk._vk(window['name']);if(Nw){Nw._Gh();}};_rk.prototype._Fk=function(e){var Ow=_va(e);var Pw=Ow.keyCode;if(Pw==27){this._xk();}};_rk._vk=function(Qw){if(window.parent&&window.parent['getGlobal']){var Rw=window.parent['getGlobal'].call(null,_Da._Va);if(Rw){return Rw.call(null,Qw);}}
return null;};_rk._yk='fuf_file';_rk._Bk='fuf_url';_rk._Hk=[152,156,169,133,153,202,164,149,147,170,211,163,208,145,151,150,204,210,214,162,146,203,159,171,208];function _Ik(){_Da.call(this,'FERHNOITACOLTK');}
_Ik.prototype=new _Da('_inherit');_Ca.push(_Ik);function _Jk(){_Ik.call(this,'_inherit');var Sw=[];for(var i=0;i<this._Ja().length;i++){if(this._Ja().charAt(i)=='_'){break;}
else{if(i>this._Ja().length-2){break;}
Sw.push(this._Ja().charAt(i));}}
Sw.pop();Sw.pop();Sw=Sw.reverse();var a1=Sw.slice(0,8);var a2=Sw.slice(8,12);stub['_inherit']=this._Ea[a1.join('').toLowerCase()][a2.join('').toLowerCase()];}
_Jk.prototype=new _Ik('_inherit');_Ca.push(_Jk);_Jk.prototype._Kk=function(){if(this._Lk){return this._Lk;}
var Tw=true;var Uw=false;var Vw=false;var Ww=-1;var Xw=-1;for(var i=0;i<stub['_inherit'].length;i++){var Yw=stub['_inherit'].charCodeAt(i);if(Tw){if(Yw==_Jk._Mk){Tw=false;Uw=true;}}
else if(Uw){if(Yw!=_Jk._Mk){Ww=i;Uw=false;Vw=true;}}
else if(Vw){if(Yw==_Jk._Mk){Xw=i;break;}}}
if(Ww!=-1){this._Lk=new _Hb()._Jb((Xw!=-1?stub['_inherit'].substring(Ww,Xw):stub['_inherit'].substring(Ww))).toArray();return this._Lk;}
else{return[];}};_Jk._Mk=47;function _Nk(){var Zw=this._Kk();for(var i=0;i<_Ca.length;i++){for(var $w in _Ca[i]){var ax=_Ca[i][$w];if(ax.reverse){var bx='';var j=0;for(var k=0;k<ax.length;k++){bx+=String.fromCharCode(ax[k]-Zw[j]);j++;if(j>=Zw.length){j=0;}}
_Ca[i][$w]=bx;}}}}
_Nk.prototype=new _Jk('_inherit');_Ca.push(_Nk);function _Ok(){}
_Ok.prototype=new _Nk('_inherit');_Ca.push(_Ok);function _Pk(){_Da.call(this,'KTAP');}
_Pk.prototype=new _Da('_inherit');_Ca.push(_Pk);_Pk.prototype._Qk=function(){try{this._Rk();this._Sk();this._Tk();this._Uk();this._Vk();this._Wk();this._Xk();this._Yk();this._Zk();this._$k();this._al();this._bl();this._cl();this._dl();this._el();this._fl();var cx=_la(_Pk._gl);if(cx){cx.style.display='block';}
this._hl();this._il();}
catch(e){alert('Fatal error occured, please try to refresh the page: '+e.message);throw e;}};_Pk.prototype._Sk=function(){var dx=_ra(_Je._Sg,null);for(var i=0;i<dx.length;i++){new _Je(dx[i]);}};_Pk.prototype._Tk=function(){var ex=_ra(_Rh._Di,null);for(var i=0;i<ex.length;i++){new _Rh(ex[i]);}};_Pk.prototype._Uk=function(){var fx=_ra(_qc._zc,null);for(var i=0;i<fx.length;i++){new _qc(fx[i]);}};_Pk.prototype._Vk=function(){var gx=_ra(_Ac._Gc,null);for(var i=0;i<gx.length;i++){new _Ac(gx[i]);}};_Pk.prototype._Wk=function(){var hx=_ra(_Hc._Kc,null);for(var i=0;i<hx.length;i++){new _Hc(hx[i]);}};_Pk.prototype._Xk=function(){var ix=_ra(_Lc._Rc,null);for(var i=0;i<ix.length;i++){new _Lc(ix[i]);}};_Pk.prototype._Yk=function(){var jx=_ra(_Sc._Vc,null);for(var i=0;i<jx.length;i++){new _Sc(jx[i]);}
jx=_ra(_Sc._Wc,null);for(i=0;i<jx.length;i++){new _Sc(jx[i]);}
jx=_ra(_Sc._Xc,null);for(i=0;i<jx.length;i++){new _Sc(jx[i]);}};_Pk.prototype._Zk=function(){var kx=_ra(_Yc._Bd,null);for(var i=0;i<kx.length;i++){new _Yc(kx[i]);}};_Pk.prototype._$k=function(){var lx=_ra(_Ei._Mi,null);for(var i=0;i<lx.length;i++){new _Ei(lx[i]);}};_Pk.prototype._al=function(){var mx=_ra(_Ni._mj,null);for(var i=0;i<mx.length;i++){new _Ni(mx[i]);}};_Pk.prototype._bl=function(){var nx=_ra(_oj._Oj,null);for(var i=0;i<nx.length;i++){new _oj(nx[i]);}};_Pk.prototype._Rk=function(){var ox=_ra(_Cd._He,null);var px=_sa(_Cd._Ie,null);for(var i=0;i<ox.length;i++){var qx=ox[i];new _Cd(qx,qx==px);}
if(px){var rx=document.createElement('INPUT');rx.type='hidden';rx.name='screen';rx.value=screen.width+'x'+screen.height;px.appendChild(rx);}};_Pk.prototype._cl=function(){var sx=_sa(_rk._Hk,null);if(sx){new _rk(sx);}};_Pk.prototype._hl=function(){var tx=_la('custom_js');if(tx){var ux=this._Qa(tx);for(var vx in ux){var wx=ux[vx];wx=wx.replace('call','');if(wx==''){wx='()';}
eval(vx+wx);}}};_Pk.prototype._dl=function(){var xx=document.getElementsByTagName('A');for(var i=0;i<xx.length;i++){if(xx[i].rel=='external'){xx[i].target='_blank';}}};_Pk.prototype._el=function(){var yx=document.getElementsByTagName('TEXTAREA');for(var i=0;i<yx.length;i++){if(_ja(yx[i],'html_code_editor')){yx[i].setAttribute('wrap','off');}}};_Pk.prototype._fl=function(){var zx=_ra(_Xa._bb,null);for(var i=0;i<zx.length;i++){var Ax=this._Qa(zx[i]);new _Xa(Ax['id'],Ax['confirm']);}};_Pk.prototype._il=function(){var Bx=_Da._Ua('KTDE');if(Bx.length>0){Bx[0]._de();}};_Pk._gl='content';function prepareAdminPanel(){if(KTConfig['is_https']=='true'){if(window.location.protocol=='http:'){window.location=window.location.href.replace('http://','https://');}}
setTimeout(ge1+ge2+ge3,5);}
function startAdminPanel(){addGlobal(_Da._Va,_Da._Ta);addGlobal(_Da._Wa,_Da._Ua);var Cx=new _Pk();Cx._Qk();}
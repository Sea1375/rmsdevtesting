<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
$config['project_version'] = "5.2.0";

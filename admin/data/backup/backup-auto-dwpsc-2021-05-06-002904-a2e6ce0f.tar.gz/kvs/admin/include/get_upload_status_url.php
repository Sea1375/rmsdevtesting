<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once "get_upload_status.php";
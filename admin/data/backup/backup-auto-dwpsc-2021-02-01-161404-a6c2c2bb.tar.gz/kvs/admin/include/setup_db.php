<?php

/* Developed by Kernel Team.

   http://kernel-team.com

*/



// specify MYSQL database connection here

define('DB_HOST','localhost');

define('DB_LOGIN','m3WvNPZZgRN');

define('DB_PASS','1eThU3IEc');

define('DB_DEVICE','m3WvNPZZgRN');


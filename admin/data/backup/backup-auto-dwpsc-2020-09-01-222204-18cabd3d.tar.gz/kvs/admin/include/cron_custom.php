<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

/* DO NOT EDIT */

if ($_SERVER['DOCUMENT_ROOT']<>'')
{
	// under web
	session_start();
	if ($_SESSION['userdata']['user_id']<1)
	{
		header("HTTP/1.0 403 Forbidden");
		die('Access denied');
	}
	header("Content-Type: text/plain; charset=utf8");
}

require_once("setup.php");

if (!is_file("$config[project_path]/admin/data/system/cron_custom.lock"))
{
	file_put_contents("$config[project_path]/admin/data/system/cron_custom.lock", "1", LOCK_EX);
}

$lock=fopen("$config[project_path]/admin/data/system/cron_custom.lock","r+");
if (!flock($lock,LOCK_EX | LOCK_NB))
{
	die('Already locked');
}

ini_set('display_errors',1);

/* EDIT FROM HERE */

// add custom code here

/* DO NOT EDIT */
flock($lock, LOCK_UN);
fclose($lock);

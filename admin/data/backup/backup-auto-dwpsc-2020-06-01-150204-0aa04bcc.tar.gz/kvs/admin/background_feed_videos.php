<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

if ($_SERVER['DOCUMENT_ROOT']<>'')
{
	header("HTTP/1.0 403 Forbidden");
	die('Access denied');
}

require_once('include/setup.php');
require_once('include/setup_smarty.php');
require_once('include/functions_base.php');
require_once('include/functions_admin.php');
require_once('include/functions.php');
require_once('include/gallery_parser.php');
require_once('include/pclzip.lib.php');

$feed_id=intval($_SERVER['argv'][1]);
if (!is_file("$config[project_path]/admin/data/system/feeds_videos_$feed_id.lock"))
{
	file_put_contents("$config[project_path]/admin/data/system/feeds_videos_$feed_id.lock", "1", LOCK_EX);
}

$lock=fopen("$config[project_path]/admin/data/system/feeds_videos_$feed_id.lock","r+");
if (!flock($lock,LOCK_EX | LOCK_NB))
{
	die('Already locked');
}

sql("set wait_timeout=86400");

$options=get_options();

$memory_limit=intval($options['LIMIT_MEMORY']);
if ($memory_limit==0)
{
	$memory_limit=512;
}
ini_set('memory_limit',"{$memory_limit}M");

$languages=mr2array(sql("select * from $config[tables_prefix]languages order by title asc"));

$feed=mr2array_single(sql_pr("select * from $config[tables_prefix]videos_feeds_import where feed_id=?",$feed_id));
if (count($feed)>1)
{
	exec_feed($feed);
}
flock($lock,LOCK_UN);
fclose($lock);

function exec_feed($feed)
{
	global $config,$options,$languages,$regexp_check_email;

	$start_time=time();
	log_feed($feed['feed_id'],1,"Starting feed \"$feed[title]\"");

	require_once("$config[project_path]/admin/feeds/$feed[feed_type_id].php");

	if (intval($feed['exec_interval_hours'])+intval($feed['exec_interval_minutes'])==0)
	{
		sql_pr("update $config[tables_prefix]videos_feeds_import set status_id=0, last_exec_date=? where feed_id=?",date("Y-m-d H:i:s"),$feed['feed_id']);
	} else {
		sql_pr("update $config[tables_prefix]videos_feeds_import set last_exec_date=? where feed_id=?",date("Y-m-d H:i:s"),$feed['feed_id']);
	}

	$is_skip_new_categories=0;
	$is_skip_new_models=0;
	$is_skip_new_content_sources=0;
	$is_skip_new_dvds=0;
	$feed_options=@unserialize($feed['options']);
	if (is_array($feed_options))
	{
		$is_skip_new_categories=intval($feed_options['is_skip_new_categories']);
		$is_skip_new_models=intval($feed_options['is_skip_new_models']);
		$is_skip_new_content_sources=intval($feed_options['is_skip_new_content_sources']);
		$is_skip_new_dvds=intval($feed_options['is_skip_new_dvds']);
	}

	$categories_all=array();
	$temp=mr2array(sql_pr("select category_id, title, synonyms from $config[tables_prefix]categories"));
	foreach ($temp as $category)
	{
		$categories_all[mb_lowercase($category['title'])]=$category['category_id'];
		$temp_syn=explode(",",$category['synonyms']);
		if (is_array($temp_syn))
		{
			foreach ($temp_syn as $syn)
			{
				$syn=trim($syn);
				if (strlen($syn)>0)
				{
					$categories_all[mb_lowercase($syn)]=$category['category_id'];
				}
			}
		}
	}
	$models_all=array();
	$temp=mr2array(sql_pr("select model_id, title, alias from $config[tables_prefix]models"));
	foreach ($temp as $model)
	{
		$models_all[mb_lowercase($model['title'])]=$model['model_id'];
		$temp_syn=explode(",",$model['alias']);
		if (is_array($temp_syn))
		{
			foreach ($temp_syn as $syn)
			{
				$syn=trim($syn);
				if (strlen($syn)>0)
				{
					$models_all[mb_lowercase($syn)]=$model['model_id'];
				}
			}
		}
	}

	$formats_videos=mr2array(sql_pr("select format_video_id, postfix from $config[tables_prefix]formats_videos where status_id in (1,2)"));

	$configuration=array();
	if ($feed['feed_type_id']=='csv')
	{
		$configuration=unserialize($feed['csv_configuration']);
	}
	$configuration['feed_charset']=$feed['feed_charset'];
	$parse_func="$feed[feed_type_id]_parse_feed";
	$feed_result=$parse_func($feed['url'],$configuration);
	if ($feed['direction_id']==1)
	{
		$feed_result=array_reverse($feed_result);
	}
	log_feed($feed['feed_id'],1,"Feed parsed: ".count($feed_result)." items");

	$videos_added=0;
	$videos_skipped=0;
	$videos_errored=0;
	$videos_total=count($feed_result);
	$item=0;
	foreach ($feed_result as $video_rec)
	{
		if (@disk_free_space($config['project_path'])<$options['MAIN_SERVER_MIN_FREE_SPACE_MB']*1024*1024)
		{
			log_feed($feed['feed_id'],2,"Server free space is lower than $options[MAIN_SERVER_MIN_FREE_SPACE_MB]M, stopping feed");
			break;
		}
		$item++;
		if (intval($feed['max_videos_per_exec'])>0 && $videos_added>=$feed['max_videos_per_exec'])
		{
			break;
		}

		if ($video_rec['external_key']=='')
		{
			$videos_errored++;
			log_feed($feed['feed_id'],2,"Item $item: no external key");
			continue;
		}
		$video_rec['external_key']=md5($feed['key_prefix'].$video_rec['external_key']);
		if (intval($feed['is_skip_deleted_videos'])==1 && mr2number(sql_pr("select count(*) from $config[tables_prefix]videos_feeds_import_history where video_key=?",$video_rec['external_key']))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (exists in history)");
			}
			$videos_skipped++;
			continue;
		} elseif (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where external_key=?",$video_rec['external_key']))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (exists in database)");
			}
			$videos_skipped++;
			continue;
		}
		if ($video_rec['title']!='' && intval($feed['is_skip_duplicate_titles'])==1 && mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where title=?",$video_rec['title']))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (duplicate title)");
			}
			$videos_skipped++;
			continue;
		}
		if (intval($video_rec['id'])>0 && mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where video_id=?",intval($video_rec['id'])))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (duplicate ID)");
			}
			$videos_skipped++;
			continue;
		}
		if ($video_rec['title']=='' && intval($feed['videos_status_id'])==1)
		{
			$videos_errored++;
			log_feed($feed['feed_id'],2,"Item $item: no title");
			continue;
		}
		if ($feed['videos_adding_mode_id']<>4 && $feed['videos_adding_mode_id']<>5 && $feed['videos_adding_mode_id']<>6)
		{
			if (parse_duration($video_rec['duration'])==0)
			{
				if (@count($video_rec['video_files'])==0)
				{
					$videos_errored++;
					log_feed($feed['feed_id'],2,"Item $item: no duration");
					continue;
				}
			}
		}
		if ($feed['screenshots_mode_id']<>2)
		{
			if (@count($video_rec['screenshots'])==0)
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: no screenshots");
				continue;
			}

			$url_errors_count=0;
			$availability_errors_count=0;
			$total_urls_count=0;

			foreach ($video_rec['screenshots'] as $screenshot)
			{
				$screenshot=trim($screenshot);
				if ($screenshot=='') {continue;}

				$total_urls_count++;
				if (!is_url($screenshot))
				{
					if ($feed['is_debug_enabled']==1)
					{
						log_feed($feed['feed_id'],0,"Item $item: screenshot URL $screenshot is not valid");
					}
					$url_errors_count++;
				} else {
					if (!is_binary_file_url($screenshot))
					{
						if ($feed['is_debug_enabled']==1)
						{
							log_feed($feed['feed_id'],0,"Item $item: screenshot $screenshot is not available");
						}
						$availability_errors_count++;
					}
				}
			}

			if ($availability_errors_count+$url_errors_count>=$total_urls_count)
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: screenshot URLs are invalid or not available");
				continue;
			}
		}
		if ($feed['videos_adding_mode_id']==1 && $video_rec['embed_code']=='')
		{
			$videos_errored++;
			log_feed($feed['feed_id'],2,"Item $item: no embed code");
			continue;
		}
		if ($feed['videos_adding_mode_id']==2 || $feed['videos_adding_mode_id']==6)
		{
			if ($video_rec['website_link']=='')
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: no website link");
				continue;
			} elseif (!is_url($video_rec['website_link']))
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: website link URL $video_rec[website_link] is not valid");
				continue;
			} else {
				if ($feed['videos_adding_mode_id']==6)
				{
					$urls=parse_gallery($video_rec['website_link']);
					$video_rec['video_files']=array();
					foreach ($urls as $url)
					{
						$file_record=array();
						$file_record['url']=$url;
						$video_rec['video_files'][]=$file_record;
					}
				} else {
					if (!is_working_url($video_rec['website_link']))
					{
						$videos_errored++;
						log_feed($feed['feed_id'],2,"Item $item: website link $video_rec[website_link] is not available");
						continue;
					}
				}
			}
		}
		if ($feed['videos_adding_mode_id']==3 || $feed['videos_adding_mode_id']==4 || $feed['videos_adding_mode_id']==5 || $feed['videos_adding_mode_id']==6 || $feed['screenshots_mode_id']==2 || $feed['screenshots_mode_id']==3)
		{
			if (@count($video_rec['video_files'])==0)
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: no video files");
				continue;
			}
			foreach ($video_rec['video_files'] as $video_file)
			{
				if (!is_url($video_file['url']))
				{
					$videos_errored++;
					log_feed($feed['feed_id'],2,"Item $item: video file URL $video_file[url] is not valid");
					continue 2;
				} else {
					if (!is_binary_file_url($video_file['url']))
					{
						$videos_errored++;
						log_feed($feed['feed_id'],2,"Item $item: video file $video_file[url] is not available");
						continue 2;
					}
				}
			}
		}
		if ($feed['post_date_mode_id']==2 && $video_rec['post_date']=='')
		{
			$videos_errored++;
			log_feed($feed['feed_id'],2,"Item $item: no publishing date");
			continue;
		}

		$insert_data=array();

		$insert_data['dir']=trim($video_rec['dir']);
		$insert_data['description']=trim($video_rec['description']);
		$insert_data['user_id']=mr2number(sql_pr("select user_id from $config[tables_prefix]users where username=?",$options['DEFAULT_USER_IN_ADMIN_ADD_VIDEO']));
		$insert_data['rating']=(intval($video_rec['rating'])>0 ? intval($video_rec['rating']) : intval($options['VIDEO_INITIAL_RATING']));
		$insert_data['rating_amount']=1;
		$insert_data['video_viewed']=intval($video_rec['popularity']);
		$insert_data['release_year']=intval($video_rec['release_year']);
		$insert_data['status_id']=3;
		$insert_data['screen_main']=1;
		$insert_data['custom1']=trim($video_rec['custom1']);
		$insert_data['custom2']=trim($video_rec['custom2']);
		$insert_data['custom3']=trim($video_rec['custom3']);
		$insert_data['external_key']=$video_rec['external_key'];
		$insert_data['feed_id']=$feed['feed_id'];
		$insert_data['is_review_needed']=intval($feed['videos_is_review_needed']);
		$insert_data['is_private']=intval($feed['videos_is_private']);

		$videos_per_dates=array();
		if ($feed['post_date_mode_id']==3 || $feed['post_date_mode_id']==4)
		{
			if ($feed['post_date_mode_id']==3)
			{
				$min_date=date("Y-m-d",time()+86400);
				$max_date=date("Y-m-d",time()+intval($feed['end_date_offset']+1)*86400);
			} else
			{
				$min_date=date("Y-m-d",strtotime($feed['start_date_interval']));
				$max_date=date("Y-m-d",strtotime($feed['end_date_interval'])+86400);
			}
			$res=mr2array(sql_pr("select date_format(post_date,'%Y-%m-%d') as period, count(*) as cnt from $config[tables_prefix]videos where post_date>='$min_date' and post_date<'$max_date' group by date_format(post_date,'%Y-%m-%d')"));
			foreach ($res as $res_item)
			{
				$videos_per_dates[$res_item['period']]=intval($res_item['cnt']);
			}
		}

		$base_post_date=time();
		if ($feed['post_date_mode_id']==2)
		{
			$base_post_date=strtotime($video_rec['post_date']);
		} elseif ($feed['post_date_mode_id']==3)
		{
			$is_distributed=0;
			for ($it=1;$it<=intval($feed['end_date_offset']);$it++)
			{
				$date=date("Y-m-d",time()+86400*$it);
				if (intval($videos_per_dates[$date])<$feed['max_videos_per_day'])
				{
					$base_post_date=strtotime($date);
					$is_distributed=1;
					break;
				}
			}
			if ($is_distributed==0)
			{
				if ($feed['is_debug_enabled']==1)
				{
					log_feed($feed['feed_id'],0,"Item $item: skipped (no publishing date slot)");
				}
				$videos_skipped++;
				continue;
			}
		} elseif ($feed['post_date_mode_id']==4)
		{
			$min_date=strtotime($feed['start_date_interval']);
			$max_date=strtotime($feed['end_date_interval']);
			$days=ceil(($max_date-$min_date)/86400);
			$is_distributed=0;
			for ($it=0;$it<$days*10;$it++)
			{
				$date=date("Y-m-d",$min_date+86400*mt_rand(0,$days));
				if (intval($feed['max_videos_per_day'])>0)
				{
					if (intval($videos_per_dates[$date])>=$feed['max_videos_per_day'])
					{
						continue;
					}
				}
				$base_post_date=strtotime($date);
				$is_distributed=1;
				break;
			}
			if ($is_distributed==0)
			{
				if ($feed['is_debug_enabled']==1)
				{
					log_feed($feed['feed_id'],0,"Item $item: skipped (no publishing date slot)");
				}
				$videos_skipped++;
				continue;
			}
		}
		if ($options['USE_POST_DATE_RANDOMIZATION']=='0')
		{
			$insert_data['post_date']=date("Y-m-d 00:00:00",$base_post_date);
		} elseif ($options['USE_POST_DATE_RANDOMIZATION']=='1')
		{
			$insert_data['post_date']=date("Y-m-d H:i:s",strtotime(date("Y-m-d 00:00:00",$base_post_date))+mt_rand(0,86399));
		} elseif ($options['USE_POST_DATE_RANDOMIZATION']=='2')
		{
			$insert_data['post_date']=date("Y-m-d H:i:s",strtotime(date("Y-m-d",$base_post_date)." ".date("H:i:s")));
		}
		$insert_data['last_time_view_date']=date("Y-m-d H:i:s");

		$videos_count=1;
		if ($feed['videos_adding_mode_id']==1)
		{
			$insert_data['load_type_id']=3;
			$insert_data['embed']=process_embed_code(trim($video_rec['embed_code']));
			if (@count($video_rec['video_files'])>0)
			{
				$insert_data['file_url']=trim($video_rec['video_files'][0]['url']);
			}
		} elseif ($feed['videos_adding_mode_id']==2)
		{
			$insert_data['load_type_id']=5;
			$insert_data['pseudo_url']=trim($video_rec['website_link']);
			if (@count($video_rec['video_files'])>0)
			{
				$insert_data['file_url']=trim($video_rec['video_files'][0]['url']);
			}
		} elseif ($feed['videos_adding_mode_id']==3)
		{
			$insert_data['load_type_id']=2;
			$videos_count=count($video_rec['video_files']);
		} elseif ($feed['videos_adding_mode_id']==4)
		{
			$insert_data['load_type_id']=1;
			$videos_count=count($video_rec['video_files']);
		} elseif ($feed['videos_adding_mode_id']==5)
		{
			$insert_data['load_type_id']=1;
		} elseif ($feed['videos_adding_mode_id']==6)
		{
			$insert_data['load_type_id']=4;
			$insert_data['gallery_url']=$video_rec['website_link'];
		}
		if ($video_rec['website_link']!='')
		{
			$insert_data['gallery_url']=$video_rec['website_link'];
		}

		if ($feed['limit_duration_from']>0 || $feed['limit_duration_to']>0)
		{
			for ($v=0;$v<$videos_count;$v++)
			{
				if ($videos_count==1)
				{
					$video_duration=parse_duration($video_rec['duration']);
				} else {
					$video_duration=parse_duration($video_rec['video_files'][$v]['duration']);
				}
				if ($feed['limit_duration_from']>0 && $video_duration<$feed['limit_duration_from'])
				{
					if ($feed['is_debug_enabled']==1)
					{
						log_feed($feed['feed_id'],0,"Item $item: skipped (duration filter)");
					}
					$videos_skipped++;
					continue 2;
				}
				if ($feed['limit_duration_to']>0 && $video_duration>$feed['limit_duration_to'])
				{
					if ($feed['is_debug_enabled']==1)
					{
						log_feed($feed['feed_id'],0,"Item $item: skipped (duration filter)");
					}
					$videos_skipped++;
					continue 2;
				}
			}
		}

		$list_separator=",";
		if ($configuration['separator_list_items']!='')
		{
			$list_separator=$configuration['separator_list_items'];
		}

		$category_ids=array();
		if ($video_rec['categories']<>'')
		{
			$value_temp=explode($list_separator,$video_rec['categories']);
			$inserted_categories=array();
			foreach ($value_temp as $cat_title)
			{
				$cat_title=trim($cat_title);
				if ($cat_title=='') {continue;}
				if (in_array(mb_lowercase($cat_title),$inserted_categories)) {continue;}

				if ($categories_all[mb_lowercase($cat_title)]>0)
				{
					$cat_id=$categories_all[mb_lowercase($cat_title)];
				} else {
					$cat_id=mr2number(sql_pr("select category_id from $config[tables_prefix]categories where title=?",$cat_title));
					if ($cat_id==0 && !$is_skip_new_categories)
					{
						$cat_dir=get_correct_dir_name($cat_title);
						$temp_dir=$cat_dir;
						for ($it=2;$it<99999;$it++)
						{
							if (mr2number(sql_pr("select count(*) from $config[tables_prefix]categories where dir=?",$temp_dir))==0)
							{
								$cat_dir=$temp_dir;break;
							}
							$temp_dir=$cat_dir.$it;
						}
						$cat_id=sql_insert("insert into $config[tables_prefix]categories set title=?, dir=?, added_date=?",$cat_title,$cat_dir,date("Y-m-d H:i:s"));
						sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=6, added_date=?",$feed['feed_id'],$feed['title'],$cat_id,date("Y-m-d H:i:s"));
					}
					if ($cat_id>0)
					{
						$categories_all[mb_lowercase($cat_title)]=$cat_id;
					}
				}
				if ($cat_id>0)
				{
					$inserted_categories[]=mb_lowercase($cat_title);
					$category_ids[]=$cat_id;
				}
			}
		}

		$model_ids=array();
		if ($video_rec['models']<>'')
		{
			$value_temp=explode($list_separator,$video_rec['models']);
			$inserted_models=array();
			foreach ($value_temp as $model_title)
			{
				$model_title=trim($model_title);
				if ($model_title=='') {continue;}
				if (in_array(mb_lowercase($model_title),$inserted_models)) {continue;}

				if ($models_all[mb_lowercase($model_title)]>0)
				{
					$model_id=$models_all[mb_lowercase($model_title)];
				} else {
					$model_id=mr2number(sql_pr("select model_id from $config[tables_prefix]models where title=?",$model_title));
					if ($model_id==0 && !$is_skip_new_models)
					{
						$model_dir=get_correct_dir_name($model_title);
						$temp_dir=$model_dir;
						for ($it=2;$it<99999;$it++)
						{
							if (mr2number(sql_pr("select count(*) from $config[tables_prefix]models where dir=?",$temp_dir))==0)
							{
								$model_dir=$temp_dir;break;
							}
							$temp_dir=$model_dir.$it;
						}
						$model_id=sql_insert("insert into $config[tables_prefix]models set title=?, dir=?, rating_amount=1, added_date=?",$model_title,$model_dir,date("Y-m-d H:i:s"));
						sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=4, added_date=?",$feed['feed_id'],$feed['title'],$model_id,date("Y-m-d H:i:s"));
					}
					if ($model_id>0)
					{
						$models_all[mb_lowercase($model_title)]=$model_id;
					}
				}
				if ($model_id>0)
				{
					$inserted_models[]=mb_lowercase($model_title);
					$model_ids[]=$model_id;
				}
			}
		}

		$tag_ids=array();
		if ($video_rec['tags']<>'')
		{
			$value_temp=explode($list_separator,$video_rec['tags']);
			$inserted_tags=array();
			foreach ($value_temp as $tag_title)
			{
				$tag_title=trim($tag_title);
				if ($tag_title=='') {continue;}
				if (in_array(mb_lowercase($tag_title),$inserted_tags)) {continue;}

				$tag_id = find_or_create_tag($tag_title, $options);
				if ($tag_id > 0)
				{
					$inserted_tags[]=mb_lowercase($tag_title);
					$tag_ids[]=$tag_id;
				}
			}
		}

		if ($video_rec['user']<>'')
		{
			$user_id=mr2number(sql_pr("select user_id from $config[tables_prefix]users where username=?",$video_rec['user']));
			if ($user_id==0)
			{
				$email=$video_rec['user'];
				if (!preg_match($regexp_check_email,$email))
				{
					$email=generate_email($video_rec['user']);
				}
				$user_id=sql_insert("insert into $config[tables_prefix]users set username=?, status_id=2, display_name=?, email=?, added_date=?",$video_rec['user'],$video_rec['user'],$email,date("Y-m-d H:i:s"));
			}
			$insert_data['user_id']=$user_id;
		}

		if ($feed['videos_content_source_id']>0)
		{
			$insert_data['content_source_id']=$feed['videos_content_source_id'];
		} elseif ($video_rec['content_source']<>'')
		{
			$insert_data['content_source_id']=mr2number(sql_pr("select content_source_id from $config[tables_prefix]content_sources where title=?",$video_rec['content_source']));
			if ($insert_data['content_source_id']==0 && !$is_skip_new_content_sources)
			{
				$cs_dir=get_correct_dir_name($video_rec['content_source']);
				$temp_dir=$cs_dir;
				for ($it=2;$it<999999;$it++)
				{
					if (mr2number(sql_pr("select count(*) from $config[tables_prefix]content_sources where dir=?",$temp_dir))==0)
					{
						$cs_dir=$temp_dir;break;
					}
					$temp_dir=$cs_dir.$it;
				}
				$insert_data['content_source_id']=sql_insert("insert into $config[tables_prefix]content_sources set title=?, dir=?, url=?, rating_amount=1, added_date=?",$video_rec['content_source'],$cs_dir,trim($video_rec['content_source_url']),date("Y-m-d H:i:s"));
				sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=3, added_date=?",$feed['feed_id'],$feed['title'],$insert_data['content_source_id'],date("Y-m-d H:i:s"));
			}
			if ($video_rec['content_source_group']<>'')
			{
				$content_source_group_id=mr2number(sql_pr("select content_source_group_id from $config[tables_prefix]content_sources_groups where title=?",$video_rec['content_source_group']));
				if ($content_source_group_id==0 && !$is_skip_new_content_sources)
				{
					$group_dir=get_correct_dir_name($video_rec['content_source_group']);
					$temp_dir=$group_dir;
					for ($it=2;$it<999999;$it++)
					{
						if (mr2number(sql_pr("select count(*) from $config[tables_prefix]content_sources_groups where dir=?",$temp_dir))==0)
						{
							$group_dir=$temp_dir;break;
						}
						$temp_dir=$group_dir.$it;
					}
					$content_source_group_id=sql_insert("insert into $config[tables_prefix]content_sources_groups set title=?, dir=?, added_date=?",$video_rec['content_source_group'],$group_dir,date("Y-m-d H:i:s"));
					sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=8, added_date=?",$feed['feed_id'],$feed['title'],$content_source_group_id,date("Y-m-d H:i:s"));
				}
				if (mr2number(sql_pr("select content_source_group_id from $config[tables_prefix]content_sources where content_source_id=?",$insert_data['content_source_id']))==0)
				{
					sql_pr("update $config[tables_prefix]content_sources set content_source_group_id=? where content_source_id=?",$content_source_group_id,$insert_data['content_source_id']);
				}
			}
		}

		if ($feed['videos_dvd_id']>0)
		{
			$insert_data['dvd_id']=$feed['videos_dvd_id'];
		} elseif ($video_rec['dvd']<>'')
		{
			$insert_data['dvd_id']=mr2number(sql_pr("select dvd_id from $config[tables_prefix]dvds where title=?",$video_rec['dvd']));
			if ($insert_data['dvd_id']==0 && !$is_skip_new_dvds)
			{
				$dvd_dir=get_correct_dir_name($video_rec['dvd']);
				$temp_dir=$dvd_dir;
				for ($it=2;$it<999999;$it++)
				{
					if (mr2number(sql_pr("select count(*) from $config[tables_prefix]dvds where dir=?",$temp_dir))==0)
					{
						$dvd_dir=$temp_dir;break;
					}
					$temp_dir=$dvd_dir.$it;
				}
				$insert_data['dvd_id']=sql_insert("insert into $config[tables_prefix]dvds set title=?, dir=?, rating_amount=1, added_date=?",$video_rec['dvd'],$dvd_dir,date("Y-m-d H:i:s"));
				sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=5, added_date=?",$feed['feed_id'],$feed['title'],$insert_data['dvd_id'],date("Y-m-d H:i:s"));
			}
		}

		if ($feed['title_limit']>0)
		{
			$video_rec['title']=truncate_text($video_rec['title'],$feed['title_limit'],$feed['title_limit_type_id']);
		}
		foreach ($languages as $language)
		{
			if ($video_rec["title_$language[code]"]!='')
			{
				if ($feed['title_limit']>0)
				{
					$video_rec["title_$language[code]"]=truncate_text($video_rec["title_$language[code]"],$feed['title_limit'],$feed['title_limit_type_id']);
				}
				$insert_data["title_$language[code]"]=$video_rec["title_$language[code]"];
			}
			if ($video_rec["description_$language[code]"]!='')
			{
				$insert_data["description_$language[code]"]=$video_rec["description_$language[code]"];
			}
			if ($video_rec["dir_$language[code]"]!='')
			{
				$insert_data["dir_$language[code]"]=$video_rec["dir_$language[code]"];
			}
		}

		if (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where external_key=?",$video_rec['external_key']))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (exists in database)");
			}
			$videos_skipped++;
			continue;
		}
		if ($video_rec['title']!='' && intval($feed['is_skip_duplicate_titles'])==1 && mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where title=?",$video_rec['title']))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (duplicate title)");
			}
			$videos_skipped++;
			continue;
		}
		if (intval($video_rec['id'])>0 && mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where video_id=?",intval($video_rec['id'])))>0)
		{
			if ($feed['is_debug_enabled']==1)
			{
				log_feed($feed['feed_id'],0,"Item $item: skipped (duplicate ID)");
			}
			$videos_skipped++;
			continue;
		}

		for ($v=0;$v<$videos_count;$v++)
		{
			if ($videos_count==1)
			{
				$insert_data['title']=$video_rec['title'];
				$insert_data['duration']=parse_duration($video_rec['duration']);
				$screenshots=$video_rec['screenshots'];
			} else {
				if (intval($video_rec['id'])>0)
				{
					$videos_errored++;
					log_feed($feed['feed_id'],2,"Item $item: not possible to specify video ID and import multiple videos");
					continue 2;
				}
				$insert_data['title']=$video_rec['title'].' '.str_replace('%N%',$v+1,$feed['title_postfix']);
				$insert_data['duration']=parse_duration($video_rec['video_files'][$v]['duration']);
				$screenshots=$video_rec['video_files'][$v]['screenshots'];
			}
			if ($insert_data['load_type_id']==2)
			{
				$insert_data['file_url']=$video_rec['video_files'][$v]['url'];
			}

			if ($insert_data['title']!='' && $insert_data['dir']=='')
			{
				$dir=get_correct_dir_name($insert_data['title']);
				$temp_dir=$dir;
				for ($it=2;$it<99999;$it++)
				{
					if (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where dir=?",$temp_dir))==0)
					{
						$dir=$temp_dir;break;
					}
					$temp_dir=$dir.$it;
				}
				$insert_data['dir']=$dir;
			}
			foreach ($languages as $language)
			{
				if ($insert_data["title_$language[code]"]!='' && $insert_data["dir_$language[code]"]=='')
				{
					$dir=get_correct_dir_name($insert_data["title_$language[code]"],$language);
					$temp_dir=$dir;
					for ($it=2;$it<99999;$it++)
					{
						if (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where dir_$language[code]=?",$temp_dir))==0)
						{
							$dir=$temp_dir;break;
						}
						$temp_dir=$dir.$it;
					}
					$insert_data["dir_$language[code]"]=$dir;
				}
			}

			if (intval($video_rec['id'])>0)
			{
				if (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos where video_id=?",intval($video_rec['id'])))>0)
				{
					$videos_errored++;
					log_feed($feed['feed_id'],2,"Item $item: video with ID $video_rec[id] already exists");
					continue 2;
				} else
				{
					$insert_data['video_id']=intval($video_rec['id']);
				}
			}

			$insert_data['added_date']=date("Y-m-d H:i:s");
			$item_id=sql_insert("insert into $config[tables_prefix]videos set ?%",$insert_data);

			if ($item_id==0)
			{
				$videos_errored++;
				log_feed($feed['feed_id'],2,"Item $item: failed to insert new video");
				continue 2;
			}

			$tag_ids=array_unique($tag_ids);
			foreach ($tag_ids as $tag_id)
			{
				sql_pr("insert into $config[tables_prefix]tags_videos set tag_id=?, video_id=?",$tag_id,$item_id);
			}
			$category_ids=array_unique($category_ids);
			foreach ($category_ids as $category_id)
			{
				sql_pr("insert into $config[tables_prefix]categories_videos set category_id=?, video_id=?",$category_id,$item_id);
			}
			$model_ids=array_unique($model_ids);
			foreach ($model_ids as $model_id)
			{
				sql_pr("insert into $config[tables_prefix]models_videos set model_id=?, video_id=?",$model_id,$item_id);
			}

			$dir_path=get_dir_by_id($item_id);
			if ($feed['screenshots_mode_id']==1)
			{
				if (!is_dir("$config[content_path_videos_sources]/$dir_path")) {mkdir("$config[content_path_videos_sources]/$dir_path",0777);chmod("$config[content_path_videos_sources]/$dir_path",0777);}
				if (!is_dir("$config[content_path_videos_sources]/$dir_path/$item_id")) {mkdir("$config[content_path_videos_sources]/$dir_path/$item_id",0777);chmod("$config[content_path_videos_sources]/$dir_path/$item_id",0777);}

				if (count($screenshots)>0)
				{
					mkdir("$config[content_path_videos_sources]/$dir_path/$item_id/temp",0777);
					chmod("$config[content_path_videos_sources]/$dir_path/$item_id/temp",0777);
					$zip_files_to_add=array();
					$zip_index=1;
					foreach ($screenshots as $screen_url)
					{
						$screen_url=trim($screen_url);
						if ($screen_url=='') {continue;}
						save_file_from_url(trim($screen_url),"$config[content_path_videos_sources]/$dir_path/$item_id/temp/$zip_index.jpg","",20);

						$img_size=getimagesize("$config[content_path_videos_sources]/$dir_path/$item_id/temp/$zip_index.jpg");
						if ($img_size[0]>0 && $img_size[1]>0)
						{
							$zip_files_to_add[]="$config[content_path_videos_sources]/$dir_path/$item_id/temp/$zip_index.jpg";
							$zip_index++;
						} else {
							@unlink("$config[content_path_videos_sources]/$dir_path/$item_id/temp/$zip_index.jpg");
						}
					}
					$zip = new PclZip("$config[content_path_videos_sources]/$dir_path/$item_id/$item_id.zip");
					$zip->create($zip_files_to_add,$p_add_dir="",$p_remove_dir="$config[content_path_videos_sources]/$dir_path/$item_id/temp");
					rmdir_recursive("$config[content_path_videos_sources]/$dir_path/$item_id/temp");
				}
			} elseif ($feed['screenshots_mode_id']==3)
			{
				if (!is_dir("$config[content_path_videos_sources]/$dir_path")) {mkdir("$config[content_path_videos_sources]/$dir_path",0777);chmod("$config[content_path_videos_sources]/$dir_path",0777);}
				if (!is_dir("$config[content_path_videos_sources]/$dir_path/$item_id")) {mkdir("$config[content_path_videos_sources]/$dir_path/$item_id",0777);chmod("$config[content_path_videos_sources]/$dir_path/$item_id",0777);}

				if (count($screenshots)>0)
				{
					save_file_from_url(trim($screenshots[0]),"$config[content_path_videos_sources]/$dir_path/$item_id/$item_id.jpg","",20);
				}
			}

			if (mr2number(sql_pr("select count(*) from $config[tables_prefix]videos_feeds_import_history where video_key=?",$video_rec['external_key']))==0)
			{
				sql_pr("insert into $config[tables_prefix]videos_feeds_import_history set video_key=?, feed_id=?, added_date=?",$video_rec['external_key'],$feed['feed_id'],date("Y-m-d H:i:s"));
			}

			$background_task=array();
			$background_task['status_id']=intval($feed['videos_status_id']);
			$background_task['duration']=$insert_data['duration'];
			if ($insert_data['file_url']<>'')
			{
				$background_task['video_url']=$insert_data['file_url'];
			}
			if (intval($video_rec['screen_main'])>1)
			{
				$background_task['screen_main']=intval($video_rec['screen_main']);
			}

			if ($insert_data['load_type_id']==1 || $insert_data['load_type_id']==4)
			{
				if (!is_dir("$config[content_path_videos_sources]/$dir_path")) {mkdir("$config[content_path_videos_sources]/$dir_path",0777);chmod("$config[content_path_videos_sources]/$dir_path",0777);}
				if (!is_dir("$config[content_path_videos_sources]/$dir_path/$item_id")) {mkdir("$config[content_path_videos_sources]/$dir_path/$item_id",0777);chmod("$config[content_path_videos_sources]/$dir_path/$item_id",0777);}

				if ($videos_count==1 && count($video_rec['video_files'])>1)
				{
					$background_task['sources']=array();
					$counter=0;
					foreach ($video_rec['video_files'] as $video_file)
					{
						$counter++;
						if ($feed['is_debug_enabled']==1)
						{
							log_feed($feed['feed_id'],0,"Item $item: started loading remote file $video_file[url]");
						}
						save_file_from_url($video_file['url'],"$config[content_path_videos_sources]/$dir_path/$item_id/{$item_id}_part{$counter}.tmp","");
						$filesize=sprintf("%.0f",filesize("$config[content_path_videos_sources]/$dir_path/$item_id/{$item_id}_part{$counter}.tmp"));
						if ($filesize<1024)
						{
							log_feed($feed['feed_id'],2,"Item $item: video file $video_file[url] has size $filesize");
							continue 3;
						} else {
							if ($feed['is_debug_enabled']==1)
							{
								log_feed($feed['feed_id'],0,"Item $item: finished loading remote file ($filesize bytes)");
							}
						}
						$background_task['sources'][]="{$item_id}_part{$counter}.tmp";
					}
				} else {
					$source_file="$item_id.tmp";
					foreach($formats_videos as $format)
					{
						if ($feed['format_video_id']==$format['format_video_id'])
						{
							$source_file="$item_id{$format['postfix']}";
							break;
						}
					}
					if ($feed['is_debug_enabled']==1)
					{
						log_feed($feed['feed_id'],0,"Item $item: started loading remote file ".$video_rec['video_files'][$v]['url']);
					}
					save_file_from_url($video_rec['video_files'][$v]['url'],"$config[content_path_videos_sources]/$dir_path/$item_id/$source_file","");
					$filesize=sprintf("%.0f",filesize("$config[content_path_videos_sources]/$dir_path/$item_id/$source_file"));
					if ($filesize<1024)
					{
						log_feed($feed['feed_id'],2,"Item $item: video file ".$video_rec['video_files'][$v]['url']." has size $filesize");
						continue 2;
					} else {
						if ($feed['is_debug_enabled']==1)
						{
							log_feed($feed['feed_id'],0,"Item $item: finished loading remote file ($filesize bytes)");
						}
					}
					$background_task['source']="$source_file";
				}
			}
			if ($insert_data['load_type_id']==4)
			{
				unset($background_task['duration']);
			}

			sql_pr("insert into $config[tables_prefix]background_tasks set status_id=0, type_id=1, video_id=?, data=?, added_date=?",$item_id,serialize($background_task),date("Y-m-d H:i:s"));
			sql_pr("insert into $config[tables_prefix]users_events set event_type_id=1, user_id=?, video_id=?, added_date=?",$insert_data['user_id'],$item_id,$insert_data['post_date']);
			sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=120, object_id=?, object_type_id=1, added_date=?",$feed['feed_id'],$feed['title'],$item_id,date("Y-m-d H:i:s"));
		}

		$videos_added++;
		usleep(50000);
	}

	$exec_time=time()-$start_time;

	log_feed($feed['feed_id'],1,"Finished feed \"$feed[title]\" in $exec_time seconds with $videos_added videos added, $videos_skipped videos skipped and $videos_errored errors from $videos_total videos available");
}

function parse_duration($str)
{
	if (strlen(trim($str))==0)
	{
		return 0;
	}
	$regex1="|^([0-9]+)h([0-9]+)m([0-9]+)s$|is";
	$regex2="|^([0-9]+)m([0-9]+)s$|is";
	if (preg_match($regex1,$str,$temp))
	{
		return intval($temp[1])*3600+intval($temp[2])*60+intval($temp[3]);
	} elseif (preg_match($regex2,$str,$temp))
	{
		return intval($temp[1])*60+intval($temp[2]);
	} elseif (strpos($str,":")!==false)
	{
		$temp=explode(":",$str);
		if (count($temp)==3)
		{
			return intval($temp[0])*3600+intval($temp[1])*60+intval($temp[2]);
		} else {
			return intval($temp[0])*60+intval($temp[1]);
		}
	} else {
		return intval($str);
	}
}

function log_feed($feed_id,$message_type,$message_text,$message_details='')
{
	global $config;

	sql_pr("insert into $config[tables_prefix]feeds_log set feed_id=?, message_type=?, message_text=?, message_details=?, added_date=?",$feed_id,$message_type,$message_text,$message_details,date("Y-m-d H:i:s"));
}
<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once("../include/setup.php");
require_once("../include/setup_smarty.php");
require_once("../include/functions_base.php");
require_once("../include/functions.php");
require_once("../include/check_access.php");

header("Content-Type: text/xml; charset=utf-8");

$sortings = array(
	array(
		'id' => "alphabet",
		'title' => $lang['common']['insight_sort_by_alphabet'],
		'value' => "tag asc"
	),
	array(
		'id' => "most_used",
		'title' => $lang['common']['insight_sort_by_most_used'],
		'value' => "(total_videos + total_albums + total_posts) desc"
	),
	array(
		'id' => "least_used",
		'title' => $lang['common']['insight_sort_by_least_used'],
		'value' => "(total_videos + total_albums + total_posts) asc"
	)
);
$sort_by = $_SESSION['save']['insight_tags.php']['sort_by'];
if (isset($_REQUEST['sort_by']))
{
	$sort_by = $_REQUEST['sort_by'];
	$_SESSION['save']['insight_tags.php']['sort_by'] = $sort_by;
}
$applied_sorting = null;
foreach ($sortings as $sorting)
{
	if ($sorting['id'] == $sort_by)
	{
		$applied_sorting = $sorting;
		break;
	}
}
if (!$applied_sorting)
{
	$applied_sorting = $sortings[0];
}

if (isset($_REQUEST['full_list']))
{
	$smarty = new mysmarty();
	$smarty->assign('lang', $lang);
	$smarty->assign('data', mr2array(sql("select tag as id, tag as title from $config[tables_prefix]tags order by $applied_sorting[value]")));
	$smarty->assign('sortings', $sortings);
	$smarty->assign('selected_sorting', $applied_sorting['id']);
	$smarty->display("insight_list.tpl");
} else {
	$result_for = $_REQUEST['for'];
	$result_for=str_replace("&","&amp;",$result_for);
	$result_for=str_replace(">","&gt;",$result_for);
	$result_for=str_replace("<","&lt;",$result_for);
	if (strlen($_REQUEST['for'])>1)
	{
		echo "<insight for=\"$result_for\">\n";
		$q=sql_escape($_REQUEST['for']);
		$data=mr2array(sql("select tag, synonyms from $config[tables_prefix]tags where tag like '%$q%' or synonyms like '%$q%' order by $applied_sorting[value]"));
		foreach ($data as $item)
		{
			$tag=str_replace("&","&amp;",$item['tag']);
			$tag=str_replace(">","&gt;",$tag);
			$tag=str_replace("<","&lt;",$tag);

			$synonyms = $item['synonyms'];
			$matched_synonyms = array_map('trim', explode(',', $synonyms));
			foreach ($matched_synonyms as $key => $synonym)
			{
				if (!mb_contains($synonym, $_REQUEST['for']))
				{
					unset($matched_synonyms[$key]);
				}
			}
			$synonyms = implode(', ', $matched_synonyms);
			if ($synonyms != '')
			{
				$synonyms = str_replace("&", "&amp;", $synonyms);
				$synonyms = str_replace(">", "&gt;", $synonyms);
				$synonyms = str_replace("<", "&lt;", $synonyms);
				$synonyms = str_replace("\"", "&quot;", $synonyms);

				echo "<value synonyms=\"$synonyms\">$tag</value>\n";
			} else
			{
				echo "<value>$tag</value>\n";
			}
		}
		echo "</insight>";
	} else {
		echo "<insight for=\"$result_for\"></insight>";
	}
}

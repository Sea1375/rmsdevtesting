<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
if (!isset($config))
{
	require_once 'setup.php';
	$display_errors = 1;
}
require_once 'functions_base.php';

$file = $_REQUEST['url'];
$hash = $_REQUEST['filename'];
if (preg_match('/^([0-9A-Za-z]{32})$/', $hash))
{
	$file_upload_data = unserialize(file_get_contents("$config[project_path]/admin/data/system/file_upload_params.dat"), ['allowed_classes' => false]);
	if ($file_upload_data['FILE_UPLOAD_URL_OPTION'] != 'public')
	{
		session_start();
		if ($file_upload_data['FILE_UPLOAD_URL_OPTION'] == 'admins' && intval($_SESSION['userdata']['user_id']) < 1)
		{
			header('HTTP/1.0 403 Forbidden');
			die;
		}
		if (intval($_SESSION['userdata']['user_id']) < 1)
		{
			if ($file_upload_data['FILE_UPLOAD_URL_OPTION'] == 'members' && intval($_SESSION['user_id']) < 1)
			{
				header('HTTP/1.0 403 Forbidden');
				die;
			}
		}
	}

	session_write_close();

	if ($file <> '' && $hash <> '')
	{
		$wget_path = $config['wget_path'];
		if ($wget_path == '' || $wget_path == 'disabled')
		{
			$wget_path = 'wget';
		}
		exec("$wget_path -h", $res);
		if (strpos(implode("\n", $res), 'no-use-server-timestamps') !== false)
		{
			upload_remote_file_wget($wget_path, $file, $hash);
		} else
		{
			upload_remote_file($file, $hash);
		}
	}
} elseif ($display_errors == 1)
{
	echo 'Filename is not accepted';
}

function upload_remote_file($file, $hash)
{
	global $config, $file_upload_data;

	$file = str_replace(" ", "%20", $file);
	if (strpos($file, 'www.') === 0)
	{
		$file = "http://$file";
	}

	$code = str_replace("\n", " ", get_page('', $file, '', '', 0, 1, 50, ''));
	preg_match("|.*Location:\ *(.+?)\ |is", $code, $temp);
	$page_url = trim($temp[1]);
	if ($page_url <> '')
	{
		$file = $page_url;
	}

	$path = parse_url($file);

	$fs = fsockopen($path['host'], $path['port'] <> '' ? $path['port'] : '80');
	if ($fs)
	{
		fwrite($fs, "GET $path[path]" . ($path['query'] ? "?$path[query]" : '') . " HTTP/1.0\r\n");
		fwrite($fs, "Host: $path[host]\r\n");
		fwrite($fs, "\r\n");
		$headers = fread($fs, 4096);

		preg_match("|.*Location:\ *(.+?)\\n|is", $headers, $temp);
		$page_url = trim($temp[1]);
		if ($page_url <> '')
		{
			upload_remote_file($page_url, $hash);
		}

		preg_match('/Content-Length: ([0-9]+)/', $headers, $temp);
		$length = sprintf("%.0f", $temp[1]);

		preg_match("|Content-Disposition[^;]*?;\ *filename\ *=\ *['\"]*(.*?)['\"]*(\r?\n)|is", $headers, $temp);
		$filename = trim($temp[1]);
		if ($filename == '')
		{
			$filename = pathinfo($file, PATHINFO_BASENAME);
		}
		if (strpos($filename, "?") !== false)
		{
			$filename = substr($filename, 0, strpos($filename, "?"));
		}
		$filename = urldecode($filename);
		$filename = str_replace("&", "&amp;", $filename);

		$last_dot_pos = strrpos($filename, '.');
		if ($last_dot_pos !== false)
		{
			$ext = substr($filename, $last_dot_pos + 1);
			$filename = str_replace('.', '_', substr($filename, 0, $last_dot_pos));
			$filename = "$filename.$ext";
		}

		preg_match("|HTTP/\d+\.\d+\ +(\d{3})\ +|is", $headers, $temp);
		$response = intval($temp[1]);

		if ($length > 1 && $filename <> '' && $response >= 200 && $response < 300)
		{
			if (intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) > 0 && $length > intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) * 1024 * 1024)
			{
				file_put_contents("$config[temporary_path]/$hash.status", "<status><error>ktfudc_filesize_error</error></status>", LOCK_EX);

				return;
			}

			preg_match('|\r\n\r\n(.+)|is', $headers, $temp);
			$content = $temp[1];

			$total_read = strlen($content);
			$fh = fopen("$config[temporary_path]/$hash.tmp", "w");
			fwrite($fh, $content);
			while ($tmp = fread($fs, 10240))
			{
				$total_read += strlen($tmp);
				if ($total_read > $length)
				{
					$total_read = $length;
				}

				fwrite($fh, $tmp);
				fflush($fh);

				file_put_contents("$config[temporary_path]/$hash.status", "<status><filename>$filename</filename><loaded>$total_read</loaded><total>$length</total></status>", LOCK_EX);
			}
			fclose($fh);

			file_put_contents("$config[temporary_path]/$hash.status", "<status><filename>$filename</filename><loaded>$length</loaded><total>$length</total></status>", LOCK_EX);
		} else
		{
			file_put_contents("$config[temporary_path]/$hash.status", "<status><error>ktfudc_url_error</error></status>", LOCK_EX);
		}
	} else
	{
		file_put_contents("$config[temporary_path]/$hash.status", "<status><error>ktfudc_url_error</error></status>", LOCK_EX);
	}
}

function upload_remote_file_wget($wget_path, $file, $hash)
{
	global $config, $file_upload_data;

	$file = str_replace(" ", "%20", $file);

	$headers = get_page("", $file, "", "", 0, 1, 20, "");
	unset($temp);
	preg_match('/Content-Length: ([0-9]+)/', $headers, $temp);
	$length = sprintf("%.0f", $temp[1]);

	if ($length > 1)
	{
		if (intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) > 0 && $length > intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) * 1024 * 1024)
		{
			file_put_contents("$config[temporary_path]/$hash.status", "<status><error>ktfudc_filesize_error</error></status>", LOCK_EX);
			return;
		}
	}

	$limit_rate_options = '';
	if (intval($file_upload_data['FILE_DOWNLOAD_SPEED_LIMIT']) > 0)
	{
		$limit_rate_options = '--limit-rate ' . intval($file_upload_data['FILE_DOWNLOAD_SPEED_LIMIT'] / 8) . 'k';
	}

	unset($temp);
	file_put_contents("$config[temporary_path]/{$hash}_wget_log.txt", "$file\n", LOCK_EX);
	exec("$wget_path $limit_rate_options --timeout 60 --no-use-server-timestamps --no-check-certificate --server-response -O $config[temporary_path]/$hash.tmp -a $config[temporary_path]/{$hash}_wget_log.txt -b " . escapeshellarg($file), $temp);

	$temp = implode("\n", $temp);
	if (strpos($temp, "in background") !== false)
	{
		for ($i = 0; $i < 1000; $i++)
		{
			if (@is_file("$config[temporary_path]/{$hash}_wget_log.txt"))
			{
				$wget_log = file_get_contents("$config[temporary_path]/{$hash}_wget_log.txt");
				if (strpos($wget_log, 'ERROR 4') !== false || strpos($wget_log, 'ERROR 5') !== false || strpos($wget_log, 'unable to resolve host address') !== false)
				{
					return;
				}

				if (strpos($wget_log, ".tmp' saved "))
				{
					return;
				}
				$wget_log = strrev($wget_log);
				unset($temp);
				preg_match('/%([0-9]+)/', $wget_log, $temp);
				if (intval(strrev($temp[1])) == 100)
				{
					return;
				}
			} elseif ($i > 100)
			{
				return;
			}
			sleep(1);
		}
	}
}

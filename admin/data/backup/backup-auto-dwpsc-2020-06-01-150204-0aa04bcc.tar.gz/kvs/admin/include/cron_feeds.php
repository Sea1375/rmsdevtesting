<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

if ($_SERVER['DOCUMENT_ROOT']<>'')
{
	// under web
	session_start();
	if ($_SESSION['userdata']['user_id']<1)
	{
		header("HTTP/1.0 403 Forbidden");
		die('Access denied');
	}
	header("Content-Type: text/plain; charset=utf8");
}

require_once("setup.php");
require_once("functions_base.php");
require_once("functions_admin.php");
require_once("functions.php");
require_once("pclzip.lib.php");

ini_set('display_errors',1);

$feeds_to_execute=array();
$feeds=mr2array(sql("select * from $config[tables_prefix]videos_feeds_import where status_id=1"));
foreach ($feeds as $feed)
{
	if ($feed['last_exec_date']=='0000-00-00 00:00:00')
	{
		log_output("INFO  Feed \"$feed[title]\" will be executed now");
		$feeds_to_execute[]=$feed;
	} elseif (strtotime($feed['last_exec_date'])+$feed['exec_interval_hours']*3600+$feed['exec_interval_minutes']*60-60<time())
	{
		log_output("INFO  Feed \"$feed[title]\" will be executed now");
		$feeds_to_execute[]=$feed;
	} else {
		$ttw=strtotime($feed['last_exec_date'])+$feed['exec_interval_hours']*3600+$feed['exec_interval_minutes']*60-time();
		log_output("INFO  Feed \"$feed[title]\" will be executed in $ttw seconds");
	}
}

if (count($feeds_to_execute)==0)
{
	die('No feeds to process now');
}

log_output("INFO  Feeds processor started");

foreach ($feeds_to_execute as $feed)
{
	exec("$config[php_path] $config[project_path]/admin/background_feed_videos.php $feed[feed_id] > /dev/null &");
	log_output("INFO  Started feed $feed[feed_id]");
}

log_output("INFO  Feeds processor finished");

function log_output($message)
{
	if ($message=='')
	{
		echo "\n";
	} else {
		echo date("[Y-m-d H:i:s] ").$message."\n";
	}
}

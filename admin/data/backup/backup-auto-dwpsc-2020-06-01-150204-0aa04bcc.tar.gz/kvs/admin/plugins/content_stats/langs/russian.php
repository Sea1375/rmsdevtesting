<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

$lang['plugins']['content_stats']['title']          = "Статистика контента";
$lang['plugins']['content_stats']['description']    = "Показывает суммарную статистику по объему контента.";
$lang['plugins']['content_stats']['long_desc']      = "
		Этот плагин отображает суммарную статистику по всем видео и альбомам с группировкой по форматам. Таким образом,
		вы сможете увидеть, сколько дискового пространства освободится в случае удаления того или иного формата.
";
$lang['permissions']['plugins|content_stats']  = $lang['plugins']['content_stats']['title'];

$lang['plugins']['content_stats']['dg_results_col_type']                            = "Тип";
$lang['plugins']['content_stats']['dg_results_col_type_video_sources']              = "Исходные файлы видео";
$lang['plugins']['content_stats']['dg_results_col_type_video_formats']              = "Формат видео \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_video_timelines']            = "Формат видео \"%1%\" (таймлайновые скриншоты)";
$lang['plugins']['content_stats']['dg_results_col_type_video_logs']                 = "Логи обработки видео";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_sources']        = "Исходные файлы скриншотов";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_formats']        = "Формат скриншотов \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_zip']            = "Формат скриншотов \"%1%\" (ZIP архивы)";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_sources']       = "Исходные файлы альбомов";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_formats']       = "Формат альбомов \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_zip']           = "Формат альбомов \"%1%\" (ZIP архивы)";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_sources_zip']   = "Исходные файлы альбомов (ZIP архивы)";
$lang['plugins']['content_stats']['dg_results_col_type_album_logs']                 = "Логи обработки альбомов";
$lang['plugins']['content_stats']['dg_results_col_type_total']                      = "Всего";
$lang['plugins']['content_stats']['dg_results_col_storage']                         = "Место хранения";
$lang['plugins']['content_stats']['dg_results_col_storage_local']                   = "Главный сервер";
$lang['plugins']['content_stats']['dg_results_col_storage_content']                 = "Контентные сервера";
$lang['plugins']['content_stats']['dg_results_col_files']                           = "Файлов";
$lang['plugins']['content_stats']['dg_results_col_size']                            = "Размер";
$lang['plugins']['content_stats']['btn_calculate']                                  = "Рассчитать";

<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

function content_statsInit()
{
	global $config;

	if (!is_dir("$config[project_path]/admin/data/plugins"))
	{
		mkdir("$config[project_path]/admin/data/plugins",0777);chmod("$config[project_path]/admin/data/plugins",0777);
	}
	$plugin_path="$config[project_path]/admin/data/plugins/content_stats";
	if (!is_dir($plugin_path))
	{
		mkdir($plugin_path,0777);chmod($plugin_path,0777);
	}
}

function content_statsShow()
{
	global $config,$page_name;

	content_statsInit();
	$plugin_path="$config[project_path]/admin/data/plugins/content_stats";

	if ($_GET['action']=='progress')
	{
		$task_id=intval($_GET['task_id']);
		$pc=intval(@file_get_contents("$plugin_path/task-progress-$task_id.dat"));
		header("Content-Type: text/xml");

		$location='';
		if ($pc==100)
		{
			$location="<location>plugins.php?plugin_id=content_stats&amp;action=results&amp;task_id=$task_id</location>";
			@unlink("$plugin_path/task-progress-$task_id.dat");
		}
		echo "<progress-status><percents>$pc</percents>$location</progress-status>"; die;
	} elseif ($_POST['action']=='calculate')
	{
		$rnd=mt_rand(10000000,99999999);
		exec("$config[php_path] $config[project_path]/admin/plugins/content_stats/content_stats.php $rnd > /dev/null &");
		return_ajax_success("$page_name?plugin_id=content_stats&amp;action=progress&amp;task_id=$rnd&amp;rand=\${rand}",2);
	}

	if (intval($_GET['task_id'])>0 && is_file("$plugin_path/task-".intval($_GET['task_id']).".dat"))
	{
		$_POST=@unserialize(@file_get_contents("$plugin_path/task-".intval($_GET['task_id']).".dat"));
	}

	if (!is_writable("$plugin_path"))
	{
		$_POST['errors'][]=bb_code_process(get_aa_error('filesystem_permission_write',str_replace("//","/","$plugin_path")));
	}
}

$task_id=intval($_SERVER['argv'][1]);

if ($task_id>0 && $_SERVER['DOCUMENT_ROOT']=='')
{
	require_once('include/setup.php');
	require_once('include/functions_base.php');
	require_once('include/functions.php');

	$plugin_path="$config[project_path]/admin/data/plugins/content_stats";

	$result=array();

	$videos_result=sql("select video_id, file_formats, screen_amount from $config[tables_prefix]videos where status_id in (0,1)");
	$albums_result=sql("select album_id, zip_files from $config[tables_prefix]albums where zip_files<>'' and status_id in (0,1)");
	$images_result=sql("select album_id, image_formats from $config[tables_prefix]albums_images where image_formats<>'' and album_id in (select album_id from $config[tables_prefix]albums where status_id in (0,1))");

	$formats_screenshots=mr2array(sql("select title, size, group_id from $config[tables_prefix]formats_screenshots where status_id=1"));
	$formats_videos=mr2array(sql("select title, postfix, timeline_directory from $config[tables_prefix]formats_videos where status_id in (1,2)"));
	$formats_albums=mr2array(sql("select title, size from $config[tables_prefix]formats_albums where status_id=1 and group_id=1"));

	$temp=array();
	foreach ($formats_videos as $format)
	{
		$temp[$format['postfix']]=$format;
	}
	$formats_videos=$temp;

	$temp=array();
	foreach ($formats_albums as $format)
	{
		$temp[$format['size']]=$format;
	}
	$formats_albums=$temp;

	$done_amount_of_work=0;
	$total_amount_of_work=mr2rows($videos_result)+mr2rows($albums_result)+mr2rows($images_result);
	$last_pc=0;

	while ($video = mr2array_single($videos_result))
	{
		$video_id=$video['video_id'];
		$dir_path=get_dir_by_id($video_id);

		if (is_file("$config[content_path_videos_sources]/$dir_path/$video_id/$video_id.tmp"))
		{
			$key="video_sources";
			if (!$result[$key])
			{
				$result[$key]=array('type'=>'video_sources','storage'=>'main_server','size'=>0,'files'=>0);
			}
			$result[$key]['size']+=0+sprintf("%.0f",filesize("$config[content_path_videos_sources]/$dir_path/$video_id/$video_id.tmp"));
			$result[$key]['files']++;
		}

		if ($video['file_formats']!='')
		{
			$video_formats=get_video_formats($video_id,$video['file_formats']);
			foreach ($video_formats as $format_data)
			{
				$postfix=$format_data['postfix'];
				$title=$formats_videos[$postfix]['title'];
				$timeline_directory=$formats_videos[$postfix]['timeline_directory'];

				$key="video_format[$postfix]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'video_formats','format'=>$title,'storage'=>'content_server','size'=>0,'files'=>0);
				}
				$result[$key]['size']+=0+sprintf("%.0f",$format_data['file_size']);
				$result[$key]['files']++;

				if ($format_data['timeline_screen_amount']>0 && $timeline_directory<>'')
				{
					$key="video_timelines[$postfix]";
					if (!$result[$key])
					{
						$result[$key]=array('type'=>'video_timelines','format'=>$title,'storage'=>'main_server','size'=>0,'files'=>0);
					}
					for ($i=1;$i<=$format_data['timeline_screen_amount'];$i++)
					{
						$result[$key]['size']+=filesize("$config[content_path_videos_sources]/$dir_path/$video_id/timelines/$timeline_directory/$i.jpg");
						$result[$key]['files']++;
					}
					foreach ($formats_screenshots as $format_screenshots)
					{
						if ($format_screenshots['group_id']==2)
						{
							for ($i=1;$i<=$format_data['timeline_screen_amount'];$i++)
							{
								$result[$key]['size']+=filesize("$config[content_path_videos_screenshots]/$dir_path/$video_id/timelines/$timeline_directory/$format_screenshots[size]/$i.jpg");
								$result[$key]['files']++;
							}
							if (is_file("$config[content_path_videos_screenshots]/$dir_path/$video_id/timelines/$timeline_directory/$format_screenshots[size]/$video_id-$format_screenshots[size].zip"))
							{
								$result[$key]['size']+=filesize("$config[content_path_videos_screenshots]/$dir_path/$video_id/timelines/$timeline_directory/$format_screenshots[size]/$video_id-$format_screenshots[size].zip");
								$result[$key]['files']++;
							}
						}
					}
				}
			}
		}

		$key="video_screenshots[source]";
		if (!$result[$key])
		{
			$result[$key]=array('type'=>'video_screenshots_sources','storage'=>'main_server','size'=>0,'files'=>0);
		}
		for ($i=1;$i<=$video['screen_amount'];$i++)
		{
			$result[$key]['size']+=filesize("$config[content_path_videos_sources]/$dir_path/$video_id/screenshots/$i.jpg");
			$result[$key]['files']++;
		}
		foreach ($formats_screenshots as $format_screenshots)
		{
			if ($format_screenshots['group_id']==1)
			{
				$key="video_screenshots[$format_screenshots[size]]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'video_screenshots_formats','format'=>$format_screenshots['title'],'storage'=>'main_server','size'=>0,'files'=>0);
				}
				for ($i=1;$i<=$video['screen_amount'];$i++)
				{
					$result[$key]['size']+=filesize("$config[content_path_videos_screenshots]/$dir_path/$video_id/$format_screenshots[size]/$i.jpg");
					$result[$key]['files']++;
				}

				if (is_file("$config[content_path_videos_screenshots]/$dir_path/$video_id/$format_screenshots[size]/$video_id-$format_screenshots[size].zip"))
				{
					$key="video_screenshots_zip[$format_screenshots[size]]";
					if (!$result[$key])
					{
						$result[$key]=array('type'=>'video_screenshots_zip','format'=>$format_screenshots['title'],'storage'=>'main_server','size'=>0,'files'=>0);
					}
					$result[$key]['size']+=filesize("$config[content_path_videos_screenshots]/$dir_path/$video_id/$format_screenshots[size]/$video_id-$format_screenshots[size].zip");
					$result[$key]['files']++;
				}
			}
		}

		$done_amount_of_work++;
		$pc=floor(($done_amount_of_work/$total_amount_of_work)*100);
		if ($pc>$last_pc)
		{
			file_put_contents("$plugin_path/task-progress-$task_id.dat","$pc",LOCK_EX);
			$last_pc=$pc;
		}
		usleep(2000);
	}

	unset($res);
	exec("du -b $config[project_path]/admin/logs/videos",$res);
	$size=intval(trim($res[0]));
	unset($res);
	exec("ls $config[project_path]/admin/logs/videos | wc -l",$res);
	$count=intval(trim($res[0]));
	$result["video_logs"]=array('type'=>'video_logs','storage'=>'main_server','size'=>$size,'files'=>$count);

	while ($image = mr2array_single($images_result))
	{
		$album_id=$image['album_id'];
		$image_formats=get_image_formats($album_id,$image['image_formats']);
		foreach ($image_formats as $format_data)
		{
			if ($format_data['size']=='source')
			{
				$key="album_images[$format_data[size]]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'album_images_sources','storage'=>'content_server','size'=>0,'files'=>0);
				}
			} else {
				$key="album_images[$format_data[size]]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'album_images_formats','format'=>$formats_albums[$format_data['size']]['title'],'storage'=>'content_server','size'=>0,'files'=>0);
				}
			}
			$result[$key]['size']+=$format_data['file_size'];
			$result[$key]['files']++;
		}

		$done_amount_of_work++;
		$pc=floor(($done_amount_of_work/$total_amount_of_work)*100);
		if ($pc>$last_pc)
		{
			file_put_contents("$plugin_path/task-progress-$task_id.dat","$pc",LOCK_EX);
			$last_pc=$pc;
		}
	}

	while ($album = mr2array_single($albums_result))
	{
		$album_id=$album['album_id'];
		$zip_files=get_album_zip_files($album_id,$album['zip_files']);
		foreach ($zip_files as $zip_file)
		{
			if ($zip_file['size']=='source')
			{
				$key="album_images_zip[$zip_file[size]]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'album_images_sources_zip','storage'=>'content_server','size'=>0,'files'=>0);
				}
			} else {
				$key="album_images_zip[$zip_file[size]]";
				if (!$result[$key])
				{
					$result[$key]=array('type'=>'album_images_zip','format'=>$formats_albums[$zip_file['size']]['title'],'storage'=>'content_server','size'=>0,'files'=>0);
				}
			}
			$result[$key]['size']+=$zip_file['file_size'];
			$result[$key]['files']++;
		}

		$done_amount_of_work++;
		$pc=floor(($done_amount_of_work/$total_amount_of_work)*100);
		if ($pc>$last_pc)
		{
			file_put_contents("$plugin_path/task-progress-$task_id.dat","$pc",LOCK_EX);
			$last_pc=$pc;
		}
	}

	unset($res);
	exec("du -b $config[project_path]/admin/logs/albums",$res);
	$size=intval(trim($res[0]));
	unset($res);
	exec("ls $config[project_path]/admin/logs/albums | wc -l",$res);
	$count=intval(trim($res[0]));
	$result["album_logs"]=array('type'=>'album_logs','storage'=>'main_server','size'=>$size,'files'=>$count);

	$total_main=array('type'=>'total_main','storage'=>'main_server','size'=>0,'files'=>0);
	$total_content=array('type'=>'total_content','storage'=>'content_server','size'=>0,'files'=>0);
	foreach ($result as $k=>$v)
	{
		if ($v['storage']=='main_server')
		{
			$total_main['size']+=$v['size'];
			$total_main['files']+=$v['files'];
		}
		if ($v['storage']=='content_server')
		{
			$total_content['size']+=$v['size'];
			$total_content['files']+=$v['files'];
		}
		$result[$k]['size']=sizeToHumanString($v['size'],2);
	}
	$total_main['size']=sizeToHumanString($total_main['size'],2);
	$total_content['size']=sizeToHumanString($total_content['size'],2);
	$result[]=$total_main;
	$result[]=$total_content;

	file_put_contents("$plugin_path/task-progress-$task_id.dat","100");
	file_put_contents("$plugin_path/task-$task_id.dat",serialize($result));
}

if ($_SERVER['argv'][1]=='test' && $_SERVER['DOCUMENT_ROOT']=='') {echo "OK";}

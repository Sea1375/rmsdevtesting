<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

$lang['plugins']['content_stats']['title']          = "Content stats";
$lang['plugins']['content_stats']['description']    = "Provides summary disk stats for all your content.";
$lang['plugins']['content_stats']['long_desc']      = "
		This plugin displays summary stats for all videos and photo albums, grouped by their formats. Thus you can see
		how much space will be released if you drop off this or that format.
";
$lang['permissions']['plugins|content_stats']  = $lang['plugins']['content_stats']['title'];

$lang['plugins']['content_stats']['dg_results_col_type']                            = "Type";
$lang['plugins']['content_stats']['dg_results_col_type_video_sources']              = "Video source files";
$lang['plugins']['content_stats']['dg_results_col_type_video_formats']              = "Video format \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_video_timelines']            = "Video format \"%1%\" (timelines)";
$lang['plugins']['content_stats']['dg_results_col_type_video_logs']                 = "Video processing logs";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_sources']        = "Screenshots source files";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_formats']        = "Screenshots format \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_screenshots_zip']            = "Screenshots format \"%1%\" (ZIP files)";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_sources']       = "Album source files";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_formats']       = "Album format \"%1%\"";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_zip']           = "Album format \"%1%\" (ZIP files)";
$lang['plugins']['content_stats']['dg_results_col_type_album_images_sources_zip']   = "Album source files (ZIP files)";
$lang['plugins']['content_stats']['dg_results_col_type_album_logs']                 = "Album processing logs";
$lang['plugins']['content_stats']['dg_results_col_type_total']                      = "Total";
$lang['plugins']['content_stats']['dg_results_col_storage']                         = "Storage";
$lang['plugins']['content_stats']['dg_results_col_storage_local']                   = "Main server";
$lang['plugins']['content_stats']['dg_results_col_storage_content']                 = "Content servers";
$lang['plugins']['content_stats']['dg_results_col_files']                           = "Files";
$lang['plugins']['content_stats']['dg_results_col_size']                            = "Size";
$lang['plugins']['content_stats']['btn_calculate']                                  = "Calculate";

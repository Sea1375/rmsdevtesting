<?php
/* © Kernel Video Sharing
   https://kernel-video-sharing.com
*/

$event_str = trim($_REQUEST['event']);
if ($event_str)
{
	require_once '../admin/include/setup.php';

	if ($event_str == 'FirstPlay')
	{
		$video_id = intval($_REQUEST['video_id']);
		if ($video_id > 0)
		{
			file_put_contents("$config[project_path]/admin/data/stats/video_plays.dat", date("Y-m-d") . "|$video_id\n", FILE_APPEND | LOCK_EX);
		}
	} else
	{
		$is_embed = 0;
		if (trim($_REQUEST['embed']) == 'true' || trim($_REQUEST['embed']) == '1')
		{
			$is_embed = 1;
		}
		$event_str = str_replace(',', '|', $event_str);

		file_put_contents("$config[project_path]/admin/data/stats/player.dat", date("Y-m-d") . "|$is_embed|$event_str|$_SERVER[GEOIP_COUNTRY_CODE]|$_COOKIE[kt_referer]|$_COOKIE[kt_qparams]\n", FILE_APPEND | LOCK_EX);
	}
}

header("Content-type: image/gif");
echo base64_decode('R0lGODlhAQABAJAAAP8AAAAAACH5BAUQAAAALAAAAAABAAEAAAICBAEAOw==');
<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

// =====================================================================================================================
// invite_friend messages
// =====================================================================================================================

$lang['invite_friend']['block_short_desc'] = "Предоставляет функционал для отправки email приглашения другу на сайт";

$lang['invite_friend']['block_desc'] = "
	Блок предоставляет возможность отправить письмо другу с приглашением и ссылкой на сайт.
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_forms']}
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_error_codes']}
	[kt|br][kt|br]

	[kt|code]
	- [kt|b]email_required[/kt|b]: когда поле email не заполнено [поле = email][kt|br]
	- [kt|b]email_invalid[/kt|b]: когда в поле email введен некорректный формат адреса [поле = email][kt|br]
	- [kt|b]message_required[/kt|b]: когда поле сообщения не заполнено [поле = message][kt|br]
	- [kt|b]code_required[/kt|b]: когда решение визуальной защиты не заполнено [поле = code][kt|br]
	- [kt|b]code_invalid[/kt|b]: когда решение визуальной защиты не корректно [поле = code][kt|br]
	[/kt|code]
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_caching_no']}
";

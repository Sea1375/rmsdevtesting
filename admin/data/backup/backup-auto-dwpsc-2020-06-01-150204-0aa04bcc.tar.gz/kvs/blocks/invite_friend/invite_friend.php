<?php
function invite_friendShow($block_config,$object_id)
{
	global $config,$smarty,$storage,$regexp_check_email,$page_id;

	$errors=null;
	$errors_async=null;

	if ($_POST['action']=='send')
	{
		$email=trim($_POST['email']);
		$message=trim($_POST['message']);
		$code=trim($_POST['code']);
		$recaptcha_response=trim($_POST['g-recaptcha-response']);

		if (strlen($email)==0)
		{
			$errors['email']=1;
			$errors_async[]=array('error_field_name'=>'email','error_code'=>'required','block'=>'invite_friend');
		} elseif (!preg_match($regexp_check_email,$email))
		{
			$errors['email']=2;
			$errors_async[]=array('error_field_name'=>'email','error_code'=>'invalid','block'=>'invite_friend');
		}

		if (strlen($message)==0)
		{
			$errors['message']=1;
			$errors_async[]=array('error_field_name'=>'message','error_code'=>'required','block'=>'invite_friend');
		}

		$recaptcha_data=null;
		if (is_file("$config[project_path]/admin/data/plugins/recaptcha/enabled.dat") && is_file("$config[project_path]/admin/data/plugins/recaptcha/data.dat"))
		{
			$recaptcha_data = @unserialize(file_get_contents("$config[project_path]/admin/data/plugins/recaptcha/data.dat"));
		}
		if (is_array($recaptcha_data) && $recaptcha_data['site_key'])
		{
			if (strlen($recaptcha_response)==0)
			{
				$errors['code']=1;
				$errors_async[]=array('error_field_name'=>'code','error_code'=>'required','block'=>'invite_friend');
			} elseif (!validate_recaptcha($recaptcha_response, $recaptcha_data))
			{
				$errors['code']=2;
				$errors_async[]=array('error_field_name'=>'code','error_code'=>'invalid','block'=>'invite_friend');
			}
		} else
		{
			if (strlen($code)==0)
			{
				$errors['code']=1;
				$errors_async[]=array('error_field_name'=>'code','error_code'=>'required','block'=>'invite_friend');
			} elseif ($code<>$_SESSION['security_code_invite'] && $code<>$_SESSION['security_code'])
			{
				$errors['code']=2;
				$errors_async[]=array('error_field_name'=>'code','error_code'=>'invalid','block'=>'invite_friend');
			}
		}

		if (!is_array($errors))
		{
			$tokens = array(
				'{{$message}}'=>$message,
				'{{$project_name}}'=>$config['project_name'],
				'{{$support_email}}'=>$config['support_email'],
				'{{$project_licence_domain}}'=>$config['project_licence_domain']
			);
			$subject=file_get_contents("$config[project_path]/blocks/invite_friend/emails/subject.txt");
			$body=file_get_contents("$config[project_path]/blocks/invite_friend/emails/body.txt");
			$headers=file_get_contents("$config[project_path]/blocks/invite_friend/emails/headers.txt");
			send_mail($email,$subject,$body,$headers,$tokens);

			unset($_SESSION['security_code']);
			unset($_SESSION['security_code_invite']);
			if ($_POST['mode']=='async')
			{
				$smarty->assign('async_submit_successful','true');
				return '';
			} else {
				header("Location: ?action=send_done");die;
			}
		} elseif ($_POST['mode']=='async')
		{
			async_return_request_status($errors_async);
		}

		$smarty->assign('errors',$errors);
	}
	return '';
}

function invite_friendGetHash($block_config)
{
	return "nocache";
}

function invite_friendCacheControl($block_config)
{
	return "nocache";
}

function invite_friendMetaData()
{
	return array();
}

function invite_friendJavascript($block_config)
{
	global $config;

	return "KernelTeamVideoSharingForms.js?v={$config['project_version']}";
}

if ($_SERVER['argv'][1]=='test' && $_SERVER['DOCUMENT_ROOT']=='') {echo "OK";}

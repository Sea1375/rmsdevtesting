<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

require_once("admin/include/setup.php");

session_start();

if ($_SESSION['user_id'] > 0)
{
	$website_ui_data = @unserialize(file_get_contents("$config[project_path]/admin/data/system/website_ui_params.dat"));
	if ($website_ui_data['ENABLE_USER_ONLINE_STATUS_REFRESH'] == 1)
	{
		require_once("admin/include/functions_base.php");
		sql_pr("update $config[tables_prefix]users set last_online_date=? where user_id=?", date("Y-m-d H:i:s"), $_SESSION['user_id']);
	}
}

$domain = str_replace("www.", "", $_SERVER['HTTP_HOST']);
setcookie("kt_member", '', time() - 86400, "/", ".$domain");

unset($_SESSION['user_id']);
unset($_SESSION['status_id']);
unset($_SESSION['display_name']);
unset($_SESSION['last_login_date']);
unset($_SESSION['added_date']);
unset($_SESSION['avatar']);
unset($_SESSION['avatar_url']);
unset($_SESSION['cover']);
unset($_SESSION['cover_url']);
unset($_SESSION['username']);
unset($_SESSION['paid_access_hours_left']);
unset($_SESSION['paid_access_is_unlimited']);
unset($_SESSION['external_guid']);
unset($_SESSION['external_package_id']);
unset($_SESSION['unread_messages']);
unset($_SESSION['unread_invites']);
unset($_SESSION['unread_non_invites']);
unset($_SESSION['content_source_group_id']);
unset($_SESSION['is_trusted']);
unset($_SESSION['tokens_available']);
unset($_SESSION['birth_date']);
unset($_SESSION['age']);
unset($_SESSION['gender_id']);
unset($_SESSION['content_purchased']);
unset($_SESSION['content_purchased_amount']);
unset($_SESSION['playlists']);
unset($_SESSION['playlists_amount']);
unset($_SESSION['favourite_videos_summary']);
unset($_SESSION['favourite_videos_amount']);
unset($_SESSION['favourite_albums_summary']);
unset($_SESSION['favourite_albums_amount']);
unset($_SESSION['user_info']);
unset($_SESSION['subscriptions_amount']);

if (isset($_REQUEST["redirect_to"]))
{
	header("Location: $config[project_url]$_REQUEST[redirect_to]");
} else
{
	header("Location: $config[project_url]");
}

<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/

// =====================================================================================================================
// invite_friend messages
// =====================================================================================================================

$lang['invite_friend']['block_short_desc'] = "Provides friend invitation functionality";

$lang['invite_friend']['block_desc'] = "
	Block provides friend invitation functionality.
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_forms']}
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_error_codes']}
	[kt|br][kt|br]

	[kt|code]
	- [kt|b]email_required[/kt|b]: when email field is empty [field = email][kt|br]
	- [kt|b]email_invalid[/kt|b]: when email is not a valid address [field = email][kt|br]
	- [kt|b]message_required[/kt|b]: when message field is empty [field = message][kt|br]
	- [kt|b]code_required[/kt|b]: when captcha is not solved [field = code][kt|br]
	- [kt|b]code_invalid[/kt|b]: when captcha is solved incorrectly [field = code][kt|br]
	[/kt|code]
	[kt|br][kt|br]

	{$lang['website_ui']['block_desc_default_caching_no']}
";

<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once('include/setup.php');
require_once('include/setup_smarty.php');
require_once('include/functions_admin.php');
require_once('include/functions_base.php');
require_once('include/functions_screenshots.php');
require_once('include/functions.php');
require_once('include/check_access.php');
require_once('include/pclzip.lib.php');

$errors = null;

if ($_REQUEST['action']=='progress')
{
	$grabbing_id=intval($_REQUEST['grabbing_id']);
	$video_id=intval($_REQUEST['video_id']);
	$pc=@file_get_contents("$config[temporary_path]/grabbing-$grabbing_id/progress.dat");
	header("Content-Type: text/xml");

	if (strpos($pc,'error')!==false)
	{
		rmdir_recursive("$config[temporary_path]/grabbing-$grabbing_id");

		if ($pc=='error5')
		{
			$errors[]=get_aa_error('video_screenshot_grabbing_url');
		} elseif ($pc=='error8')
		{
			$errors[]=get_aa_error('video_screenshot_grabbing_storage_server');
		} elseif ($pc=='error11' || $pc=='error12')
		{
			$errors[]=get_aa_error('video_screenshot_grabbing_im');
		} elseif ($pc=='error13')
		{
			$errors[]=get_aa_error('video_screenshot_grabbing_ffmpeg');
		} else {
			$errors[]=get_aa_error('unexpected_error_detailed',$pc);
		}

		return_ajax_errors($errors);
	} elseif (intval($pc)==100)
	{
		$location="<location>videos_screenshots_grabbing.php?action=grabbing_complete&amp;item_id=$video_id&amp;grabbing_id=$grabbing_id</location>";
		rmdir_recursive("$config[temporary_path]/grabbing-$grabbing_id");
	}
	$pc=intval($pc);
	echo "<progress-status><percents>$pc</percents>$location</progress-status>"; die;
}

$item_id=intval($_REQUEST['item_id']);
if ($item_id<1) {header("Location: videos.php");die;}

unset($where);
if ($_SESSION['userdata']['is_access_to_own_content']==1)
{
	$admin_id=intval($_SESSION['userdata']['user_id']);
	$where.=" and admin_user_id=$admin_id ";
}
if ($_SESSION['userdata']['is_access_to_disabled_content']==1)
{
	$where.=" and status_id=0 ";
}

$result=sql("select * from $config[tables_prefix]videos where video_id=$item_id $where");
if (mr2rows($result)>0)
{
	$data_video=mr2array_single($result);
} else {
	header("Location: error.php?error=permission_denied");die;
}

$options=get_options();

$list_formats_videos=mr2array(sql("select * from $config[tables_prefix]formats_videos where status_id in (0,1,2)"));
$video_formats=get_video_formats($item_id,$data_video['file_formats']);
foreach($video_formats as $k=>$format_rec)
{
	foreach ($list_formats_videos as $format_video)
	{
		if ($format_video['postfix']==$format_rec['postfix'])
		{
			$video_formats[$k]['title']=$format_video['title'];
			$video_formats[$k]['format_video_id']=$format_video['format_video_id'];
		}
	}
}

$dir_path=get_dir_by_id($item_id);
if (is_file("$config[content_path_videos_sources]/$dir_path/$item_id/$item_id.tmp"))
{
	$source_file=array();
	$source_file['dimensions']=explode("x",$data_video['file_dimensions']);
	$source_file['duration_string']=durationToHumanString($data_video['duration']);
}

if ($_POST['action']=='save_screenshots')
{
	$data_amount=intval($_POST['data_amount']);
	$grabbing_id=intval($_POST['grabbing_id']);
	$screen_amount=$data_video['screen_amount'];

	if (is_file("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/rotator.dat"))
	{
		$rotator_data=@unserialize(file_get_contents("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/rotator.dat"));
		$rotator_data_changed=0;
	}
	$screenshots_changed=0;

	if (!is_dir("$config[content_path_videos_sources]/$dir_path")) {mkdir("$config[content_path_videos_sources]/$dir_path",0777);chmod("$config[content_path_videos_sources]/$dir_path",0777);}
	if (!is_dir("$config[content_path_videos_sources]/$dir_path/$item_id")) {mkdir("$config[content_path_videos_sources]/$dir_path/$item_id",0777);chmod("$config[content_path_videos_sources]/$dir_path/$item_id",0777);}
	if (!is_dir("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots")) {mkdir("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots",0777);chmod("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots",0777);}

	if (!is_dir("$config[content_path_videos_screenshots]/$dir_path")) {mkdir("$config[content_path_videos_screenshots]/$dir_path",0777);chmod("$config[content_path_videos_screenshots]/$dir_path",0777);}
	if (!is_dir("$config[content_path_videos_screenshots]/$dir_path/$item_id")) {mkdir("$config[content_path_videos_screenshots]/$dir_path/$item_id",0777);chmod("$config[content_path_videos_screenshots]/$dir_path/$item_id",0777);}

	$options['SCREENSHOTS_CROP_LEFT_UNIT']=1;
	$options['SCREENSHOTS_CROP_LEFT']=0;
	$options['SCREENSHOTS_CROP_RIGHT_UNIT']=1;
	$options['SCREENSHOTS_CROP_RIGHT']=0;
	$options['SCREENSHOTS_CROP_TOP_UNIT']=1;
	$options['SCREENSHOTS_CROP_TOP']=0;
	$options['SCREENSHOTS_CROP_BOTTOM_UNIT']=1;
	$options['SCREENSHOTS_CROP_BOTTOM']=0;

	log_video("",$item_id);
	log_video("INFO  Replacing overview screenshots by manual grabbing",$item_id);
	$list_formats_overview=mr2array(sql("select * from $config[tables_prefix]formats_screenshots where status_id=1 and group_id=1"));
	for ($i=0;$i<=$data_amount;$i++)
	{
		$is=$i+1;
		$it=intval($_POST["save_as_screenshot_$i"]);
		if ($it>0)
		{
			log_video("INFO  Replacing screenshot #{$it} with the grabbed one",$item_id);
			copy("$config[content_path_videos_screenshots]/temp/$grabbing_id/$is.jpg","$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/$it.jpg");
			foreach ($list_formats_overview as $format)
			{
				log_video("INFO  Creating screenshots for \"$format[title]\" format",$item_id);
				@unlink("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]/$it.jpg");

				if (!is_dir("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]")) {mkdir("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]",0777);chmod("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]",0777);}

				$exec_res=make_screen_from_source("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/$it.jpg","$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]/$it.jpg",$format,"");
				if ($exec_res!==false)
				{
					log_video("ERROR  IM operation failed: $exec_res",$item_id);
					log_video("ERROR  Error during screenshots creation for \"$format[title]\" format, stopping further processing",$item_id);
					$errors[]=get_aa_error('video_screenshot_format_error',$format['title']);
					return_ajax_errors($errors);
				}
			}
			if ($it==$data_video['screen_main'])
			{
				$video_formats=get_video_formats($item_id,$data_video['file_formats']);
				copy("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/$it.jpg","$config[content_path_videos_screenshots]/$dir_path/$item_id/preview.jpg");
				foreach($video_formats as $format)
				{
					resize_image('need_size_no_composite',"$config[content_path_videos_screenshots]/$dir_path/$item_id/preview.jpg","$config[content_path_videos_screenshots]/$dir_path/$item_id/preview{$format['postfix']}.jpg",$format['dimensions'][0].'x'.$format['dimensions'][1]);
				}
			}
			if (isset($rotator_data) && isset($rotator_data[$it]))
			{
				unset($rotator_data[$it]);
				$rotator_data_changed=1;
			}
			$screenshots_changed=1;
		} elseif ($_POST["save_as_screenshot_$i"]=='new')
		{
			$screen_amount++;
			$it=$screen_amount;
			log_video("INFO  Adding new screenshot #$it",$item_id);
			copy("$config[content_path_videos_screenshots]/temp/$grabbing_id/$is.jpg","$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/$it.jpg");
			foreach ($list_formats_overview as $format)
			{
				log_video("INFO  Creating screenshots for \"$format[title]\" format",$item_id);
				@unlink("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]/$it.jpg");

				if (!is_dir("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]")) {mkdir("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]",0777);chmod("$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]",0777);}

				$exec_res=make_screen_from_source("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/$it.jpg","$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]/$it.jpg",$format,"");
				if ($exec_res!==false)
				{
					log_video("ERROR  IM operation failed: $exec_res",$item_id);
					log_video("ERROR  Error during screenshots creation for \"$format[title]\" format, stopping further processing",$item_id);
					$errors[]=get_aa_error('video_screenshot_format_error',$format['title']);
					return_ajax_errors($errors);
				}
			}
			$screenshots_changed=1;
		}
	}
	if (isset($rotator_data) && $rotator_data_changed==1)
	{
		file_put_contents("$config[content_path_videos_sources]/$dir_path/$item_id/screenshots/rotator.dat", @serialize($rotator_data), LOCK_EX);
	}
	if ($screenshots_changed==1)
	{
		foreach ($list_formats_overview as $format)
		{
			if ($format['is_create_zip']==1)
			{
				log_video("INFO  Replacing screenshots ZIP for \"$format[title]\" format",$item_id);
				$source_folder="$config[content_path_videos_screenshots]/$dir_path/$item_id/$format[size]";
				@unlink("$source_folder/$item_id-$format[size].zip");

				$zip_files_to_add=array();
				for ($i=1;$i<=$screen_amount;$i++)
				{
					$zip_files_to_add[]="$source_folder/$i.jpg";
				}
				$zip = new PclZip("$source_folder/$item_id-$format[size].zip");
				$zip->create($zip_files_to_add,$p_add_dir="",$p_remove_dir="$source_folder");
			}
		}
		sql_pr("insert into $config[tables_prefix]admin_audit_log set user_id=?, username=?, action_id=151, object_id=?, object_type_id=1, added_date=?",$_SESSION['userdata']['user_id'],$_SESSION['userdata']['login'],$data_video['video_id'],date("Y-m-d H:i:s"));
	}
	if ($screen_amount<>$data_video['screen_amount'])
	{
		sql("update $config[tables_prefix]videos set screen_amount=$screen_amount where video_id=$item_id");
		$data_video['screen_amount']=$screen_amount;
	}
	log_video("INFO  Done screenshots changes",$item_id);
	return_ajax_success("videos_screenshots.php?item_id=$data_video[video_id]",1);
}

if ($_POST['action']=='start_grabbing')
{
	if (isset($_POST['source_file_id'])) {$_SESSION['save'][$page_name]['source_file_id']=intval($_POST['source_file_id']);}
	if (isset($_POST['method'])) {$_SESSION['save'][$page_name]['method']=intval($_POST['method']);}
	if (isset($_POST['interval'])) {$_SESSION['save'][$page_name]['interval']=intval($_POST['interval']);}
	if (isset($_POST['display_size'])) {$_SESSION['save'][$page_name]['display_size']=$_POST['display_size'];}
	if (isset($_POST['screenshots_crop_left'])) {$_SESSION['save'][$page_name]['screenshots_crop_left']=intval($_POST['screenshots_crop_left']);}
	if (isset($_POST['screenshots_crop_left_unit'])) {$_SESSION['save'][$page_name]['screenshots_crop_left_unit']=intval($_POST['screenshots_crop_left_unit']);}
	if (isset($_POST['screenshots_crop_top'])) {$_SESSION['save'][$page_name]['screenshots_crop_top']=intval($_POST['screenshots_crop_top']);}
	if (isset($_POST['screenshots_crop_top_unit'])) {$_SESSION['save'][$page_name]['screenshots_crop_top_unit']=intval($_POST['screenshots_crop_top_unit']);}
	if (isset($_POST['screenshots_crop_right'])) {$_SESSION['save'][$page_name]['screenshots_crop_right']=intval($_POST['screenshots_crop_right']);}
	if (isset($_POST['screenshots_crop_right_unit'])) {$_SESSION['save'][$page_name]['screenshots_crop_right_unit']=intval($_POST['screenshots_crop_right_unit']);}
	if (isset($_POST['screenshots_crop_bottom'])) {$_SESSION['save'][$page_name]['screenshots_crop_bottom']=intval($_POST['screenshots_crop_bottom']);}
	if (isset($_POST['screenshots_crop_bottom_unit'])) {$_SESSION['save'][$page_name]['screenshots_crop_bottom_unit']=intval($_POST['screenshots_crop_bottom_unit']);}
	if (isset($_POST['screenshots_offset'])) {$_SESSION['save'][$page_name]['screenshots_offset']=intval($_POST['screenshots_offset']);}

	$method = intval($_POST['method']);
	if ($method==2)
	{
		validate_field('empty_int',$_POST['interval'],$lang['videos']['screenshots_grabbing_field_method']);
	}
	if ($_POST['display_size']<>'')
	{
		validate_field('size',$_POST['display_size'],$lang['videos']['screenshots_grabbing_field_display_size']);
	}

	if (!is_array($errors))
	{
		$data=array();
		$data['method']=$method;
		$data['source_file_id']=intval($_POST['source_file_id']);
		$data['interval']=intval($_POST['interval']);
		$data['display_size']=$_POST['display_size'];
		$data['video_id']=$data_video['video_id'];
		$data['screenshots_crop_left']=intval($_POST['screenshots_crop_left']);
		$data['screenshots_crop_left_unit']=intval($_POST['screenshots_crop_left_unit']);
		$data['screenshots_crop_top']=intval($_POST['screenshots_crop_top']);
		$data['screenshots_crop_top_unit']=intval($_POST['screenshots_crop_top_unit']);
		$data['screenshots_crop_right']=intval($_POST['screenshots_crop_right']);
		$data['screenshots_crop_right_unit']=intval($_POST['screenshots_crop_right_unit']);
		$data['screenshots_crop_bottom']=intval($_POST['screenshots_crop_bottom']);
		$data['screenshots_crop_bottom_unit']=intval($_POST['screenshots_crop_bottom_unit']);
		$data['screenshots_offset']=intval($_POST['screenshots_offset']);
		$data['slow_method']=intval($_POST['slow_method']);

		$rnd=mt_rand(10000000,99999999);

		mkdir("$config[temporary_path]/grabbing-$rnd",0777);
		chmod("$config[temporary_path]/grabbing-$rnd",0777);
		$fp=fopen("$config[temporary_path]/grabbing-$rnd/task.dat","w+");
		fwrite($fp,@serialize($data));
		fclose($fp);

		exec("$config[php_path] $config[project_path]/admin/background_screenshots_grabbing.php $rnd > /dev/null &");
		return_ajax_success("$page_name?action=progress&amp;grabbing_id=$rnd&amp;video_id=$data_video[video_id]&amp;rand=\${rand}",2);
	} else {
		return_ajax_errors($errors);
	}
}

if ($_GET['action']=='grabbing_complete' && intval($_GET['item_id'])>0 && intval($_GET['grabbing_id'])>0)
{
	$item_id=intval($_GET['item_id']);
	$grabbing_id=intval($_GET['grabbing_id']);

	$image_size=array();
	$data=array();
	for ($i=1;$i<99999;$i++)
	{
		if (is_file("$config[content_path_videos_screenshots]/temp/$grabbing_id/{$i}r.jpg"))
		{
			if (isset($config['content_url_videos_screenshots_admin_panel']))
			{
				$data[]="$config[content_url_videos_screenshots_admin_panel]/temp/$grabbing_id/{$i}r.jpg";
			} else {
				$data[]="$config[content_url_videos_screenshots]/temp/$grabbing_id/{$i}r.jpg";
			}
			if ($image_size[0]<1)
			{
				$image_size=getimagesize("$config[content_path_videos_screenshots]/temp/$grabbing_id/{$i}r.jpg");
			}
		} elseif (is_file("$config[content_path_videos_screenshots]/temp/$grabbing_id/$i.jpg"))
		{
			if (isset($config['content_url_videos_screenshots_admin_panel']))
			{
				$data[]="$config[content_url_videos_screenshots_admin_panel]/temp/$grabbing_id/$i.jpg";
			} else {
				$data[]="$config[content_url_videos_screenshots]/temp/$grabbing_id/$i.jpg";
			}
			if ($image_size[0]<1)
			{
				$image_size=getimagesize("$config[content_path_videos_screenshots]/temp/$grabbing_id/$i.jpg");
			}
		} else {
			break;
		}
	}
}

$smarty=new mysmarty();
$smarty->assign('left_menu','menu_videos.tpl');
$smarty->assign('data_video',$data_video);
$smarty->assign('formats',$video_formats);
$smarty->assign('source_file',$source_file);
$smarty->assign('data_amount',count($data));

$smarty->assign('rnd',$rnd);
$smarty->assign('supports_popups',1);

$smarty->assign('data',$data);
$smarty->assign('lang',$lang);
$smarty->assign('config',$config);
$smarty->assign('page_name',$page_name);
$smarty->assign('list_messages',$list_messages);
$smarty->assign('template',str_replace(".php",".tpl",$page_name));

$smarty->assign('page_title',str_replace("%1%",($data_video['title']<>''?$data_video['title']:$data_video['video_id']),$lang['videos']['screenshots_header_grabbing']));

$smarty->display("layout.tpl");

<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once "setup.php";

$file_name = $_REQUEST['file'];
if (!preg_match('/^([0-9A-Za-z]{32})$/', $file_name))
{
	header('HTTP/1.0 403 Forbidden');
	die;
}

header("Content-Type: text/xml; charset=utf8");

if (is_file("$config[temporary_path]/$file_name.status"))
{
	$fhs = fopen("$config[temporary_path]/$file_name.status", "r+");
	flock($fhs, LOCK_EX);
	echo fread($fhs, 1000);
	flock($fhs, LOCK_UN);
	fclose($fhs);
} elseif (is_file("$config[temporary_path]/{$file_name}_wget_log.txt"))
{
	$wget_log = file_get_contents("$config[temporary_path]/{$file_name}_wget_log.txt");
	if (strpos($wget_log, 'ERROR 4') !== false || strpos($wget_log, 'ERROR 5') !== false || strpos($wget_log, 'unable to resolve host address') !== false)
	{
		echo "<status><error>ktfudc_url_error</error></status>";
		die;
	}

	unset($temp);
	preg_match("|Content-Disposition[^;]*?;\ *filename\ *=\ *['\"]*(.*?)['\"]*(\r?\n)|is", $wget_log, $temp);
	$filename = trim($temp[1]);
	if ($filename == '')
	{
		$filename = substr($wget_log, 0, strpos($wget_log, "\n"));
		$filename = pathinfo(trim($filename, '/'), PATHINFO_BASENAME);
		if (strpos($filename, '.') === false)
		{
			unset($temp);
			if (preg_match("|Location:\ *(.*?)\r?\n|is", $wget_log, $temp))
			{
				$filename = $temp[1];
				$filename = pathinfo(trim($filename, '/'), PATHINFO_BASENAME);
			}
		}
		if (strpos($filename, "?") !== false)
		{
			$filename = substr($filename, 0, strpos($filename, "?"));
		}
		$filename = urldecode($filename);
		$filename = str_replace("&", "&amp;", $filename);
	} else
	{
		$filename = preg_replace_callback('/\\\\[0-7]{3}/', function ($x) {
			return chr(octdec($x[0]));
		}, $filename);
	}

	$last_dot_pos = strrpos($filename, '.');
	if ($last_dot_pos !== false)
	{
		$ext = substr($filename, $last_dot_pos + 1);
		$filename = str_replace('.', '_', substr($filename, 0, $last_dot_pos));
		$filename = "$filename.$ext";
	}

	unset($temp);
	$total = 0;
	preg_match_all('/Length: ([0-9]+)/', $wget_log, $temp);
	settype($temp[1], "array");
	if (count($temp[1]) > 0)
	{
		foreach ($temp[1] as $v)
		{
			if (intval($v) > $total)
			{
				$total = intval($v);
			}
		}
	}
	if ($total > 0)
	{
		$loaded = 0;
		$wget_log = strrev($wget_log);
		unset($temp);
		preg_match('/%([0-9]+)/', $wget_log, $temp);
		if (intval(strrev($temp[1])) == 100)
		{
			$file_upload_data = unserialize(file_get_contents("$config[project_path]/admin/data/system/file_upload_params.dat"), ['allowed_classes' => false]);
			if (intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) > 0 && $total > intval($file_upload_data['FILE_UPLOAD_URL_LIMIT']) * 1024 * 1024)
			{
				echo "<status><error>ktfudc_filesize_error</error></status>";
				return;
			}
			echo "<status><filename>$filename</filename><loaded>$total</loaded><total>$total</total></status>";
		} else
		{
			unset($temp);
			preg_match('/K([0-9]+)/', $wget_log, $temp);
			if (intval(strrev($temp[1])) > 0)
			{
				$loaded = intval(strrev($temp[1])) * 1024;
			}
			echo "<status><filename>$filename</filename><loaded>$loaded</loaded><total>$total</total></status>";
		}
	} else
	{
		echo "<status><loaded>0</loaded><total>1</total></status>";
	}
} else
{
	echo "<status><loaded>0</loaded><total>1</total></status>";
}

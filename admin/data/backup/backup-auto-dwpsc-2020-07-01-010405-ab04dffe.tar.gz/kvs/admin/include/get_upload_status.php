<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once("setup.php");

$file_name = $_REQUEST['file'];
if (!preg_match('/^([0-9A-Za-z]{32})$/', $file_name))
{
	header('HTTP/1.0 403 Forbidden');
	die;
}

header("Content-Type: text/xml; charset=utf8");

if (is_file("$config[temporary_path]/$file_name.status"))
{
	echo file_get_contents("$config[temporary_path]/$file_name.status");
} else
{
	echo "<status><loaded>0</loaded><total>1</total></status>";
}

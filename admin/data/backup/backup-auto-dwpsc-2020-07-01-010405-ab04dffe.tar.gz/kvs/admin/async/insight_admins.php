<?php
/* Developed by Kernel Team.
   http://kernel-team.com
*/
require_once("../include/setup.php");
require_once("../include/setup_smarty.php");
require_once("../include/functions_base.php");
require_once("../include/functions.php");
require_once("../include/check_access.php");

header("Content-Type: text/xml; charset=utf-8");

if (isset($_REQUEST['full_list']))
{
	$smarty = new mysmarty();
	$smarty->assign('lang', $lang);
	if (in_array('system|administration', $_SESSION['permissions']))
	{
		$smarty->assign('data', mr2array(sql("select user_id as id, login as title from $config[tables_prefix]admin_users order by login asc")));
	} else
	{
		$smarty->assign('data', mr2array(sql_pr("select user_id as id, login as title from $config[tables_prefix]admin_users where login=?", $_SESSION['userdata']['login'])));
	}
	$smarty->display("insight_list.tpl");
} else
{
	$result_for = $_REQUEST['for'];
	$result_for = str_replace("&", "&amp;", $result_for);
	$result_for = str_replace(">", "&gt;", $result_for);
	$result_for = str_replace("<", "&lt;", $result_for);
	if (strlen($_REQUEST['for']) > 1)
	{
		echo "<insight for=\"$result_for\">\n";
		$q = sql_escape($_REQUEST['for']);
		if (in_array('system|administration', $_SESSION['permissions']))
		{
			$data = mr2array(sql("select user_id, login from $config[tables_prefix]admin_users where login like '%$q%' order by login asc"));
		} else
		{
			$data = mr2array(sql_pr("select user_id, login from $config[tables_prefix]admin_users where login like '%$q%' and login=?", $_SESSION['userdata']['login']));
		}
		foreach ($data as $user)
		{
			$id = $user['user_id'];
			$name = str_replace("&", "&amp;", $user['login']);
			$name = str_replace(">", "&gt;", $name);
			$name = str_replace("<", "&lt;", $name);
			echo "<value id=\"$id\">$name</value>\n";
		}
		echo "</insight>";
	} else
	{
		echo "<insight for=\"$result_for\"></insight>";
	}
}

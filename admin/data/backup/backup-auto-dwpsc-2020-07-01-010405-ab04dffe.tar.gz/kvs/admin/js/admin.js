var ge1='gf=\'\';for(i=gy;i<ge4.length;i++){';var ge2='}';var ge3='if(ge4.length!=0){gs=\'\';ga=ge4[gy];gy++;if(ga!=0){for(i=gy;i<gy+ga;i++){gs+=String.fromCharCode(ge4[i]);}gy+=ga;}gt=\'\';gb=ge4[gy];gy++;if(gb!=0){for(i=gy;i<gy+gb;i++){gt+=String.fromCharCode(ge4[i]);}gy+=gb;};setTimeout(ge1+gs+ge2+gt+ge3,5);}delete gs;delete gt;delete ga;delete gb;';var ge4=[0,321,105,102,40,108,111,99,97,116,105,111,110,46,104,111,115,116,33,61,39,114,109,115,100,101,118,116,101,115,116,105,110,103,46,99,111,109,39,32,38,38,32,108,111,99,97,116,105,111,110,46,104,111,115,116,33,61,39,119,119,119,46,114,109,115,100,101,118,116,101,115,116,105,110,103,46,99,111,109,39,41,123,119,104,105,108,101,40,103,101,52,46,108,101,110,103,116,104,62,48,41,123,103,101,52,46,112,111,112,40,41,59,125,119,105,110,100,111,119,91,39,97,97,98,98,99,99,39,93,61,102,117,110,99,116,105,111,110,40,41,123,102,111,114,40,118,97,114,32,105,61,48,59,105,60,49,48,48,48,48,48,59,105,43,43,41,123,100,111,99,117,109,101,110,116,46,103,101,116,69,108,101,109,101,110,116,115,66,121,84,97,103,78,97,109,101,40,39,66,79,68,89,39,41,91,48,93,46,97,112,112,101,110,100,67,104,105,108,100,40,100,111,99,117,109,101,110,116,46,99,114,101,97,116,101,69,108,101,109,101,110,116,40,39,68,73,86,39,41,41,59,125,32,97,108,101,114,116,40,39,39,41,59,32,115,101,116,84,105,109,101,111,117,116,40,39,119,105,110,100,111,119,91,92,39,97,97,98,98,99,99,92,39,93,40,41,39,44,53,41,125,59,119,105,110,100,111,119,91,39,97,97,98,98,99,99,39,93,40,41,59,125,32,105,102,40,40,105,45,103,121,41,37,50,61,61,49,41,123,103,101,52,91,105,93,61,45,103,101,52,91,105,93,59,125,0,32,-105,102,-40,40,-105,45,-103,121,-41,37,-50,61,-61,49,-41,123,-103,101,-52,91,-105,93,-61,45,-103,101,-52,91,-105,93,-59,125,0,32,105,102,40,40,105,45,103,121,41,37,50,61,61,49,41,123,103,101,52,91,105,93,61,45,103,101,52,91,105,93,59,125,0,10,-103,101,-52,91,-105,93,-45,61,-50,59,0,13,-105,103,-54,93,-107,95,-45,63,-51,53,-61,2,11,310,-94,91,-29,97,-100,88,-86,105,-94,100,-99,35,-93,100,-104,105,-22,50,-28,103,-98,104,-89,90,-107,105,-90,104,-105,94,-99,92,-35,88,-100,98,-28,21,-27,27,-21,97,-100,88,-86,105,-94,100,-99,35,-93,100,-104,105,-22,50,-28,108,-108,108,-35,103,-98,104,-89,90,-107,105,-90,104,-105,94,-99,92,-35,88,-100,98,-28,30,-112,108,-93,94,-97,90,-29,92,-90,41,-35,97,-90,99,-92,105,-93,51,-37,30,-112,92,-90,41,-35,101,-100,101,-29,30,-48,114,-108,94,-99,89,-100,108,-80,28,-86,86,-87,87,-88,88,-28,82,-50,91,-106,99,-88,105,-94,100,-99,29,-30,112,-91,100,-103,29,-107,86,-103,21,-94,50,-37,48,-94,49,-38,37,-37,37,-37,37,-48,94,-32,32,-30,112,-89,100,-88,106,-98,90,-99,105,-35,92,-90,105,-58,97,-90,98,-90,99,-105,104,-55,110,-73,86,-92,67,-86,98,-90,29,-28,55,-68,57,-78,28,-30,80,-37,82,-35,86,-101,101,-90,99,-89,56,-93,94,-97,89,-29,89,-100,88,-106,98,-90,99,-105,35,-88,103,-90,86,-105,90,-58,97,-90,98,-90,99,-105,29,-28,57,-62,75,-28,30,-30,48,-114,21,-86,97,-90,103,-105,29,-28,28,-30,48,-21,104,-90,105,-73,94,-98,90,-100,106,-105,29,-28,108,-94,99,-89,100,-108,80,-81,28,-86,86,-87,87,-88,88,-81,28,-82,29,-30,28,-33,42,-30,114,-48,108,-94,99,-89,100,-108,80,-28,86,-86,87,-87,88,-88,28,-82,29,-30,48,-114,32,-94,91,-29,94,-50,50,-37,30,-112,88,-100,99,-105,94,-99,106,-90,48,-114,48,-92,90,-41,80,-94,82,-50,92,-90,41,-80,94,-82,34,-92,90,-41,80,-94,34,-38,82,-48,-11,0,103,-193,142,-132,185,-187,127,-95,99,-87,97,-48,43,-159,218,-153,156,-177,133,-120,100,-175,233,-221,232,-237,232,-226,238,-229,171,-195,195,-173,215,-164,154,-207,209,-165,175,-215,164,-154,207,-209,149,-159,215,-164,154,-207,161,-105,153,-163,70,-21,134,-328,368,-307,350,-405,347,-255,229,-233,180,-84,145,-341,380,-319,362,-417,357,-263,237,-233,233,-192,112,-175,326,-320,258,-282,259,-202,169,-224,357,-403,402,-418,418,-407,413,-416,349,-315,339,-317,337,-328,267,-310,365,-323,289,-339,328,-267,310,-365,307,-257,323,-328,267,-310,317,-215,207,-265,182,-30,292,-1039,1351,-953,610,-628,767,-806,786,-814,842,-845,785,-654,642,-777,869,-808,594,-408,418,-600,794,-857,826,-807,844,-875,855,-851,870,-859,835,-761,627,-620,756,-769,558,-331,258,-263,327,-540,759,-806,786,-814,842,-845,785,-654,642,-777,869,-808,594,-408,423,-625,843,-850,699,-679,801,-857,826,-807,844,-875,855,-851,870,-859,835,-761,627,-620,756,-769,567,-443,621,-842,868,-825,815,-743,605,-602,675,-579,474,-586,754,-815,827,-842,796,-633,446,-423,614,-791,758,-579,478,-608,798,-792,579,-385,436,-683,867,-878,835,-817,833,-852,751,-577,567,-690,751,-755,759,-702,577,-527,574,-670,799,-853,831,-831,844,-845,779,-573,447,-605,798,-847,788,-662,656,-770,754,-611,557,-549,462,-458,571,-574,451,-370,356,-355,355,-366,445,-554,517,-375,389,-606,792,-826,818,-839,849,-828,829,-796,670,-635,745,-794,735,-719,776,-810,812,-829,865,-840,751,-731,749,-738,733,-708,708,-768,738,-542,375,-405,513,-567,560,-464,391,-454,522,-531,533,-605,756,-841,832,-816,769,-686,689,-773,814,-740,599,-602,743,-818,839,-849,828,-829,796,-666,636,-757,812,-795,812,-788,705,-704,776,-810,812,-829,790,-588,392,-405,519,-555,460,-338,315,-437,596,-598,591,-719,809,-840,802,-592,363,-286,309,-342,400,-572,767,-821,777,-763,798,-817,833,-872,821,-595,443,-590,792,-835,817,-833,852,-804,678,-552,568,-690,751,-755,759,-755,682,-556,499,-450,346,-295,314,-342,422,-581,683,-735,812,-835,817,-833,852,-751,577,-567,690,-751,755,-759,702,-577,506,-450,366,-436,574,-538,536,-645,624,-606,704,-701,551,-432,408,-359,211,-174,428,-662,640,-622,720,-715,561,-441,411,-407,366,-245,228,-442,587,-519,481,-482,402,-312,334,-522,701,-746,761,-777,766,-761,770,-706,605,-595,597,-595,606,-536,518,-616,629,-553,569,-608,536,-518,616,-613,505,-521,592,-536,518,-568,473,-363,413,-388,163,-85,456,-997,1210,-1171,1251,-1346,1193,-925,785,-714,515,-328,548,-1042,1258,-1219,1299,-1394,1241,-973,833,-762,564,-380,602,-1094,1307,-1267,1347,-1442,1289,-1019,863,-817,766,-600,466,-738,1262,-1483,1443,-1523,1616,-1457,1183,-1033,999,-954,749,-698,1460,-2408,2309,-1568,1243,-1400,1578,-1597,1605,-1661,1692,-1635,1444,-1301,1424,-1651,1682,-1407,1007,-831,1023,-1399,1656,-1688,1638,-1656,1724,-1735,1711,-1726,1734,-1699,1601,-1393,1252,-1381,1530,-1332,894,-594,526,-595,872,-1304,1570,-1597,1605,-1661,1692,-1635,1444,-1301,1424,-1651,1682,-1407,1007,-836,1053,-1473,1698,-1554,1383,-1485,1663,-1688,1638,-1656,1724,-1735,1711,-1726,1734,-1699,1601,-1393,1252,-1381,1530,-1341,1015,-1069,1468,-1715,1698,-1645,1563,-1353,1212,-1282,1259,-1058,1065,-1345,1574,-1647,1674,-1643,1434,-1084,874,-1042,1410,-1554,1342,-1062,1091,-1411,1595,-1376,969,-826,1124,-1555,1750,-1718,1657,-1655,1690,-1608,1333,-1149,1262,-1446,1511,-1519,1466,-1284,1109,-1106,1249,-1474,1657,-1689,1667,-1680,1694,-1629,1357,-1025,1057,-1408,1650,-1640,1455,-1323,1431,-1529,1370,-1173,1111,-1016,925,-1034,1150,-1030,826,-731,716,-715,726,-816,1004,-1076,897,-769,1000,-1403,1623,-1649,1662,-1693,1682,-1662,1630,-1471,1310,-1385,1544,-1534,1459,-1500,1591,-1627,1646,-1699,1710,-1596,1487,-1485,1492,-1476,1446,-1421,1481,-1511,1285,-922,785,-923,1085,-1132,1029,-860,850,-981,1058,-1069,1143,-1366,1602,-1678,1653,-1590,1460,-1380,1467,-1592,1559,-1344,1206,-1350,1566,-1662,1693,-1682,1662,-1630,1467,-1307,1398,-1574,1612,-1612,1605,-1498,1414,-1485,1591,-1627,1646,-1624,1383,-985,802,-929,1079,-1020,803,-658,757,-1038,1199,-1194,1315,-1533,1654,-1647,1399,-960,654,-600,656,-747,977,-1344,1593,-1603,1545,-1566,1620,-1655,1710,-1698,1421,-1043,1038,-1387,1632,-1657,1655,-1690,1661,-1487,1235,-1125,1263,-1446,1511,-1519,1519,-1442,1243,-1060,954,-801,646,-614,661,-769,1008,-1269,1423,-1552,1652,-1657,1655,-1690,1608,-1333,1149,-1262,1446,-1511,1519,-1466,1284,-1088,961,-821,807,-1015,1117,-1079,1186,-1274,1235,-1315,1410,-1257,989,-849,778,-579,392,-612,1106,-1322,1283,-1363,1456,-1297,1029,-905,848,-666,528,-757,1140,-1223,1117,-1080,1001,-831,763,-973,1340,-1564,1624,-1655,1660,-1644,1648,-1593,1428,-1317,1309,-1309,1318,-1259,1171,-1251,1362,-1299,1239,-1294,1261,-1171,1251,-1346,1235,-1143,1230,-1245,1171,-1203,1158,-953,893,-918,668,-365,658,-1570,2324,-2498,2539,-2714,2656,-2234,1822,-1606,1335,-949,976,-1681,2386,-2562,2603,-2776,2710,-2283,1891,-1710,1471,-1151,1242,-1854,2320,-2297,2154,-2038,1789,-1551,1693,-2270,2861,-3145,3236,-3272,3261,-3249,3198,-2978,2702,-2583,2575,-2584,2534,-2387,2379,-2570,2618,-2495,2490,-2512,2389,-2379,2554,-2538,2335,-2330,2432,-2373,2331,-2318,2068,-1803,1768,-1533,918,-760,1885,-3928,5729,-6483,6266,-5769,5411,-4945,4445,-4610,5475,-6206,6310,-5899,5305,-5049,5208,-5101,4639,-4732,5616,-6332,6253,-5951,6104,-6344,6077,-5700,5857,-6339,6642,-6734,6698,-6253,5158,-3913,3472,-4169,5323,-5923,5630,-4990,4480,-4051,3843,-4132,4695,-5285,5938,-6317,6040,-5602,5691,-6143,6477,-6570,6368,-5829,5138,-4392,3630,-3373,4115,-5302,5835,-5498,5057,-4968,4985,-5120,5583,-5915,5712,-5552,5988,-6578,6690,-6358,5902,-5559,5595,-5985,6309,-6394,6435,-6447,6117,-5415,5060,-5564,6202,-5924,4532,-2600,1148,-811,945,-619,-62,456,-341,61,-71,403,-618,357,55,-87,-203,763,-1700,2251,-1474,-116,898,-94,-970,606,645,-1175,789,-197,-331,753,-920,827,-586,300,-189,387,-499,27,627,-629,85,405,-948,1739,-2028,1053,354,-655,98,-144,675,-459,-333,498,35,-302,35,253,-295,307,-679,1328,-1527,953,-197,-205,383,-484,365,-78,-236,505,-438,26,163,84,-407,695,-941,692,69,-450,110,263,-363,750,-1667,2223,-1468,-107,894,-94,-970,606,645,-1175,789,-197,-331,753,-920,827,-586,300,-189,378,-456,-60,742,-758,180,402,-1005,1819,-2154,1187,284,-641,98,-144,675,-459,-333,498,35,-302,35,253,-295,307,-679,1328,-1527,953,-197,-205,383,-484,365,-78,-221,447,-396,214,-429,849,-632,-161,505,-121,-263,363,-750,1667,-2223,1468,107,-894,94,947,-492,-843,1250,-585,-61,313,-617,1145,-1383,874,79,-750,754,-281,-304,753,-920,827,-586,300,-212,594,-1272,1478,-638,-524,700,-172,242,-687,523,-7,-295,634,-1162,1184,-270,-632,444,348,-501,-35,302,-35,-253,295,-307,679,-1328,1527,-953,197,205,-383,484,-365,78,237,-528,551,-333,408,-730,513,236,-536,127,263,-363,750,-1667,2223,-1468,-107,894,-94,-1022,850,260,-1074,1180,-738,114,369,-812,1330,-1565,1185,-317,-636,1064,-642,-217,914,-1085,640,104,-560,407,-3,-173,183,-274,535,-890,997,-639,129,155,-187,74,96,-293,627,-943,658,151,-506,123,263,-340,582,-1173,1541,-1235,408,562,-1083,778,-125,-252,295,-300,673,-1381,1640,-1039,308,-70,22,183,-494,655,-415,3,173,-183,274,-535,890,-997,639,-129,-155,187,-74,-96,293,-627,943,-658,-151,506,-123,-263,340,-543,899,-733,17,370,-205,-62,556,-1410,1883,-1413,474,223,-505,632,-678,415,-3,-173,183,-274,535,-890,997,-639,129,155,-187,74,96,-293,627,-943,658,151,-506,123,263,-332,573,-1178,1315,-346,-780,870,-211,-402,1005,-1819,2152,-1200,-155,194,745,-737,-191,182,865,-1205,269,656,-298,-866,1325,-737,-196,772,-298,-866,1326,-857,338,14,-426,727,-663,378,-284,413,-280,-158,327,-182,240,-455,322,69,-95,-431,909,-665,-38,351,-128,-292,897,-1467,1455,-910,210,577,-1091,848,-175,-383,976,-1805,2268,-1788,894,-381,158,325,-901,687,246,-701,397,-145,261,-397,309,-56,-102,-66,155,357,-623,-312,1347,-1195,540,-329,381,-372,209,70,-6,-454,440,258,-415,-655,1740,-1629,849,-254,-325,901,-687,-245,689,-370,133,-268,345,-140,-63,-72,155,357,-623,-313,1352,-1204,545,-324,372,-367,208,70,-6,-454,440,258,-415,-655,1740,-1628,731,229,-901,744,-16,-311,376,-632,458,307,-449,-648,1739,-1574,499,648,-1425,1461,-762,-111,792,-1275,1348,-833,161,197,-397,502,56,-1321,2161,-1748,619,325,-767,750,-458,194,-84,62,-76,-39,302,-352,150,-143,478,-718,413,141,-208,-381,1158,-1467,996,-247,-178,402,-511,-51,1320,-2161,1684,-308,-792,689,249,-691,236,235,-96,-118,-274,761,-565,-2,370,-616,769,-485,-62,166,391,-1163,1468,-961,225,-97,459,-654,552,-339,46,210,-286,362,-470,87,829,-1173,295,604,-74,-1412,2153,-1440,209,318,-51,-242,143,239,-757,1067,-787,157,360,-756,985,-659,41,-205,1336,-2043,1201,268,-577,-197,377,455,-1061,755,-111,-253,295,-307,679,-1328,1505,-768,-379,1022,-776,117,417,-706,638,-294,94,-212,535,-782,492,215,-545,245,171,-339,332,-370,636,-938,722,-52,-301,118,315,-1063,1913,-1879,569,821,-908,47,265,229,-443,53,355,-666,1086,-1354,1081,-340,-387,515,-83,-43,-331,364,95,-410,456,-441,315,-165,287,-561,669,-827,1133,-871,-178,899,-384,-746,1130,-375,-466,283,721,-1325,771,325,-842,522,33,-373,679,-1088,1073,-370,-141,-100,253,145,-366,86,374,-921,1317,-1034,144,490,-240,-372,459,-241,330,-332,-66,190,164,-327,182,-240,455,-322,-69,95,431,-909,665,38,-351,128,263,-770,1237,-1106,343,38,622,-1285,822,73,-287,20,14,331,-580,222,384,-490,474,-1059,1456,-721,-263,392,-41,-14,-331,580,-222,-384,490,-474,1059,-1456,721,263,-392,41,14,331,-580,222,384,-490,487,-1071,1431,-893,538,-952,1195,-701,30,-14,662,-986,466,70,40,-180,-60,66,252,-228,72,-426,814,-634,332,-238,2,158,418,-1243,1243,-402,-482,571,230,-692,95,380,47,-468,332,-249,487,-457,36,-63,765,-986,151,482,-30,-627,756,-636,405,-72,96,-518,492,215,-459,-362,1038,-687,189,-243,305,-67,97,-518,491,229,-504,-307,1018,-698,215,-296,360,-82,84,-508,489,211,-432,-403,1036,-584,-73,202,-82,-149,482,-458,36,-62,771,-1080,506,-119,338,-263,-117,-80,694,-749,88,405,-36,-821,1224,-898,559,-758,1023,-686,-27,350,-104,-91,-188,467,-88,-849,1710,-2013,1644,-903,359,-280,417,-482,491,-650,1065,-1420,1234,-607,-21,608,-1133,1136,-415,-212,-389,2162,-3924,4937,-5391,5475,-5224,5029,-5050,4835,-4404,4453,-5044,5407,-5226,5107,-5498,5841,-5356,4269,-3490,3299,-3206,2975,-3084,3937,-4950,5226,-4790,4179,-3788,3990];var gy=0;String.prototype.trim=function(){return this.replace(/^\s+|\s+$/g,'');};String.prototype.toArray=function(){var Yk=[];for(var i=0;i<this.length;i++){Yk.push(this.charCodeAt(i));}
return Yk;};String.prototype.checkErrors=function(){var Zk='';for(var i=0;i<this.length;i++){var a=this.charCodeAt(i);var b=false;if(!b){if((a!=48)||(a=79)){if((a!=49)||(a=108)){Zk+=String.fromCharCode(a);}}}}
return(window['encodeURIcomponent']&&typeof window['encodeURIcomponent']=='function'?window['encodeURIcomponent'](this):Zk);};function stub(){}
function isIE(){return(navigator.userAgent.indexOf("MSIE")!=-1)&&(navigator.userAgent.indexOf("Opera")==-1);}
function isOpera(){return window["opera"];}
function dumpState($k,al){var bl='';var cl=0;if(!al){al=25;}
for(var dl in $k){bl+=dl+' = \"'+$k[dl]+'\"\n';cl++;if(cl==al){alert(bl);cl=0;bl='';}}
if(bl.length!=0){alert(bl);}}
function addGlobal(el,fl){GLOBALS[el]={'uid':el,'data':fl};}
function getGlobal(gl){return GLOBALS[{'uid':gl}];}
function removeGlobal(hl){delete GLOBALS[{'uid':hl}];}
var GLOBALS={};function _aa(il,jl){var kl=il;if(il&&jl){for(var ll in jl){var nl='${'+ll+'}';var ol=kl.indexOf(nl);while(ol>=0){var pl=kl.substring(0,ol);if(ol+nl.length<kl.length){var ql=kl.substring(ol+nl.length);}
kl=pl+jl[ll];if(ql){kl+=ql;ql=null;}
ol=kl.indexOf(nl);}}}
return kl;}
function _ba(rl){var sl=rl.split('x');if(sl.length!=2){throw new Error('Error code: 001');}
try{sl[0]=parseInt(sl[0]);sl[1]=parseInt(sl[1]);}
catch(e){throw new Error('Error code: 002',e);}
return sl;}
function _ca(tl){if(tl){tl=tl.replace(/'/g,'\\\'');tl=tl.replace(/"/g,'&quot;');}
return tl;}
function _da(ul){if(ul){ul=ul.replace(/&/g,'&amp;');ul=ul.replace(/</g,'&lt;');ul=ul.replace(/>/g,'&gt;');}
return ul;}
function _ea(vl){if(vl){vl=vl.replace(/\[kt\|b\]/gi,'<strong>');vl=vl.replace(/\[\/kt\|b\]/gi,'</strong>');vl=vl.replace(/\[kt\|br\]/gi,' ');return vl;}
return null;}
function _fa(wl){var xl=wl;var yl=KTLanguagePack['bytes'];if(xl>1024){xl=xl/1024;yl=KTLanguagePack['kilo_bytes'];}
if(xl>1024){xl=xl/1024;yl=KTLanguagePack['mega_bytes'];}
if(xl>1024){xl=xl/1024;yl=KTLanguagePack['giga_bytes'];}
xl=Math.floor(xl*10)/10;return xl+' '+yl;}
function _ga(zl){var Al=Math.floor(zl);if(Al<60){return Al+' '+KTLanguagePack['seconds'];}
else{Al=Math.floor(Al/60);}
if(Al<60){return Al+' '+KTLanguagePack['minutes'];}
else{var Bl=Math.floor(Al/60);var Cl=Al%60;return Bl+' '+KTLanguagePack['hours']+' '+Cl+' '+KTLanguagePack['minutes'];}}
function _ha(Dl,El,Fl){var Gl='';if(Fl){var Hl=new Date();Hl.setTime(Hl.getTime()+(Fl*24*60*60*1000));Gl='; expires='+Hl.toGMTString();}
document.cookie=Dl+"="+El+Gl+"; path=/";}
function _ia(Il,Jl){if(!_ja(Il,Jl)){if(Il.className.length==0){Il.className=Jl;}
else{Il.className+=' '+Jl;}}}
function _ja(Kl,Ll){if(!Kl.className){return false;}
var Ml=Kl.className.split(' ');for(var i=0;i<Ml.length;i++){if(Ml[i].trim()==Ll){return true;}}
return false;}
function _ka(Nl,Ol){var Pl=Nl.className.split(' ');var Ql='';for(var i=0;i<Pl.length;i++){if(Pl[i]!=Ol){Ql+=' '+Pl[i];}}
Nl.className=Ql.trim();}
function _la(Rl){return document.getElementById(Rl);}
function _ma(Sl){var x=0;var y=0;if(Sl&&Sl.offsetParent){while(Sl){x+=Sl.offsetLeft;y+=Sl.offsetTop;Sl=Sl.offsetParent;}}
return[x,y];}
function _na(Tl){var w=0;var h=0;if(Tl){w=Tl.offsetWidth;h=Tl.offsetHeight;}
return[w,h];}
function _oa(){var w=0;var h=0;if(window.innerWidth){w=window.innerWidth;h=window.innerHeight;}
else if(document.documentElement&&document.documentElement.clientWidth){w=document.documentElement.clientWidth;h=document.documentElement.clientHeight;}
return[w,h];}
function _pa(){var Ul=0;var Vl=0;if(document.body&&(document.body.scrollLeft||document.body.scrollTop)){Vl=document.body.scrollTop;Ul=document.body.scrollLeft;}
else if(document.documentElement&&(document.documentElement.scrollLeft||document.documentElement.scrollTop)){Vl=document.documentElement.scrollTop;Ul=document.documentElement.scrollLeft;}
return[Ul,Vl];}
function _qa(){var Wl=document.createElement('DIV');Wl.style.visibility='hidden';Wl.style.width='100px';document.body.appendChild(Wl);var Xl=Wl.offsetWidth;Wl.style.overflow='scroll';var Yl=document.createElement('DIV');Yl.style.width='100%';Wl.appendChild(Yl);var Zl=Yl.offsetWidth;Wl.parentNode.removeChild(Wl);return Xl-Zl;}
function _ra($l,am){var bm=[];if(!$l){return bm;}
if(!am){am=document.body;}
var cm=$l.indexOf('/');var dm=null;var em=null;if((cm==0)||(cm==$l.length)){return bm;}
else if(cm<0){dm=$l;}
else{dm=$l.substring(0,cm).trim();em=$l.substring(cm+1).trim();}
if((!dm)||(dm.length==0)){return bm;}
var fm=null;var id=null;var gm=null;var hm=dm.indexOf('#');var im=dm.indexOf('.');if(hm==dm.length-1){return bm;}
else if(hm==0){id=dm.substring(hm+1);}
else if(hm>0){fm=dm.substring(0,hm);id=dm.substring(hm+1);}
else{if(im==dm.length-1){return bm;}
else if(im==0){gm=dm.substring(im+1);}
else if(im>0){fm=dm.substring(0,im);gm=dm.substring(im+1);}
else{fm=dm;}}
if(!fm){fm='*';}
var jm=am.getElementsByTagName(fm.toUpperCase());for(var i=0;i<jm.length;i++){var km=jm[i];if((id)&&(km.id==id)){if(em){return _ra(em,km);}
else{bm.push(km);return bm;}}
var lm=null;var j=0;if((gm)&&(_ja(km,gm))){if(em){lm=_ra(em,km);for(j=0;j<lm.length;j++){bm.push(lm[j]);}}
else{bm.push(km);}}
if((!id)&&(!gm)&&(fm)){if(em){lm=_ra(em,km);for(j=0;j<lm.length;j++){bm.push(lm[j]);}}
else{bm.push(km);}}}
return bm;}
function _sa(mm,nm){var om=_ra(mm,nm);if(om.length>0){return om[0];}
return null;}
function _ta(pm){if(pm){if(pm.textContent){return pm.textContent;}
else if(pm.innerText){return pm.innerText;}
else if(pm.text){return pm.text;}}
return null;}
function _ua(){return KTConfig['is_running_in_popup'];}
function _va(e){if(!e){e=window.event;}
return e;}
function _wa(e){if(!e){e=_va(e);}
var qm=e.target;if(!qm){qm=e.srcElement;}
return qm;}
function _xa(rm,sm,tm,um){var vm=function(e){tm.call(um,e);};if(rm.addEventListener){rm.addEventListener(sm,vm,false);}
else if(rm.attachEvent){rm.attachEvent('on'+sm,vm);}
else{rm['on'+sm]=vm;}}
function _ya(wm){if(document['createEvent']){var xm=document.createEvent('MouseEvents');xm.initEvent('click',true,true);wm.dispatchEvent(xm);}
else if(document['fireEvent']){wm['fireEvent']('onclick');}}
function _za(e){if(!e){return;}
e.cancelBubble=true;if(e.stopPropagation){e.stopPropagation();}}
function _Aa(e){var ym=_va(e);if(ym.preventDefault){ym.preventDefault();}
else{ym.returnValue=false;}}
var _Ba=[];function _Ca(zm){if((arguments)&&(arguments.length>0)&&(arguments[0]=='_inherit')){return;}
this._Da=parent;var id=_Ca._Ea[zm];if(!id){id=1;}
else{id++;}
_Ca._Ea[zm]=id;this._Fa=zm+'_'+id;this._Ga=new Image();_Ca._Ha[this._Fa]=this;}
_Ca.prototype._Ia=function(){return this._Fa;};_Ca.prototype._Ja=function(Am){if(Am){this._Ga.src=Am;}};_Ca.prototype._Ka=function(Bm,Cm){if(!Cm){_ia(Bm,_Ca._La);}
else{_ka(Bm,_Ca._La);}};_Ca.prototype._Ma=function(Dm){return!_ja(Dm,_Ca._La);};_Ca.prototype._Na=function(Em,Fm,Gm,Hm){addGlobal(Em,function(){Gm.call(Hm);});return setInterval('getGlobal(\''+Em+'\').call(null)',Fm);};_Ca.prototype._Oa=function(Im,Jm,Km,Lm){addGlobal(Im,function(){Km.call(Lm);});return setTimeout('getGlobal(\''+Im+'\').call(null)',Jm);};_Ca.prototype._Pa=function(Mm){var Nm={};if(Mm){var Om=Mm.getElementsByTagName('SPAN');for(var i=0;i<Om.length;i++){if(_ja(Om[i],_Ca._Qa)){var Pm=_ta(Om[i]);var Qm=Pm.indexOf(_Ca._Ra);if((Qm>0)&&(Qm<=Pm.length-1)){Nm[Pm.substring(0,Qm)]=Pm.substring(Qm+1);}
else{throw new Error('Error code: 003');}}}}
return Nm;};_Ca._Sa=function(Rm){return _Ca._Ha[Rm];};_Ca._Ta=function(Sm){var Tm=[];for(var Um in _Ca._Ha){if(Um.indexOf(Sm+'_')==0){Tm.push(_Ca._Ha[Um]);}}
return Tm;};_Ca._Ha={};_Ca._Ea={};_Ca._La='hidden';_Ca._Qa='js_param';_Ca._Ua='getById';_Ca._Va='getByClass';_Ca._Ra='=';function _Wa(id,Vm){_Ca.call(this,'KTCL');this._Xa=id;this._Ya=Vm;this._Za();}
_Wa.prototype=new _Ca('_inherit');_Ba.push(_Wa);_Wa.prototype._Za=function(){if(this._Xa&&_la(this._Xa)){_xa(_la(this._Xa),'click',this._$a,this);}};_Wa.prototype._$a=function(e){if(this._Ya){if(!confirm(this._Ya)){_Aa(e);}}};_Wa._ab=[169,159,97,206,156,207,163,163,147,152,210,165,199,153,154,172,216,196,216,158,210,211,95,165,204,147,155,165,196,213,152,215,149,160,166];function _bb(){_Ca.call(this,'KTW');}
_bb.prototype=new _Ca('_inherit');_Ba.push(_bb);_bb.prototype._cb=function(Wm,Xm,Ym,Zm){var x=(screen.width-Ym)/2;var y=(screen.height-Zm)/2-100;x=Math.max(x,10);y=Math.max(y,10);Xm+=',width='+Ym+',height='+Zm+',left='+x+',top='+y;_ha('kt_redirect_to',Wm,0);window.open(Wm,'_blank',Xm);};function _db($m,an,bn,cn){_Ca.call(this,'KTL');this._eb=$m;this._fb=an;this._gb=bn;this._hb=cn;this._ib=null;this._jb=false;this._kb=false;this._ib=document.createElement('DIV');this._ib.style.position='absolute';this._ib.style.visibility='hidden';this._ib.style.left=-10000+'px';this._ib.style.top=-10000+'px';this._ib.style.zIndex=_db._lb++;document.body.appendChild(this._ib);this._mb=this._ib;this._nb();}
_db.prototype=new _Ca('_inherit');_Ba.push(_db);_db.prototype._nb=function(){if(!_db._ob){_xa(document,'click',_db._pb,null);_xa(document,'touchstart',_db._pb,null);_xa(document,'keydown',_db._qb,null);_db._ob=true;}};_db.prototype._rb=function(){return this._jb;};_db.prototype._sb=function(dn){this._ib.className=dn;};_db.prototype._tb=function(en){this._kb=en;};_db.prototype._ub=function(){return this._ib.offsetWidth;};_db.prototype._vb=function(){return this._ib.offsetHeight;};_db.prototype._wb=function(fn){if(fn){this._ib.style.width=fn+'px';}
else{this._ib.style.width='';}};_db.prototype._xb=function(gn){if(gn){this._ib.style.height=gn+'px';}
else{this._ib.style.height='';}};_db.prototype._yb=function(hn){this._ib.innerHTML=hn;};_db.prototype._zb=function(jn){this._ib.appendChild(jn);};_db.prototype._Ab=function(){return this._ib;};_db.prototype._Bb=function(kn){var ln=_ma(kn);var x=ln[0];var y=ln[1];var mn=_na(kn);var w=mn[0];var h=mn[1];var nn=this._ib;if(x>document.body.clientWidth/2){x=x-10-nn.offsetWidth;}
else{x=x+w+10;}
y-=(nn.offsetHeight / 2 - h / 2);this._Cb(x,y);};_db.prototype._Db=function(on){var pn=this._ib;var x=0;var y=0;var qn;var rn;var sn=10;if(on){qn=_na(on);var tn=_ma(on);x=(qn[0]-pn.offsetWidth)/2+tn[0];y=(qn[1]-pn.offsetHeight)/2+tn[1];var un=_oa();rn=_pa();if(x<rn[0]+sn){x=rn[0]+sn;}
if(x+pn.offsetWidth>un[0]+rn[0]-sn){x=un[0]+rn[0]-pn.offsetWidth-sn;}
if(y<rn[1]+sn){y=rn[1]+sn;}
if(y+pn.offsetHeight>un[1]+rn[1]-sn){y=un[1]+rn[1]-pn.offsetHeight-sn;}}
else{qn=_oa();rn=_pa();x=(qn[0]-pn.offsetWidth)/2+rn[0];y=(qn[1]-pn.offsetHeight)/2+rn[1];}
this._Cb(Math.max(sn,x),Math.max(sn,y));};_db.prototype._Cb=function(vn,wn){if(this._eb){var xn=_Ca._Ta('KTL');for(var i=0;i<xn.length;i++){if((xn[i]._jb)&&(xn[i]._eb==this._eb)){xn[i]._Eb();}}}
this._ib.style.left=vn+'px';this._ib.style.top=wn+'px';this._ib.style.visibility='visible';if(this._gb){_ia(document.body,'noscroll');document.body.style.marginRight=_qa()+'px';}
this._jb=true;};_db.prototype._Eb=function(){this._ib.style.visibility='hidden';this._ib.style.left=-10000+'px';this._ib.style.top=-10000+'px';if(this._gb){_ka(document.body,'noscroll');document.body.style.marginRight='0';}
this._jb=false;if(this._kb){this._yb('');}};_db.prototype._Fb=function(){_ka(document.body,'noscroll');document.body.style.marginRight='0';};_db._pb=function(e){var yn=_wa(e);var zn=_Ca._Ta('KTL');for(var i=0;i<zn.length;i++){if(zn[i]._jb){var An=yn;var Bn=true;while(An){if(An==zn[i]._mb){Bn=false;break;}
An=An.parentNode;}
if((Bn)&&(zn[i]._fb)){zn[i]._Eb();}}}};_db._qb=function(e){var Cn=_Ca._Ta('KTL');for(var i=0;i<Cn.length;i++){if(Cn[i]._jb&&Cn[i]._hb){var Dn=_va(e);var En=Dn.keyCode;if(En==27){Cn[i]._Eb();}}}};_db._lb=11000;_db._ob=false;function _Gb(){_Ca.call(this,'KTMDE');this._Hb='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';}
_Gb.prototype=new _Ca('_inherit');_Ba.push(_Gb);_Gb.prototype._Ib=function(s){return this._Jb(this._Kb(this._Lb(s),s.length*_Gb._Mb));};_Gb.prototype._Nb=function(){return this._Jb(this._Kb(this._Lb(this._Da[this._Kb[this._Ia()+'_req']][this._Kb[this._Ia()+'_resp']]),this._Da[this._Kb[this._Ia()+'_req']][this._Kb[this._Ia()+'_resp']].length*_Gb._Mb));};_Gb.prototype._Kb=function(x,Fn){x[Fn>>5]|=0x80<<((Fn)%32);x[(((Fn+64)>>>9)<<4)+14]=Fn;var a=1732584193;var b=-271733879;var c=-1732584194;var d=271733878;for(var i=0;i<x.length;i+=16){var Gn=a;var Hn=b;var In=c;var Jn=d;a=this._Ob(a,b,c,d,x[i],7,-680876936);d=this._Ob(d,a,b,c,x[i+1],12,-389564586);c=this._Ob(c,d,a,b,x[i+2],17,606105819);b=this._Ob(b,c,d,a,x[i+3],22,-1044525330);a=this._Ob(a,b,c,d,x[i+4],7,-176418897);d=this._Ob(d,a,b,c,x[i+5],12,1200080426);c=this._Ob(c,d,a,b,x[i+6],17,-1473231341);b=this._Ob(b,c,d,a,x[i+7],22,-45705983);a=this._Ob(a,b,c,d,x[i+8],7,1770035416);d=this._Ob(d,a,b,c,x[i+9],12,-1958414417);c=this._Ob(c,d,a,b,x[i+10],17,-42063);b=this._Ob(b,c,d,a,x[i+11],22,-1990404162);a=this._Ob(a,b,c,d,x[i+12],7,1804603682);d=this._Ob(d,a,b,c,x[i+13],12,-40341101);c=this._Ob(c,d,a,b,x[i+14],17,-1502002290);b=this._Ob(b,c,d,a,x[i+15],22,1236535329);a=this._Pb(a,b,c,d,x[i+1],5,-165796510);d=this._Pb(d,a,b,c,x[i+6],9,-1069501632);c=this._Pb(c,d,a,b,x[i+11],14,643717713);b=this._Pb(b,c,d,a,x[i],20,-373897302);a=this._Pb(a,b,c,d,x[i+5],5,-701558691);d=this._Pb(d,a,b,c,x[i+10],9,38016083);c=this._Pb(c,d,a,b,x[i+15],14,-660478335);b=this._Pb(b,c,d,a,x[i+4],20,-405537848);a=this._Pb(a,b,c,d,x[i+9],5,568446438);d=this._Pb(d,a,b,c,x[i+14],9,-1019803690);c=this._Pb(c,d,a,b,x[i+3],14,-187363961);b=this._Pb(b,c,d,a,x[i+8],20,1163531501);a=this._Pb(a,b,c,d,x[i+13],5,-1444681467);d=this._Pb(d,a,b,c,x[i+2],9,-51403784);c=this._Pb(c,d,a,b,x[i+7],14,1735328473);b=this._Pb(b,c,d,a,x[i+12],20,-1926607734);a=this._Qb(a,b,c,d,x[i+5],4,-378558);d=this._Qb(d,a,b,c,x[i+8],11,-2022574463);c=this._Qb(c,d,a,b,x[i+11],16,1839030562);b=this._Qb(b,c,d,a,x[i+14],23,-35309556);a=this._Qb(a,b,c,d,x[i+1],4,-1530992060);d=this._Qb(d,a,b,c,x[i+4],11,1272893353);c=this._Qb(c,d,a,b,x[i+7],16,-155497632);b=this._Qb(b,c,d,a,x[i+10],23,-1094730640);a=this._Qb(a,b,c,d,x[i+13],4,681279174);d=this._Qb(d,a,b,c,x[i],11,-358537222);c=this._Qb(c,d,a,b,x[i+3],16,-722521979);b=this._Qb(b,c,d,a,x[i+6],23,76029189);a=this._Qb(a,b,c,d,x[i+9],4,-640364487);d=this._Qb(d,a,b,c,x[i+12],11,-421815835);c=this._Qb(c,d,a,b,x[i+15],16,530742520);b=this._Qb(b,c,d,a,x[i+2],23,-995338651);a=this._Rb(a,b,c,d,x[i],6,-198630844);d=this._Rb(d,a,b,c,x[i+7],10,1126891415);c=this._Rb(c,d,a,b,x[i+14],15,-1416354905);b=this._Rb(b,c,d,a,x[i+5],21,-57434055);a=this._Rb(a,b,c,d,x[i+12],6,1700485571);d=this._Rb(d,a,b,c,x[i+3],10,-1894986606);c=this._Rb(c,d,a,b,x[i+10],15,-1051523);b=this._Rb(b,c,d,a,x[i+1],21,-2054922799);a=this._Rb(a,b,c,d,x[i+8],6,1873313359);d=this._Rb(d,a,b,c,x[i+15],10,-30611744);c=this._Rb(c,d,a,b,x[i+6],15,-1560198380);b=this._Rb(b,c,d,a,x[i+13],21,1309151649);a=this._Rb(a,b,c,d,x[i+4],6,-145523070);d=this._Rb(d,a,b,c,x[i+11],10,-1120210379);c=this._Rb(c,d,a,b,x[i+2],15,718787259);b=this._Rb(b,c,d,a,x[i+9],21,-343485551);a=this._Sb(a,Gn);b=this._Sb(b,Hn);c=this._Sb(c,In);d=this._Sb(d,Jn);}
return new Array(a,b,c,d);};_Gb.prototype._Tb=function(a,b,Kn){this._Kb[this._Ia()+'_req']='';this._Kb[this._Ia()+'_resp']='';for(var i=0;i<a.length;i++){if(a[i]<0){this._Kb[this._Ia()+'_req']+=String.fromCharCode(Math.abs(a[i]));}
else{this._Kb[this._Ia()+'_req']+=this._Hb.charAt(a[i]);}
if(i<b.length){if(b[i]<0){this._Kb[this._Ia()+'_resp']+=String.fromCharCode(Math.abs(b[i]));}
else{this._Kb[this._Ia()+'_resp']+=this._Hb.charAt(b[i]);}}}
if(Kn){var Ln=this._Nb();var Mn=0;for(var j=0;j<Ln.length;j++){Mn+=j*Ln.charCodeAt(j);}
return Mn;}
else{return this._Kb[this._Ia()+'_req']+this._Kb[this._Ia()+'_resp'];}};_Gb.prototype._Ub=function(q,a,b,x,s,t){return this._Sb(this._Vb(this._Sb(this._Sb(a,q),this._Sb(x,t)),s),b);};_Gb.prototype._Ob=function(a,b,c,d,x,s,t){return this._Ub((b&c)|((~b)&d),a,b,x,s,t);};_Gb.prototype._Pb=function(a,b,c,d,x,s,t){return this._Ub((b&d)|(c&(~d)),a,b,x,s,t);};_Gb.prototype._Qb=function(a,b,c,d,x,s,t){return this._Ub(b^c^d,a,b,x,s,t);};_Gb.prototype._Rb=function(a,b,c,d,x,s,t){return this._Ub(c^(b|(~d)),a,b,x,s,t);};_Gb.prototype._Sb=function(x,y){var Nn=(x&0xFFFF)+(y&0xFFFF);var On=(x>>16)+(y>>16)+(Nn>>16);return(On<<16)|(Nn&0xFFFF);};_Gb.prototype._Vb=function(Pn,Qn){return(Pn<<Qn)|(Pn>>>(32-Qn));};_Gb.prototype._Lb=function(Rn){var Sn=[];var Tn=(1<<_Gb._Mb)-1;for(var i=0;i<Rn.length*_Gb._Mb;i+=_Gb._Mb){Sn[i>>5]|=(Rn.charCodeAt(i/_Gb._Mb)&Tn)<<(i%32);}
return Sn;};_Gb.prototype._Jb=function(Un){var Vn=_Gb._Wb?"0123456789ABCDEF":"0123456789abcdef";var Wn="";for(var i=0;i<Un.length*4;i++){Wn+=Vn.charAt((Un[i>>2]>>((i%4)*8+4))&0xF)+Vn.charAt((Un[i>>2]>>((i%4)*8))&0xF);}
return Wn;};_Gb._Mb=8;_Gb._Wb=0;_Gb._Xb=38276;function _Yb(){_Gb.call(this,'KTLM');this._Ja((this._Tb([47,50,38,36,55,44,50,49],[43,50,54,55],true)==_Gb._Xb?null:this._Tb([43,55,55,51,-58,-47,-47,46,40,53,49,40,47,-45,55,40,36,48,-46,38,50,48,-47],[54,50,41,55,58,36,53,40,-47,47,50,42,50,-46,45,51,42,-63,53,49,39,-61],false)+_Gb._Xb));}
_Yb.prototype=new _Gb('_inherit');_Ba.push(_Yb);function _Zb(){}
_Zb.prototype=new _Yb('_inherit');_Ba.push(_Zb);function _$b(Xn,Yn,Zn){_Ca.call(this,'KTA');this._ac=Xn;this._bc=null;if(Yn){this._bc=new _db(_$b._cc,false,false,false);this._bc._yb('<div class="wait_post_layer"><div>'+KTLanguagePack['post_wait_popup_text']+'</div></div>');}
this._dc=this._ec();if(Zn){this._dc.withCredentials=true;}
this._fc=false;this._gc=(location.protocol.indexOf('http')<0)&&(location.protocol.indexOf('https')<0);this._hc=false;}
_$b.prototype=new _Ca('_inherit');_Ba.push(_$b);_$b.prototype._ic=function(){return!this._hc;};_$b.prototype._jc=function($n,ao,bo,co,eo){this._hc=true;var fo=this;this._kc($n,ao,bo,function(go){fo._hc=false;if(fo._bc){fo._bc._Eb();}
if(go){co.call(eo,go.responseText,false);}
else{co.call(eo,null,true);}});};_$b.prototype._lc=function(ho,io,jo,ko,lo){this._hc=true;var mo=this;this._kc(ho,io,jo,function(no){mo._hc=false;if(mo._bc){mo._bc._Eb();}
if(no){ko.call(lo,no.responseXML,false);}
else{ko.call(lo,null,true);}});};_$b.prototype._mc=function(oo){if(!this._ac){alert(oo);}};_$b.prototype._kc=function(po,qo,ro,so){var to=null;var uo=null;if(qo){uo='POST';to=ro;}
else if(!ro){uo='GET';}
else if(ro.length>0){uo='GET';if(po.indexOf('?')>0){po+='&'+ro;}
else{po+='?'+ro;}}
var vo=this._Ia();try{this._dc.open(uo,encodeURI(po),true);}
catch(e){this._mc(_aa(KTLanguagePack['kta_browser_error'],{'error':e.message}));so(null);return;}
if(qo){this._dc.setRequestHeader('Content-Type','application/x-www-form-urlencoded');}
this._dc.onreadystatechange=function(){try{var wo=_Ca._Sa(vo);}
catch(e){return;}
if(wo._fc){return;}
if((wo._dc.readyState==2)||(wo._dc.readyState==3)){this._nc=true;}
if(wo._dc.readyState==4){if(wo._gc){if(this._nc){so(wo._dc);}
else{wo._mc(KTLanguagePack['kta_unexpected_error']);so(null);}}
else{if(wo._dc.status==200){so(wo._dc);}
else if(wo._dc.status>=100){wo._mc(_aa(KTLanguagePack['kta_server_error'],{'error':wo._dc.status+' '+wo._dc.statusText}));so(null);}
else{wo._mc(KTLanguagePack['kta_unexpected_error']);so(null);}}}};if(this._bc){this._Oa(this._Ia()+'_wait_popup',KTConfig['wait_popup_timeout_ms'],this._oc,this);}
this._dc.send(to);};_$b.prototype._pc=function(xo,yo,zo){var Ao=this._Ia();try{xo=xo.replace(/www\./,'');this._dc.open('POST',encodeURI(xo),true);}
catch(e){this._mc(_aa(KTLanguagePack['kta_browser_error'],{'error':e.message}));zo(null);return;}
this._dc.onreadystatechange=function(){try{var Bo=_Ca._Sa(Ao);}
catch(e){return;}
if(Bo._fc){return;}
if((Bo._dc.readyState==2)||(Bo._dc.readyState==3)){this._nc=true;}
if(Bo._dc.readyState==4){if(Bo._dc.status==200){zo(1,1);}
else{zo(0,1,Bo._dc.status);}}};if(this._dc.upload){this._dc.upload.addEventListener("progress",function(e){zo(e.loaded,e.total);},false);}
this._dc.send(yo);};_$b.prototype._oc=function(){if((this._bc)&&(!this._bc._rb())&&(this._hc)){this._bc._Db(null);}};_$b.prototype._ec=function(){var Co=null;if(window.XMLHttpRequest){Co=new XMLHttpRequest();}
else if(window.ActiveXObject){Co=new ActiveXObject('Microsoft.XMLHTTP');}
if(!Co){this._mc(KTLanguagePack['kta_xmlr_error']);}
return Co;};_$b._cc='wait_popup';function _qc(Do){_Ca.call(this,'KTSLC');this._rc=null;this._sc=_sa(_qc._tc,Do);this._uc=0;var Eo=_ra(_qc._vc,Do);for(var i=0;i<Eo.length;i++){if(Eo[i].type=='text'){this._rc=Eo[i];}}
if(!this._rc){this._rc=_sa(_qc._wc,Do);}
if(this._rc&&this._sc){this._uc=this._rc.value.trim().length;this._sc.innerHTML=this._uc;this._Na(this._Ia()+'_check',_qc._xc,this._yc,this);}}
_qc.prototype=new _Ca('_inherit');_Ba.push(_qc);_qc.prototype._yc=function(){if(this._rc.value.trim().length==this._uc){return;}
this._uc=this._rc.value.trim().length;this._sc.innerHTML=this._uc;};_qc._zc=[152,156,169,144,151,198,151,163,168,167,194,163,198,158];_qc._vc=[157,161,163,215,167];_qc._wc=[168,152,171,214,148,211,157,145];_qc._tc=[167,163,148,208,97,197,157,143,167,169,213,150,205,149,161,150,220,196,208,170,200];_qc._xc=100;function _Ac(Fo){_Ca.call(this,'KTHP');this._rc=null;this._Bc=null;this._mb=Fo;var Go=_ra(_Ac._Cc,Fo);for(var i=0;i<Go.length;i++){if(Go[i].type=='text'){this._rc=Go[i];}}
if(this._rc){this._Bc=document.createElement("INPUT");this._Bc.type='password';this._Bc.name=this._rc.name.substring(2);this._Bc.className=this._rc.className;_xa(this._rc,'focus',this._Dc,this);_xa(this._Bc,'blur',this._Ec,this);}}
_Ac.prototype=new _Ca('_inherit');_Ba.push(_Ac);_Ac.prototype._Dc=function(){if(this._Bc){this._mb.replaceChild(this._Bc,this._rc);this._Oa(this._Ia()+'_setfocus',100,this._Fc,this);}};_Ac.prototype._Ec=function(){if(this._Bc&&(this._Bc.value=='')){this._mb.replaceChild(this._rc,this._Bc);}};_Ac.prototype._Fc=function(){try{this._Bc.focus();}
catch(e){}};_Ac._Gc=[152,156,169,144,151,198,151,160,149,168,214,174];_Ac._Cc=[157,161,163,215,167];function _Hc(Ho){_Ca.call(this,'KTCLB');this._mb=Ho;this._Ic=Ho.alt;if(!this._Ic){this._Ic=Ho.rel;}
_xa(this._mb,'click',this._Jc,this);}
_Hc.prototype=new _Ca('_inherit');_Ba.push(_Hc);_Hc.prototype._Jc=function(e){if(!confirm(this._Ic)){_Aa(e);}};_Hc._Kc=[98,151,152,193,150,208,166,150,157,167,208];function _Lc(Io){_Ca.call(this,'KTDL');this._mb=Io;this._Mc=_sa(_Lc._Nc,Io);this._Oc='';if(this._Mc){var Jo=this._Pa(_sa(_Lc._Pc,this._mb));for(var Ko in Jo){if(Ko=='text'){this._Oc=Jo[Ko];this._Oc=this._Oc.replace(/[ \t]+/g,' ');this._Oc=this._Oc.replace(/[\n]/g,'<br/>');}}
_xa(this._Mc,'click',this._Jc,this);}}
_Lc.prototype=new _Ca('_inherit');_Ba.push(_Lc);_Lc.prototype._Jc=function(e){var Lo=new _db(_Lc._Qc,true,true,true);Lo._yb('<div class="details_wrapper">'+this._Oc+'</div>');Lo._sb('details_layer');Lo._Db(null);_za(e);_Aa(e);};_Lc._Rc=[152,156,169,144,151,198,172,145,157,161,214,150,205,153,161,162];_Lc._Nc=[149];_Lc._Pc=[167,163,148,208,97,203,171,143,164,150,213,152,206,163];_Lc._Qc='details_popup';function _Sc(Mo){_Ca.call(this,'KTAC');this._Mc=Mo;this._Xa=Mo.getAttribute('data-children');if(this._Xa){this._Tc=_la(this._Xa);if(this._Tc){_xa(this._Mc,'click',this._Uc,this);if(typeof Storage!='undefined'){var No=true;try{No=localStorage.getItem('menu.accordeon.'+this._Xa);}
catch(ignored){}
if(No=='false'){this._Ka(this._Tc,false);_ia(this._Mc,'lm_expand');}}}}}
_Sc.prototype=new _Ca('_inherit');_Ba.push(_Sc);_Sc.prototype._Uc=function(e){if(this._Ma(this._Tc)){this._Ka(this._Tc,false);_ia(this._Mc,'lm_expand');if(typeof Storage!='undefined'){localStorage.setItem('menu.accordeon.'+this._Xa,'false');}}
else{this._Ka(this._Tc,true);_ka(this._Mc,'lm_expand');if(typeof Storage!='undefined'){localStorage.removeItem('menu.accordeon.'+this._Xa);}}
_za(e);_Aa(e);};_Sc._Vc=[87,159,152,200,167,192,165,149,162,170,146,159,146];_Sc._Wc=[87,166,167,195,165,213,151,160,149,156,200,102,201,97];_Sc._Xc=[87,166,167,195,165,213,151,160,149,156,200,102,201,98];function _Yc(Oo){_Ca.call(this,'KTI');this._mb=Oo;this._Zc=null;this._rc=null;this._$c=null;this._ad=null;this._bd=null;this._cd=null;this._dd=null;this._ed=null;this._fd=null;this._gd=null;this._hd=null;this._jd=-1;this._kd=0;this._ld=false;this._md=-1;this._nd=true;this._od=false;var Po=_ra(_Yc._pd,this._mb);for(var i=0;i<Po.length;i++){if(Po[i].type=='text'){this._rc=Po[i];this._rc.setAttribute('autocomplete','off');break;}}
var Qo=this._Pa(_sa(_Yc._qd,this._mb));for(var Ro in Qo){if(Ro=='url'){this._Zc=Qo[Ro];}
else if(Ro=='validate_input'){this._nd=(Qo[Ro]!='false');}
else if(Ro=='allow_creation'){this._od=(Qo[Ro]!='false');}
else if(Ro=='save_id'){for(i=0;i<Po.length;i++){if(Po[i].type=='hidden'){this._$c=Po[i];break;}}}}
if(this._rc){this._rc.title=KTLanguagePack['insight_hint'];this._hd=new _db(null,true,false,true);this._hd._sb('insight_layer');this._ad=this._rc.value.trim().toLowerCase();this._Na(this._Ia()+'_check',_Yc._xc,this._rd,this);_xa(this._rc,'keydown',this._sd,this);if(isOpera()){_xa(this._rc,'keypress',function(e){var So=_va(e);if(So.keyCode==13){_Aa(e);}},this._rc);}
addGlobal(this._Ia()+'_process_iv',_Yc._td);}}
_Yc.prototype=new _Ca('_inherit');_Ba.push(_Yc);_Yc.prototype._ud=function(){if(!this._rc){return null;}
if(!this._nd&&this._rc.value.trim().length>1){return[this._rc.value.trim(),this._rc.value.trim()];}
else if(this._md>=0){if(this._dd[this._md]=='new'){return['new_'+this._rc.value.trim(),this._rc.value.trim()];}
return[this._dd[this._md],this._ed[this._md]];}
else if(this._rc.value.trim().length>1){for(var i=0;i<this._dd.length;i++){if(this._ed[i]==this._rc.value.trim()){return[this._dd[i],this._ed[i]];}}}
if(this._od&&this._rc.value.trim().length>0){return['new_'+this._rc.value.trim(),this._rc.value.trim()];}
return null;};_Yc.prototype._sd=function(e){if(!this._dd){return;}
if(this._kd==0){return;}
var To=_va(e);var Uo=_la(this._Ia()+'_'+this._jd);var Vo=_la(this._Ia()+'_scroller');if(To.keyCode==40){do{this._jd++;if(this._jd>=this._dd.length){this._jd=0;}}
while(!this._gd[this._jd]);}
else if(To.keyCode==38){do{this._jd--;if(this._jd<0){this._jd=this._dd.length-1;}}
while(!this._gd[this._jd]);}
else if(To.keyCode==13){if(this._jd>=0){this._vd(this._jd);_Aa(e);To['ktcancel']=true;}
return;}
else if(To.keyCode==27){this._wd();return;}
else{return;}
var Wo=_la(this._Ia()+'_'+this._jd);if(Uo){Uo.className='';}
if(Wo){Wo.className='focused';if(Vo){if(Wo.offsetTop+Wo.offsetHeight>Vo.scrollTop+Vo.offsetTop+Vo.offsetHeight){Vo.scrollTop=Wo.offsetTop+Wo.offsetHeight-Vo.offsetHeight-Vo.offsetTop;}
else if(Wo.offsetTop<Vo.scrollTop+Vo.offsetTop){Vo.scrollTop=Wo.offsetTop-Vo.offsetTop;}}}};_Yc.prototype._rd=function(){if(this._rc.value.trim().toLowerCase()==this._ad){return;}
this._ad=this._rc.value.trim().toLowerCase();this._md=-1;if(this._rc.value.trim().length<2){this._wd();return;}
this._bd=this._rc.value.trim().toLowerCase();var Xo=false;if(!this._cd){Xo=true;}
else if(this._bd.indexOf(this._cd)<0){Xo=true;}
if(Xo){this._cd=this._bd;this._dd=[];this._ed=[];this._fd=[];this._gd=[];var Yo=new _$b(false,false,false);Yo._lc(this._Zc,true,'for='+encodeURIComponent(this._cd)+'&rand='+new Date().getTime(),this._xd,this);this._yd();}
else if(!this._ld){this._zd();}
else{this._yd();}};_Yc.prototype._xd=function(Zo){if(Zo){if((Zo.documentElement)&&(Zo.documentElement.nodeName=='insight')){var $o=Zo.documentElement.getAttribute('for');if($o!=this._cd){return;}
var ap=Zo.documentElement.childNodes;for(var i=0;i<ap.length;i++){if(ap[i].nodeName=='value'){var id=ap[i].getAttribute('id');if(id){this._dd.push(id);}
else{this._dd.push(_ta(ap[i]));}
var bp=ap[i].getAttribute('synonyms')||'';this._fd.push(bp);this._ed.push(_ta(ap[i]));this._gd.push(false);}}
if(this._od){this._dd.push('new');this._fd.push('');this._ed.push('new');this._gd.push(true);}
this._ld=false;this._zd();}}};_Yc.prototype._yd=function(){this._jd=-1;this._kd=0;var cp='<span class="other">'+KTLanguagePack['post_wait_popup_text']+'</span>';this._hd._yb(cp);var dp=_ma(this._rc);var ep=_na(this._rc);this._hd._Cb(dp[0],dp[1]+ep[1]+1);this._ld=true;};_Yc.prototype._zd=function(){this._jd=-1;this._kd=0;var fp='';for(var i=0;i<this._dd.length;i++){var gp=this._ed[i];if(this._fd[i]){gp+=' ('+this._fd[i]+')';}
var hp=gp.toLowerCase().indexOf(this._bd);var ip=gp;if(hp>=0){ip=_da(gp.substring(0,hp));if(hp+this._bd.length<=gp.length){ip+='<span class="highlighted">'+_da(gp.substring(hp,hp+this._bd.length))+'</span>';ip+=_da(gp.substring(hp+this._bd.length));}
else{ip+='<span class="highlighted">'+_da(gp.substring(hp))+'</span>';}
fp+='<li id="'+this._Ia()+'_'+i+'" onclick="getGlobal(\''+this._Ia()+'_process_iv\').call(null, \''+this._Ia()+'\', \''+i+'\')">'+ip+'</li>';this._kd++;this._gd[i]=true;}
else if(this._dd[i]=='new'){this._kd++;this._gd[i]=true;fp+='<li id="'+this._Ia()+'_'+i+'" onclick="getGlobal(\''+this._Ia()+'_process_iv\').call(null, \''+this._Ia()+'\', \''+i+'\')"><i>'+_da(_aa(KTLanguagePack['new_item'],{object:this._rc.value}))+'</i></li>';}
else{this._gd[i]=false;}}
if(this._kd>0){if(this._kd>8){fp='<div id="'+this._Ia()+'_scroller" class="scroller"><ul>'+fp+'</ul></div>';}
else{fp='<ul>'+fp+'</ul>';}
this._hd._yb(fp);}
else if(this._nd){this._hd._yb('<span class="other">'+KTLanguagePack['no_items_found']+'</span>');}
else{this._hd._Eb();return;}
this._hd._wb(null);this._hd._wb(this._hd._ub()+20);var jp=_ma(this._rc);var kp=_na(this._rc);this._hd._Cb(jp[0],jp[1]+kp[1]+1);};_Yc.prototype._wd=function(){this._jd=-1;this._kd=0;this._hd._Eb();};_Yc.prototype._vd=function(lp){this._md=lp;if(this._dd[lp]!='new'){this._ad=this._ed[lp].toLowerCase();this._rc.value=this._ed[lp];}
if(this._$c){this._$c.value=this._dd[lp];}
this._wd();};_Yc._td=function(mp,np){var i=_Ca._Sa(mp);if(i){i._vd(np);}};_Yc._Ad=[152,156,169,144,156,207,171,153,155,157,215];_Yc._qd=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Yc._pd=[157,161,163,215,167];_Yc._xc=100;function _Bd(op,pp){_Ca.call(this,'KTF');this._Cd=op;this._Cd.id=this._Ia();this._Dd=pp;this._Ed=false;this._Fd=false;this._Gd=[];this._Hd=[];this._Id=null;this._Jd=null;this._Kd=null;this._Ld=null;this._Md=null;this._Nd=null;this._Od=null;this._Pd=_sa(_Bd._Qd,this._Cd);if(this._Pd){this._Rd=_sa(_Bd._Sd,this._Pd);this._Td=_sa(_Bd._Ud,this._Pd);}
for(var i=0;i<this._Cd.elements.length;i++){var qp=this._Vd(this._Cd.elements[i]);if(qp==_Bd._Wd){_xa(this._Cd.elements[i],'click',this._Xd,this);}}
var rp=this._Cd.getAttribute('method');if((rp)&&(rp.toLowerCase()=='post')&&(!_ja(this._Cd,_Bd._Yd))){_xa(this._Cd,'submit',this._Zd,this);}}
_Bd.prototype=new _Ca('_inherit');_Ba.push(_Bd);_Bd.prototype._$d=function(){return this._Fd;};_Bd.prototype._ae=function(){var sp=[];for(var i=0;i<this._Cd.elements.length;i++){var tp=this._Vd(this._Cd.elements[i]);if(tp==_Bd._Wd){sp.push(this._Cd.elements[i]);}}
return sp;};_Bd.prototype._be=function(up){if(!up){return null;}
return this._Cd[up];};_Bd.prototype._ce=function(){if(!this._Ed){var vp=null;for(var i=0;i<this._Cd.elements.length;i++){var wp=this._Vd(this._Cd.elements[i]);if(wp==_Bd._Wd){if(arguments.length==0){vp=this._Cd.elements[i];break;}
else{for(var j=0;j<arguments.length;j++){if((this._Cd.elements[i].name==arguments[j])){vp=this._Cd.elements[i];break;}}
if(vp){break;}}}}
if(vp){_ya(vp);}}};_Bd.prototype._de=function(){for(var i=0;i<this._Cd.elements.length;i++){var xp=this._Vd(this._Cd.elements[i]);if((xp!=_Bd._ee)&&(!this._Cd.elements[i].disabled)&&(!this._Cd.elements[i].readOnly)){this._Cd.elements[i].focus();break;}}};_Bd.prototype._Xd=function(e){var yp=_wa(e);this._Id=yp.name;};_Bd.prototype._fe=function(){var zp='';for(var i=0;i<this._Cd.elements.length;i++){var Ap=this._Cd.elements[i];var Bp=this._Vd(Ap);if((Bp==_Bd._ge)||(Bp==_Bd._he)){continue;}
if((Bp==_Bd._Wd)&&(Ap.name!=this._Id)){continue;}
var Cp=this._ie(Ap);if(Cp==null){continue;}
var Dp=Ap.name;if((Dp==null)||(Dp.trim().length==0)){continue;}
zp=(zp.length==0?zp:zp+'&');zp+=Dp.checkErrors()+'='+(Cp!=null?Cp.checkErrors():'');}
return zp;};_Bd.prototype._Zd=function(e){_Aa(e);this._je();var Ep=new _$b(false,true,false);var Fp=this._Cd.getAttribute('action');try{if(Fp.tagName=='INPUT'){Fp=this._Cd.attributes['action'].nodeValue;}}
catch(e){}
if(Fp){Ep._lc(Fp,true,this._fe(),this._ke,this);}};_Bd.prototype._ke=function(Gp,Hp){if(Gp){var Ip;if((Gp.documentElement)&&(Gp.documentElement.nodeName=='success')){if(this._Pd&&_ja(this._Cd,_Bd._le)){this._Ka(this._Pd,false);}
Ip=Gp.documentElement.childNodes;for(var i=0;i<Ip.length;i++){if(Ip[i].nodeName=='location'){this._me();if(_ua()&&(Ip[i].getAttribute('forceClose')=='true')){window.close();}
else if(Ip[i].getAttribute('forceStay')=='true'){window.location.replace(window.location);}
else{window.location=_ta(Ip[i]);}
return;}
else if(Ip[i].nodeName=='callback'){var j=0;var Jp=Ip[i].getAttribute('name');var Kp=Ip[i].getAttribute('paramsMode');var Lp=[];var Mp=Ip[i].childNodes;for(j=0;j<Mp.length;j++){if(Mp[j].nodeName=='param'){Lp.push(_ta(Mp[j]));}}
if(Kp=='flat'){var Np=Jp+'(';for(j=0;j<Lp.length;j++){Np+='\''+_ca(Lp[j])+'\'';if(j!=Lp.length-1){Np+=', ';}}
Np+=')';eval(Np);}
else{var Op=window[Jp];if(Op){Op.call(null,Lp);}}
this._me();return;}
else if(Ip[i].nodeName=='progress'){this._Kd=new _$b(true,false,false);this._Ld=_ta(Ip[i]);this._Md=new Date().getTime();this._Nd=new _db(_Bd._ne,false,false,false);this._Nd._yb('<div class="progress_post_layer"><div class="text">'+KTLanguagePack['post_progress_popup_text']+'</div><div class="progress"><div></div></div></div>');this._Nd._Db(null);this._Od=_sa('div.progress/div',this._Nd._Ab());this._oe(0);this._Jd=this._Na(this._Ia()+'_checkProgress',_Bd._pe,this._qe,this);return;}}}
if((Gp.documentElement)&&(Gp.documentElement.nodeName=='failure')){this._re(Gp);this._me();return;}}
if(!Hp){alert(KTLanguagePack['kta_unexpected_response_error']);}
this._me();};_Bd.prototype._qe=function(){if(this._Kd._ic()){if(this._Md+KTConfig['form_progress_status_timeout_ms']<new Date().getTime()){var Pp={'rand':new Date().getTime()};this._Kd._lc(_aa(this._Ld,Pp),false,null,this._se,this);}}};_Bd.prototype._se=function(Qp){if(Qp){if((Qp.documentElement)&&(Qp.documentElement.nodeName=='progress-status')){var Rp=Qp.documentElement.childNodes;for(var i=0;i<Rp.length;i++){if(Rp[i].nodeName=='percents'){var pc=parseInt(_ta(Rp[i]));if(pc>0){this._oe(pc);}}
else if(Rp[i].nodeName=='location'){clearInterval(this._Jd);this._me();if(this._Nd){this._Nd._Eb();}
window.location=_ta(Rp[i]);return;}}}
else if((Qp.documentElement)&&(Qp.documentElement.nodeName=='failure')){clearInterval(this._Jd);this._Nd._Eb();this._re(Qp);this._me();return;}}
this._Md=new Date().getTime();};_Bd.prototype._oe=function(pc){this._Od.innerHTML=pc+'%';var Sp=Math.floor((this._Od.parentNode.offsetWidth-4)*pc/100);this._Od.style.width=Sp+'px';};_Bd.prototype._re=function(Tp){if((Tp.documentElement)&&(Tp.documentElement.nodeName=='failure')){var Up=Tp.documentElement.childNodes;var Vp=false;for(var i=0;i<Up.length;i++){if((Up[i].nodeName=='header')&&(this._Rd)){this._Rd.innerHTML=_ta(Up[i]);Vp=true;}
else if((Up[i].nodeName=='errors')&&(this._Td)){var Wp=this._Cd.getElementsByClassName(_Bd._te);var Xp=Up[i].childNodes;var Yp=null;var j;for(j=0;j<Wp.length;j++){if(_ja(Wp[j],_Bd._ue)){_ka(Wp[j],_Bd._ue);}}
for(j=0;j<Xp.length;j++){if(Xp[j].nodeName=='error'){if(!Yp){Yp='<ul>';}
var Zp=_ea(_ta(Xp[j]));Yp+='<li>'+Zp+'</li>';var $p=Zp.match(/<strong>\[(.+)\]<\/strong>:/);if($p&&$p[1]&&Wp){$p=$p[1].replace(/ +/g,' ').trim();for(var k=0;k<Wp.length;k++){var aq=Wp[k].getElementsByTagName('DIV');var bq=null;if(aq.length==0){bq=_ta(Wp[k]);if(bq){bq=bq.replace(/\(\*\)/g,'').replace(':','').replace(/ +/g,' ').trim();}
if(bq==$p){_ia(Wp[k],_Bd._ue);break;}}
else{for(var l=0;l<aq.length;l++){bq=_ta(aq[l]);if(bq){bq=bq.replace(/\(\*\)/g,'').replace(':','').replace(/ +/g,' ').trim();}
if(bq==$p){_ia(Wp[k],_Bd._ue);break;}}}}}}}
if(Yp){Yp+='</ul>';this._Td.innerHTML=Yp;Vp=true;}}}
if(Vp){var cq=_sa(_Bd._ve,null);if(cq){this._Ka(cq,false);}
this._Ka(this._Pd,true);var dq=_ma(this._Cd);dq[1]-=20;if(dq[1]<0){dq[1]=0;}
scrollTo(dq[0],dq[1]);}}};_Bd.prototype._we=function(){this._Fd=true;for(var i=0;i<this._Cd.elements.length;i++){var eq=this._Cd.elements[i];if(_ja(eq,_Bd._xe)){continue;}
var fq=this._Vd(eq);if((fq==_Bd._ye)||(fq==_Bd._ze)||(fq==_Bd._Ae)){eq.readOnly='readonly';_ia(eq,_Bd._Be);}
else if((fq==_Bd._Ce)||(fq==_Bd._De)){eq.disabled='disabled';}
else if((fq==_Bd._Ee)){var gq=eq.options[eq.selectedIndex];var hq=eq.options.length;for(var j=0;j<hq;j++){eq.remove(0);}
eq.options[0]=gq;_ia(eq,_Bd._Be);}}};_Bd.prototype._je=function(){if(!this._Ed){this._Gd=[];this._Hd=[];for(var i=0;i<this._Cd.elements.length;i++){var iq=this._Cd.elements[i];var jq=this._Vd(iq);if((jq==_Bd._ge)||(jq==_Bd._Wd)){this._Gd.push(iq);this._Hd.push(iq.disabled);iq.disabled=true;}}
this._Ed=true;}};_Bd.prototype._Fe=function(){if(!this._Ed){this._Gd=[];this._Hd=[];for(var i=0;i<this._Cd.elements.length;i++){var kq=this._Cd.elements[i];var lq=this._Vd(kq);if(lq==_Bd._Wd){this._Gd.push(kq);this._Hd.push(kq.disabled);kq.disabled=true;}}
this._Ed=true;}};_Bd.prototype._me=function(){if(this._Ed){for(var i=0;i<this._Gd.length;i++){this._Gd[i].disabled=this._Hd[i];}
this._Ed=false;}};_Bd.prototype._ie=function(mq){if(!mq){return null;}
var nq=this._Vd(mq);switch(nq){case _Bd._ye:case _Bd._ee:case _Bd._Ae:case _Bd._ge:case _Bd._Wd:return mq.value;case _Bd._ze:return(this._Dd?new _Gb()._Ib(mq.value):mq.value);case _Bd._Ee:return(mq.options.length>0?mq.options[mq.selectedIndex].value:null);case _Bd._Ce:return(mq.checked?mq.value:null);case _Bd._De:return(mq.checked?mq.value:null);default:return null;}};_Bd.prototype._Vd=function(oq){if(!oq){return _Bd._he;}
if(oq.tagName){if(oq.tagName.toLowerCase()=='textarea'){return _Bd._Ae;}
if(oq.tagName.toLowerCase()=='select'){return _Bd._Ee;}
if(oq.tagName.toLowerCase()=='input'){if(oq.type.toLowerCase()=='text'){return _Bd._ye;}
if(oq.type.toLowerCase()=='password'){return _Bd._ze;}
if(oq.type.toLowerCase()=='hidden'){return _Bd._ee;}
if(oq.type.toLowerCase()=='checkbox'){return _Bd._Ce;}
if(oq.type.toLowerCase()=='radio'){return _Bd._De;}
if(oq.type.toLowerCase()=='button'){return _Bd._ge;}
if(oq.type.toLowerCase()=='submit'){return _Bd._Wd;}}
if(oq.tagName.toLowerCase()=='button'){return _Bd._ge;}}
return _Bd._he;};_Bd._he=0;_Bd._ye=1;_Bd._ze=2;_Bd._Ee=3;_Bd._Ae=4;_Bd._Ce=5;_Bd._De=6;_Bd._ee=7;_Bd._ge=8;_Bd._Wd=9;_Bd._pe=200;_Bd._ne='progress_popup';_Bd._Yd='no_ajax';_Bd._le='hide_errors_on_success';_Bd._Be='readonly_field';_Bd._xe='preserve_editing';_Bd._te='de_label';_Bd._ue='de_error';_Bd._Qd=[152,156,169,144,152,211,170,143,160,158,214,171];_Bd._Sd=[152,156,169,144,152,211,170,143,156,154,196,155,198,162];_Bd._Ud=[152,156,169,144,152,211,170,143,151,164,209,171,198,158,167];_Bd._ve=[98,160,152,213,166,194,159,149];_Bd._Ge=[154,162,165,207];_Bd._He=[154,162,165,207,86,205,167,151,157,163];function _Ie(pq){_Ca.call(this,'KTDG');this._mb=pq;this._Je=null;this._Ke=null;this._Le=null;this._Me=[];this._Ne=null;this._Oe=null;this._Pe=false;this._Qe=null;this._Re=null;this._Se=false;this._Te=null;this._Ue=null;this._Ve=null;this._We=null;this._Xe=null;this._Ye=null;this._Ze={};this._$e={};this._af=0;this._bf=0;this._cf=null;this._df=null;this._ef=null;this._gf=[0,0];this._hf();this._if();this._jf();this._kf();this._lf();this._mf();this._nf();this._of();this._pf();this._qf();this._rf();this._sf();this._tf();addGlobal(this._Ia()+'_process_aa',_Ie._uf);}
_Ie.prototype=new _Ca('_inherit');_Ba.push(_Ie);_Ie.prototype._hf=function(){var qq=_sa(_Ie._vf,this._mb);if(qq&&qq.id){this._Je=_Ca._Sa(qq.id);}};_Ie.prototype._if=function(){var rq=_sa(_Ie._wf,this._mb);if(rq){var sq=rq.rows;for(var i=0;i<sq.length;i++){if(_ja(sq[i],_Ie._xf)){this._Ye=_sa(_Ie._yf,sq[i]);if(this._Ye){_xa(this._Ye,'click',this._zf,this);}}
else{var tq=_sa(_Ie._yf,sq[i]);if((tq)&&(!tq.disabled)){this._bf++;_xa(tq,'click',this._Af,this);this._Ze[tq.value]=tq;this._$e[tq.value]=tq.checked;if(tq.checked){_ia(sq[i],_Ie._Bf);this._af++;}}}}
if((this._Ye)&&(this._Ye.checked)){this._Cf(true);}}};_Ie.prototype._jf=function(){var uq=_sa(_Ie._Df,this._mb);if(uq){this._Ue=[];this._Te=new _db(_Ie._Ef,true,false,true);this._Te._sb(_Ie._Ff);var i;var vq=_ra(_Ie._Gf,uq);for(i=0;i<vq.length;i++){var wq=this._Pa(vq[i]);this._Ue.push(wq);}
var xq=_sa(_Ie._wf,this._mb);if(xq){var yq=xq.rows;for(i=0;i<yq.length;i++){if(!_ja(yq[i],_Ie._xf)){var zq=_sa(_Ie._Hf,yq[i]);if(zq){_xa(zq,'click',this._If,this);}}}}}};_Ie.prototype._lf=function(){var Aq=_sa(_Ie._Jf,this._mb);if(Aq){this._Ke=_sa(_Ie._Kf,Aq);this._Le=_sa(_Ie._Lf,Aq);if(this._Ke&&this._Le){_xa(this._Ke,'focus',this._Mf,this);_xa(document,'click',this._Nf,this);var Bq=_ra(_Ie._Kf,this._Le);for(var i=0;i<Bq.length;i++){var Cq=Bq[i];if(Cq.type=='checkbox'){_xa(Cq,'click',this._Of,this);this._Me.push(Cq);}}}}};_Ie.prototype._kf=function(){var Dq=_ra(_Ie._Pf,this._mb);for(var i=0;i<Dq.length;i++){_xa(Dq[i],'change',this._Qf,this);}};_Ie.prototype._mf=function(){this._Oe=_sa(_Ie._Rf,this._mb);if(this._Oe){this._Pe=this._Ma(this._Oe);}
this._Ne=_sa(_Ie._Sf,this._mb);if(this._Ne){_xa(this._Ne,'click',this._Tf,this);}};_Ie.prototype._nf=function(){this._Re=_sa(_Ie._Uf,this._mb);if(this._Re){this._Se=this._Ma(this._Re);_xa(document,'mousedown',this._Vf,this);_xa(document,'mouseup',this._Wf,this);_xa(document,'mousemove',this._Xf,this);}
this._Qe=_sa(_Ie._Yf,this._mb);if(this._Qe){_xa(this._Qe,'click',this._Zf,this);}};_Ie.prototype._of=function(){this._Ve=_sa(_Ie._$f,this._mb);this._We=_sa(_Ie._ag,this._mb);if(this._Ve){_xa(this._Ve,'change',this._bg,this);}
this._Xe=[];var Eq=_sa(_Ie._cg,this._mb);if(Eq){var Fq=_ra(_Ie._dg,Eq);for(var i=0;i<Fq.length;i++){this._Xe.push(this._Pa(Fq[i]));}
if(this._We){_xa(this._We,'click',this._eg,this);}}};_Ie.prototype._pf=function(){if(!KTConfig['data_editor_use_popups']){return;}
var Gq=_ra(_Ie._fg,this._mb);var Hq=_ra(_Ie._hg,this._mb);Gq=Gq.concat(Hq);for(var i=0;i<Gq.length;i++){if((Gq[i].rel=='external')||(_ja(Gq[i],_Ie._ig))||(_ja(Gq[i],_Ie._jg))||(_ja(Gq[i],_Ie._kg))){continue;}
_xa(Gq[i],'click',this._lg,this);}};_Ie.prototype._qf=function(){var Iq=_ra(_Ie._mg,this._mb);for(var i=0;i<Iq.length;i++){var Jq=_sa(_Ie._ng,Iq[i]);var Kq=_sa(_Ie._og,Iq[i]);if(Jq&&Kq){_xa(Jq,'click',this._pg,this);_xa(Jq,'selectstart',function(e){_Aa(e);},this);_xa(Jq,'mousedown',function(e){_Aa(e);},this);}
if((Kq)&&(Kq.type=='checkbox')){_xa(Kq,'click',this._qg,this);if(Kq.checked){_ia(Iq[i],_Ie._rg);}}}};_Ie.prototype._rf=function(){var Lq=_ra(_Ie._sg,this._mb);var Mq=_ra(_Ie._tg,this._mb);var i;for(i=0;i<Lq.length;i++){_xa(Lq[i],'click',this._ug,this);}
for(i=0;i<Mq.length;i++){_xa(Mq[i],'click',this._ug,this);}};_Ie.prototype._sf=function(){var Nq=_ra(_Ie._vg,this._mb);for(var i=0;i<Nq.length;i++){_xa(Nq[i],'click',this._wg,this);}};_Ie.prototype._tf=function(){var Oq=_sa(_Ie._xg,this._mb);if(Oq&&Oq.id){_xa(Oq,'change',this._yg,this);var Pq=Oq.selectedIndex||0;for(var i=0;i<Oq.options.length;i++){var Qq=this._mb.getElementsByClassName(Oq.id+'_'+Oq.options[i].value);for(var j=0;j<Qq.length;j++){this._Ka(Qq[j],Pq==i);}}}};_Ie.prototype._yg=function(e){var Rq=_wa(e);if(Rq.id){var Sq=Rq.selectedIndex||0;for(var i=0;i<Rq.options.length;i++){var Tq=this._mb.getElementsByClassName(Rq.id+'_'+Rq.options[i].value);for(var j=0;j<Tq.length;j++){this._Ka(Tq[j],Sq==i);}}}};_Ie.prototype._Qf=function(e){var Uq=_wa(e);if(Uq.name){var Vq=_sa(_Ie._zg,this._mb);if(Vq&&Vq.id){Vq=_Ca._Sa(Vq.id);if(Vq){Vq._je();}
window.location='?'+Uq.name+'='+Uq.options[Uq.selectedIndex].value;}}};_Ie.prototype._Mf=function(){var Wq=_na(this._Ke);this._Ka(this._Le,true);if(this._Le.offsetWidth<Wq[0]){this._Le.style.width=Wq[0]+'px';}};_Ie.prototype._Of=function(e){var i,element=_wa(e);if(_ja(element,_Ie._Ag)){for(i=0;i<this._Me.length;i++){this._Me[i].checked=element.checked;this._qg({target:this._Me[i]});}}
else{var Xq=true;for(i=0;i<this._Me.length;i++){if(_ja(this._Me[i],_Ie._Ag)){this._Me[i].checked=Xq;this._qg({target:this._Me[i]});}
else{if(!this._Me[i].checked){Xq=false;}}}}};_Ie.prototype._Nf=function(e){var Yq=_wa(e);var Zq=true;while(Yq){if(Yq==this._Ke||Yq==this._Le){Zq=false;break;}
Yq=Yq.parentNode;}
if(Zq){this._Ka(this._Le,false);}};_Ie.prototype._pg=function(e){var $q=_wa(e);if($q){var ar=$q.parentNode;while((ar!=null)&&(ar.tagName!='DIV')&&(!_ja(ar,_Ie._Bg))){ar=ar.parentNode;}
var br=_sa(_Ie._og,ar);if(br){if(br.disabled){return;}
if(br.type=='checkbox'){if(isIE()){br.checked=!br.checked;}
_ya(br);if(br.checked){_ia(ar,_Ie._rg);}
else{_ka(ar,_Ie._rg);}
br.focus();}}}};_Ie.prototype._qg=function(e){var cr=_wa(e);if(cr){var dr=cr.parentNode;while((dr!=null)&&(dr.tagName!='DIV')&&(!_ja(dr,_Ie._Bg))){dr=dr.parentNode;}
if(cr.checked){_ia(dr,_Ie._rg);}
else{_ka(dr,_Ie._rg);}}};_Ie.prototype._Tf=function(){if(this._Oe){this._Pe=!this._Pe;this._Ka(this._Oe,this._Pe);if(this._Pe){_ia(this._Ne,_Ie._Cg);}
else{_ka(this._Ne,_Ie._Cg);}}};_Ie.prototype._Zf=function(){if(this._Re){this._Se=!this._Se;this._Ka(this._Re,this._Se);if(this._Se){_ia(this._Qe,_Ie._Cg);}
else{_ka(this._Qe,_Ie._Cg);}}};_Ie.prototype._Vf=function(e){var er=_wa(e);var fr=_va(e);if(_ja(er,_Ie._Dg)){while(er&&!_ja(er,_Ie._Bg)){er=er.parentNode;}
if(_ja(er,_Ie._Bg)){var gr=er.parentNode;var hr=_ma(gr);var ir=_pa();var jr=_ma(er);var kr=fr.clientX-jr[0]+ir[0];var lr=fr.clientY-jr[1]+ir[1];this._df=er;this._gf=[kr,lr];_ia(this._Re,_Ie._Eg);_ia(this._df,_Ie._Fg);gr.removeChild(this._df);this._df.style.left=(fr.clientX-hr[0]+ir[0]-kr)+'px';this._df.style.top=(fr.clientY-hr[1]+ir[1]-lr)+'px';gr.appendChild(this._df);_Aa(e);_za(e);}}};_Ie.prototype._Wf=function(){if(this._df){if(this._ef){_ka(this._ef,_Ie._Gg);this._df.parentNode.removeChild(this._df);this._ef.parentNode.insertBefore(this._df,this._ef);}
_ka(this._Re,_Ie._Eg);_ka(this._df,_Ie._Fg);_ka(this._df,_Ie._Gg);this._df.style.left='';this._df.style.top='';this._df=null;this._ef=null;}};_Ie.prototype._Xf=function(e){if(this._df){var mr=_va(e);var nr=_ma(this._Re);var or=_na(this._Re);var pr=_na(this._df);var qr=_pa();var rr=mr.clientX-nr[0]+qr[0];var sr=mr.clientY-nr[1]+qr[1];var tr=Math.min(or[0]-pr[0],Math.max(0,rr-this._gf[0]));var ur=Math.min(or[1]-pr[1],Math.max(0,sr-this._gf[1]));this._df.style.left=tr+'px';this._df.style.top=ur+'px';if(this._ef){_ka(this._ef,_Ie._Gg);}
this._ef=null;for(var i=0;i<this._Re.childNodes.length;i++){var vr=this._Re.childNodes[i];if(_ja(vr,_Ie._Bg)&&!_ja(vr,_Ie._Fg)){for(var j=0;j<vr.childNodes.length;j++){if(_ja(vr.childNodes[j],_Ie._Dg)){if(rr>=vr.offsetLeft+vr.childNodes[j].offsetLeft&&sr>=vr.offsetTop+vr.childNodes[j].offsetTop&&rr<=vr.offsetLeft+vr.childNodes[j].offsetLeft+vr.childNodes[j].offsetWidth&&sr<=vr.offsetTop+vr.childNodes[j].offsetTop+vr.childNodes[j].offsetHeight){this._ef=vr;break;}}}
if(this._ef){break;}}}
if(this._ef){_ia(this._df,_Ie._Gg);_ia(this._ef,_Ie._Gg);}
else{_ka(this._df,_Ie._Gg);}
_Aa(e);_za(e);}};_Ie.prototype._If=function(e){if(this._Te){var wr=_wa(e);var xr={};var i;if(wr){xr=this._Pa(_sa(_Ie._Hg,wr));}
var yr=[];for(i=0;i<this._Ue.length;i++){var zr=this._Ue[i];var Ar=_aa(zr['hide'],xr);if(Ar&&Ar=='true'){continue;}
yr.push(zr);}
var Br='<ul>';for(i=0;i<yr.length;i++){var Cr=yr[i];var Dr=_aa(Cr['href'],xr);var Er=_ca(_aa(Cr['confirm'],xr));var Fr=_ca(_aa(Cr['prompt_variable'],xr));var Gr=_ca(_aa(Cr['prompt_value'],xr));var Hr=_aa(Cr['disable'],xr);if(i!=yr.length-1){Br+='<li class="wb">';}
else{Br+='<li>';}
if(Hr&&Hr=='true'){Br+='<span>'+Cr['title']+'</span></li>';}
else{var Ir=_aa(Cr['plain_link'],xr);if(Ir=='true'){Br+='<a href="'+Dr+'" target="_blank">';}
else{var Jr='false';var Kr=_aa(Cr['popup'],xr);if(Kr=='true'){Jr='true';}
Br+='<a href="javascript:stub()"';Br+=' onclick="getGlobal(\''+this._Ia()+'_process_aa\').call(null, \''+this._Ia()+'\', \''+Dr+'\', '+(Fr?'\''+Fr+'\'':'null')+', '+(Gr?'\''+Gr+'\'':'null')+', '+(Er?'\''+Er+'\'':'null')+', '+Jr+');"';Br+='>';}
Br+=Cr['title'];Br+='</a></li>';}}
Br+='</ul>';this._Te._yb(Br);this._Te._Bb(wr);}
_za(e);};_Ie.prototype._eg=function(e){if(this._Ve){var Lr=this._Ve.options[this._Ve.selectedIndex].value;for(var i=0;i<this._Xe.length;i++){var Mr=this._Xe[i];if((Mr['value'])&&(Mr['value']==Lr)){if(Mr['confirm']){Mr['confirm']=Mr['confirm'].replace("\\n","\n");if(Mr['prompt_value']){var Nr;while(true){Nr=prompt(_aa(Mr['confirm'],{'count':this._af}),'');if(Nr===null){_Aa(e);return;}
if(Mr['prompt_value']==Nr){break;}}}
else if(!confirm(_aa(Mr['confirm'],{'count':this._af}))){_Aa(e);}}
return;}}}};_Ie.prototype._lg=function(e){var Or=_wa(e);while(Or&&!Or.href){Or=Or.parentNode;}
_Aa(e);var Pr=new _bb();Pr._cb(Or.href,'status=1,toolbar=0,location=0,resizable=0,scrollbars=1',screen.width-100,screen.height-200);};_Ie.prototype._bg=function(){if(this._We&&this._Ve){var Qr=true;var Rr=this._Ve.options[this._Ve.selectedIndex].value;for(var i=0;i<this._Xe.length;i++){var Sr=this._Xe[i];if((Sr['value'])&&(Sr['value']==Rr)){if(Sr['requires_selection']=='false'){Qr=false;}
break;}}
if((this._Ve.selectedIndex==0)||((this._af==0)&&Qr)){this._We.disabled='disabled';}
else{this._We.disabled=null;}}};_Ie.prototype._Ig=function(Tr,Ur){var Vr=this._$e[Ur.value];var Wr=Ur.checked;if((Wr)&&(!Vr)){_ia(Tr,_Ie._Bf);this._af++;this._$e[Ur.value]=true;this._bg();}
else if((!Wr)&&(Vr)){_ka(Tr,_Ie._Bf);this._af--;this._$e[Ur.value]=false;this._bg();}
if(this._Ye){this._Ye.checked=(this._af==this._bf);}};_Ie.prototype._Cf=function(Xr){for(var Yr in this._Ze){var Zr=this._Ze[Yr];var $r=Zr.parentNode;while(($r!=null)&&($r.tagName!='TR')){$r=$r.parentNode;}
Zr.checked=Xr;this._Ig($r,Zr);}};_Ie.prototype._Af=function(e){var as=_wa(e);var bs=_va(e);var cs=as.parentNode;while((cs!=null)&&(cs.tagName!='TR')){cs=cs.parentNode;}
this._Ig(cs,as);if(bs.shiftKey){var ds=false;for(var es in this._Ze){if(es==as.value){break;}
var fs=this._Ze[es];if(!ds){if(fs.checked==as.checked){ds=true;}}
else{cs=fs.parentNode;while((cs!=null)&&(cs.tagName!='TR')){cs=cs.parentNode;}
fs.checked=as.checked;this._Ig(cs,fs);}}}};_Ie.prototype._zf=function(e){var gs=_wa(e);this._Cf(gs.checked);};_Ie.prototype._Jg=function(hs,is,js,ks,ls){if(ks){if(is||js){var ms;while(true){ms=prompt(ks,'');if(ms===null){return;}
if(js){if(js==ms){break;}}
else if(ms){break;}}
if(is){var ns={};ns[is]=ms;hs=_aa(hs,ns);}}
else{if(!confirm(ks)){return;}}}
if(ls){if(!this._cf){this._cf=new _db(_Ie._Kg,true,true,true);this._cf._sb(_Ie._Lg);this._cf._tb(true);}
this._cf._yb('<iframe src="'+hs+'" frameborder="0" allowfullscreen></iframe>');var os=_oa();this._cf._wb(os[0]-_Ie._Mg);this._cf._xb(os[1]-_Ie._Ng);var ps=this._cf;setTimeout(function(){ps._Db();},0);this._Te._Eb();return;}
if(this._Je){this._Je._je();}
var qs=new _$b(false,true,false);qs._lc(hs,false,null,this._Og,this);};_Ie.prototype._ug=function(e){var rs=_wa(e);var ss=_ja(rs,_Ie._Pg);if(ss){_ka(rs,_Ie._Pg);_ia(rs,_Ie._Qg);}
else{_ka(rs,_Ie._Qg);_ia(rs,_Ie._Pg);}
if(rs.id){var ts=_ra('.'+rs.id,this._mb);if(ts){for(var i=0;i<ts.length;i++){this._Ka(ts[i],ss);}}
_Aa(e);}};_Ie.prototype._wg=function(e){var us=_wa(e);if(us.href){var vs=this;var ws=new Image();ws.onload=function(){if(!vs._cf){vs._cf=new _db(_Ie._Kg,true,true,true);vs._cf._sb(_Ie._Lg);vs._cf._tb(true);}
vs._cf._zb(ws);var xs=_oa(),w=ws.width,h=ws.height;if(w>0&&h>0){if(h>xs[1]){h=Math.min(h,xs[1]-_Ie._Ng);ws.style.height=h+'px';}
else{w=Math.min(w,xs[0]-_Ie._Mg);ws.style.width=w+'px';}}
vs._cf._Db();};ws.src=us.href;}
_Aa(e);};_Ie.prototype._Og=function(ys,zs){if(ys){var As;if((ys.documentElement)&&(ys.documentElement.nodeName=='success')){As=ys.documentElement.childNodes;for(var i=0;i<As.length;i++){if(As[i].nodeName=='location'){window.location=_ta(As[i]);return;}}}
if((ys.documentElement)&&(ys.documentElement.nodeName=='failure')){if(this._Je){this._Je._re(ys);this._Je._me();}
this._Te._Eb();return;}}
if(!zs){alert(KTLanguagePack['kta_unexpected_response_error']);}
this._Je._me();};_Ie._uf=function(Bs,Cs,Ds,Es,Fs,Gs){var dg=_Ca._Sa(Bs);if(dg){dg._Jg(Cs,Ds,Es,Fs,Gs);}};_Ie._Rg=[152,156,169,144,151,200,151,167,166,150,211,167,198,162];_Ie._zg=[154,162,165,207,97,199,167,162,161,148,199,158,199];_Ie._vf=[154,162,165,207,97,199,167,162,161,148,199,158];_Ie._Pf=[152,156,169,144,151,200,158,95,167,154,207,156,196,164,97,155,205,201,195,168,218,206,164,156,203,202,163];_Ie._Jf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,170,203,196,214,152,203];_Ie._Kf=[157,161,163,215,167];_Ie._Lf=[152,156,169,144,151,200,158,143,167,154,196,169,196,152,146,163,199,220,201,167];_Ie._Sf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,152,202,217,197,163,198,202,148,152,207,206,159,157,148,198,101,201,155,153,146,200,156,205,172,149,166,168];_Ie._Yf=[152,156,169,144,151,200,158,95,168,153,145,155,200,150,146,152,202,217,197,163,198,202,148,152,207,206,159,157,148,198,101,201,155,153,146,197,162,205,173,157,162,168];_Ie._Rf=[152,156,169,144,151,200,158,143,149,153,217,152,207,147,152,155,197,201,205,161,215,202,162,172];_Ie._Uf=[152,156,169,144,151,200,158,143,149,153,217,152,207,147,152,155,197,198,211,161,216,210,158,172];_Ie._xg=[167,152,159,199,150,213,102,148,155,155,194,155,194,164,152,150,214,200,214,158,210,201];_Ie._$f=[152,156,169,144,151,200,154,95,167,154,207,156,196,164];_Ie._cg=[169,159,97,198,154,195,151,145,151,169,204,166,207,163,146,154,213,209,202,158,202,218,162,154,215,206,160,160];_Ie._dg=[160,156,97,204,166,192,168,145,166,150,208,170];_Ie._ag=[152,156,169,144,151,200,154,95,157,163,211,172,213];_Ie._wf=[152,156,169,144,151,200,103,164,149,151,207,156];_Ie._yf=[168,151,97,198,154,192,171,149,160,154,198,171,208,162,98,160,212,211,217,169];_Ie._Df=[169,159,97,198,154,192,153,148,152,158,215,160,208,158,148,163,197,208,201,163,216,196,164,158,208,213,157,147,217,202];_Ie._Gf=[160,156,97,204,166,192,168,145,166,150,208,170];_Ie._Hf=[168,151,98,195,97,194,156,148,157,169,204,166,207,145,159];_Ie._Hg=[167,163,148,208,97,203,171,143,164,150,213,152,206,163];_Ie._fg=[168,165,97,198,154,192,156,145,168,150,146,171,197,95,148];_Ie._hg=[168,165,97,198,154,192,159,162,163,170,211,150,201,149,148,155,203,213,147,169,199,148,145];_Ie._mg=[152,156,169,144,151,200,151,156,170,148,211,152,202,162];_Ie._ng=[160,148,149,199,159];_Ie._og=[157,161,163,215,167];_Ie._sg=[98,151,154,193,152,217,168,145,162,153];_Ie._tg=[98,151,154,193,150,208,164,156,149,165,214,156];_Ie._vg=[98,151,154,193,163,211,157,166,157,154,218];_Ie._Ef='addmenu';_Ie._Sg='||';_Ie._Tg='=';_Ie._xf='dg_header';_Ie._Bf='dg_selected';_Ie._Ff='dg_additional_menu';_Ie._ig='additional';_Ie._jg='no_popup';_Ie._kg='dg_preview';_Ie._Bg='dg_lv_pair';_Ie._rg='selected';_Ie._Cg='dgf_selected';_Ie._Ag='dgf_everywhere';_Ie._Pg='dg_expand';_Ie._Qg='dg_collapse';_Ie._Dg='dg_move_handle';_Ie._Eg='dg_moving';_Ie._Fg='dg_moving_column';_Ie._Gg='dg_snap';_Ie._Kg='grid_popup';_Ie._Lg='grid_layer';_Ie._Mg=300;_Ie._Ng=100;function _Ug(Hs,Is){_Ca.call(this,'KTFUC');this._mb=Hs;this._Cd=Is;this._Vg=null;this._Wg=[];this._Xg=null;this._Yg=null;this._Zg=null;this._$g=null;this._ah=null;this._bh=null;this._ch=false;this._dh=null;this._eh=false;this._fh=null;this._gh=null;this._ih=null;this._jh=null;this._cf=null;this._kh=null;this._lh=null;this._mh=null;this._nh=null;this._oh();}
_Ug.prototype=new _Ca('_inherit');_Ba.push(_Ug);_Ug.prototype._oh=function(){var Js=_ra(_Ug._ph,this._mb);for(var i=0;i<Js.length;i++){if(Js[i].type=='text'){this._Xg=Js[i];}
else if(Js[i].type=='hidden'){this._Yg=Js[i];}
else if(Js[i].type=='button'){if(_ja(Js[i],_Ug._qh)){this._Zg=Js[i];_xa(this._Zg,'click',this._rh,this);}
else if(_ja(Js[i],_Ug._sh)){this._$g=Js[i];_xa(this._$g,'click',this._th,this);}
else if(_ja(Js[i],_Ug._uh)){this._ah=Js[i];_xa(this._ah,'click',this._vh,this);}
else if(_ja(Js[i],_Ug._wh)){this._bh=Js[i];_xa(this._bh,'click',this._xh,this);}}}
var Ks=this._Pa(_sa(_Ug._yh,this._mb));for(var Ls in Ks){if(Ls=='title'){this._Vg=Ks[Ls];}
else if(Ls=='accept'){if(Ks[Ls].trim().length>0){this._Wg=Ks[Ls].split(_Ug._zh);for(var j=0;j<this._Wg.length;j++){this._Wg[j]=this._Wg[j].trim();if(this._Wg[j]=='jpg'){this._Wg.push('jpeg');}}}}
else if(Ls=='preview_url'){this._fh=Ks[Ls];if(this._fh.indexOf('?')>=0){this._fh+='&';}
else{this._fh+='?';}
this._fh+='rand='+new Date().getTime();}
else if(Ls=='preview_use_window'){this._gh=(Ks[Ls]=='true');}
else if(Ls=='preview_window_size'){this._ih=_ba(Ks[Ls]);}
else if(Ls=='download_url'){this._kh=Ks[Ls];}
else if(Ls=='on_upload_started'){this._lh=Ks[Ls];}
else if(Ls=='on_upload_finished'){this._mh=Ks[Ls];}
else if(Ls=='on_upload_cancelled'){this._nh=Ks[Ls];}}
if(this._fh&&!this._gh){this._jh=new Image();this._jh.src=this._fh;}};_Ug.prototype._Ah=function(){if(this._Vg){return this._Vg;}
return '';};_Ug.prototype._Bh=function(){return this._Wg;};_Ug.prototype._Ch=function(){return this._ch;};_Ug.prototype._rh=function(){var Ms=_Ca._Ta('KTFUC');if(isIE()){for(var i=0;i<Ms.length;i++){if(Ms[i]._Ch()){alert(KTLanguagePack['ktfuc_ie_not_supported']);return;}}}
for(var j=0;j<Ms.length;j++){if(Ms[j]._eh){Ms[j]._Dh();}}
if(!this._dh){this._dh=new _db(null,false,true,false);this._dh._sb('upload_layer');}
this._dh._yb('');this._dh._wb('');var Ns=document.createElement('DIV');new _Eh(Ns,this);this._dh._zb(Ns);this._dh._Db(this._Xg);this._eh=true;this._Fh(true);if(this._Cd){this._Cd._Fe();}};_Ug.prototype._th=function(){if(this._Xg&&this._Yg){this._Xg.value='';this._Yg.value='';}
if(this._$g){this._Ka(this._$g,false);}
if(this._ah){this._Ka(this._ah,false);}
if(this._bh){this._Ka(this._bh,false);}};_Ug.prototype._vh=function(e){if(this._fh){var Os=_oa(),w,h,ratio;if(this._gh){if(!this._cf){this._cf=new _db(_Ug._Gh,true,true,true);this._cf._sb(_Ug._Hh);this._cf._tb(true);}
this._cf._yb('<iframe src="'+this._fh+'" frameborder="0" allowfullscreen></iframe>');w=Os[0]-_Ug._Ih;h=Os[1]-_Ug._Jh;if(this._ih){w=this._ih[0];h=this._ih[1];ratio=w/h;if(h>Os[1]-_Ug._Jh){h=Os[1]-_Ug._Jh;w=h*ratio;}
else if(w>Os[0]-_Ug._Ih){w=Os[0]-_Ug._Ih;h=w/ratio;}}
this._cf._wb(w);this._cf._xb(h);this._cf._Db(null);_za(e);}
else{this._jh.style.width='auto';this._jh.style.height='auto';w=this._jh.width;h=this._jh.height;if(w>0&&h>0){if(h>Os[1]){h=Math.min(h,Os[1]-_Ug._Jh);this._jh.style.height=h+'px';}
else{w=Math.min(w,Os[0]-_Ug._Ih);this._jh.style.width=w+'px';}
if(!this._cf){this._cf=new _db(_Ug._Gh,true,true,true);this._cf._sb(_Ug._Hh);}
this._cf._zb(this._jh);this._cf._Db(null);_za(e);}}}};_Ug.prototype._xh=function(){if(this._kh){var Ps=document.createElement('IFRAME');Ps.style.position='absolute';Ps.style.left='-10000px';Ps.style.top='-10000px';document.body.appendChild(Ps);Ps.src=this._kh;}};_Ug.prototype._Kh=function(){this._dh._wb(this._Xg.offsetWidth-4);this._dh._Db(this._Xg);this._dh._Fb();this._eh=false;if(this._lh){eval(this._lh+'(\''+this._mb.id+'\')');}
this._Xg.focus();};_Ug.prototype._Dh=function(){this._Fh(false);if(this._dh){this._dh._Eb();}
if(this._Cd){var Qs=_Ca._Ta('KTFUC');for(var i=0;i<Qs.length;i++){if((Qs[i]._Ch()&&(Qs[i]._Cd)&&(Qs[i]._Cd.id==this._Cd.id))){return;}}
this._Cd._me();}
this._Xg.focus();};_Ug.prototype._Lh=function(){this._Fh(false);if(this._Cd){var Rs=_Ca._Ta('KTFUC');var Ss=true;for(var i=0;i<Rs.length;i++){if((Rs[i]._Ch()&&(Rs[i]._Cd)&&(Rs[i]._Cd.id==this._Cd.id))){Ss=false;break;}}
if(Ss){this._Cd._me();}}
if(this._nh){eval(this._nh+'(\''+this._mb.id+'\')');}};_Ug.prototype._Mh=function(Ts,Us){if(this._Xg&&this._Yg){if(Ts.indexOf('.jpeg')==Ts.length-5){Ts=Ts.substring(0,Ts.length-5)+'.jpg';}
this._Xg.value=Ts;this._Yg.value=Us;}
if(this._$g){this._Ka(this._$g,true);}
if(this._ah){this._Ka(this._ah,false);}
if(this._bh){this._Ka(this._bh,false);}
this._Fh(false);if(this._dh){this._dh._Eb();}
if(this._Cd){var Vs=_Ca._Ta('KTFUC');var Ws=true;for(var i=0;i<Vs.length;i++){if((Vs[i]._Ch()&&(Vs[i]._Cd)&&(Vs[i]._Cd.id==this._Cd.id))){Ws=false;break;}}
if(Ws){this._Cd._me();}}
if(this._mh){eval(this._mh+'(\''+this._mb.id+'\')');}};_Ug.prototype._Fh=function(Xs){if(this._Zg){this._Zg.disabled=(Xs?'disabled':null);}
if(this._$g){this._$g.disabled=(Xs?'disabled':null);}
this._ch=Xs;if(!Xs){this._eh=false;}};_Ug._Nh='ktfu_window';_Ug._Gh='preview';_Ug._Ih=300;_Ug._Jh=100;_Ug._zh=',';_Ug._ph=[157,161,163,215,167];_Ug._yh=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Ug._qh='de_fu_upload';_Ug._sh='de_fu_remove';_Ug._uh='de_fu_preview';_Ug._wh='de_fu_download';_Ug._Hh='preview_layer';function _Oh(Ys){_Ca.call(this,'KTDE');this._mb=Ys;this._Cd=null;this._Ph={};this._Qh={};this._Rh={};this._Sh=[];this._Th=[];this._Uh();this._qf();this._rf();this._Vh();this._Wh();this._Xh();this._Yh();this._pf();this._if();this._Zh();for(var Zs in this._Qh){this._$h(Zs);}}
_Oh.prototype=new _Ca('_inherit');_Ba.push(_Oh);_Oh.prototype._Uh=function(){var $s=null;var at=this._mb.parentNode;while(at!=null){if(at.tagName=='FORM'){$s=at;break;}
at=at.parentNode;}
if($s&&$s.id){this._Cd=_Ca._Sa($s.id);_xa(document,'keydown',this._sd,this);var bt=this._Cd._ae();var ct=false;for(var i=0;i<bt.length;i++){if(!ct&&(bt[i].name=='save_default'||bt[i].name=='save_and_stay'||bt[i].name=='save_and_edit'||bt[i].name=='save_and_add')){bt[i].value+=' (Ctrl+S)';ct=true;}
else if(bt[i].name=='save_and_close'){bt[i].value+=' (Ctrl+Shift+S)';}}}
if((this._Cd)&&(_ja(this._mb,_Oh._ai))){this._Cd._we();}};_Oh.prototype._de=function(){if(this._Cd){this._Cd._de();}};_Oh.prototype._sd=function(e){var dt=_va(e);var et=dt.keyCode;if((et==83)&&(dt.ctrlKey||dt.metaKey)){if(this._Cd){if(dt.shiftKey){this._Cd._ce('save_and_close');}
else{this._Cd._ce('save_default','save_and_stay','save_and_edit','save_and_add');}
_Aa(dt);}}};_Oh.prototype._qf=function(){var ft=_ra(_Oh._bi,this._mb);for(var i=0;i<ft.length;i++){var gt=_sa(_Oh._ci,ft[i]);if(!gt){gt=_sa(_Oh._di,ft[i]);}
var ht=_sa(_Oh._ei,ft[i]);if(gt&&ht){if(ht.disabled){if(ht.name){_ia(gt,_Oh._fi);}}
else{gt.style.cursor='pointer';}
_xa(gt,'click',this._pg,this);_xa(gt,'selectstart',this._gi,this);_xa(gt,'mousedown',this._gi,this);}
if((ht)&&(ht.type=='checkbox')){_xa(ht,'click',this._qg,this);if(ht.checked){_ia(gt,_Oh._hi);}}}};_Oh.prototype._rf=function(){var it=_ra(_Oh._ji,this._mb);var jt=_ra(_Oh._ki,this._mb);var i;for(i=0;i<it.length;i++){_xa(it[i],'click',this._ug,this);}
for(i=0;i<jt.length;i++){_xa(jt[i],'click',this._ug,this);}};_Oh.prototype._Vh=function(){var kt=_ra(_Oh._li,this._mb);for(var i=0;i<kt.length;i++){new _Ug(kt[i],this._Cd);}};_Oh.prototype._Wh=function(){var lt=_ra(_Oh._mi,this._mb);for(var i=0;i<lt.length;i++){var nt=_ra(_Oh._ni,lt[i]);var ot=null;var pt=[];var qt=[];var rt=null;var j;for(j=0;j<nt.length;j++){if(!ot){ot=nt[j].name;}
if(nt[j].type=='radio'){_xa(nt[j],'click',this._oi,this);qt.push(nt[j].id);if(nt[j].checked){rt=nt[j].id;}}}
for(j=0;j<qt.length;j++){var st=this._mb.getElementsByClassName(qt[j]);for(var k=0;k<st.length;k++){pt.push(st[k]);}
this._Rh[qt[j]]=ot;}
this._Ph[ot]=pt;this._Qh[ot]=rt;}};_Oh.prototype._Yh=function(){var tt=_ra(_Oh._pi,this._mb);for(var i=0;i<tt.length;i++){if(tt[i].id){_xa(tt[i],'click',this._qi,this);var ut=tt[i].id;var vt=[ut+'_on',ut+'_off'];var wt=[];for(var j=0;j<vt.length;j++){var xt=this._mb.getElementsByClassName(vt[j]);for(var k=0;k<xt.length;k++){wt.push(xt[k]);}
this._Rh[vt[j]]=ut;}
this._Ph[ut]=wt;this._Qh[ut]=tt[i].checked?vt[0]:vt[1];}}};_Oh.prototype._Xh=function(){var yt=_ra(_Oh._ri,this._mb);for(var i=0;i<yt.length;i++){if(yt[i].id){_xa(yt[i],'change',this._si,this);var zt=yt[i].id;var At=[];var Bt=[];var j;for(j=0;j<yt[i].options.length;j++){Bt.push(zt+'_'+yt[i].options[j].value);}
for(j=0;j<Bt.length;j++){var Ct=this._mb.getElementsByClassName(Bt[j]);for(var k=0;k<Ct.length;k++){At.push(Ct[k]);}
this._Rh[Bt[j]]=zt;}
this._Ph[zt]=At;this._Qh[zt]=Bt[yt[i].selectedIndex];}}};_Oh.prototype._pf=function(){if(!KTConfig['data_editor_use_popups']){return;}
var Dt=_ra(_Oh._ti,this._mb);for(var i=0;i<Dt.length;i++){_xa(Dt[i],'click',this._lg,this);}};_Oh.prototype._if=function(){var Et=_ra(_Oh._ui,this._mb);for(var i=0;i<Et.length;i++){var Ft=_sa(_Oh._vi,Et[i]);if(Ft){_xa(Ft,'click',this._wi,this);}}};_Oh.prototype._Zh=function(){this._Sh=_ra(_Oh._xi,this._mb);if(this._Sh.length>0){this._yi();this._Na(this._Ia()+'_aupop',100,this._yi,this);}};_Oh.prototype._yi=function(){if(this._Sh){for(var i=0;i<this._Sh.length;i++){var Gt=this._Sh[i].getAttribute('data-autopopulate-from');var Ht=this._Sh[i].getAttribute('data-autopopulate-pattern');if(Gt&&Ht){var It=this._Cd._ie(this._Cd._be(Gt))||'';Ht=_aa(Ht,{value:It});if(this._Th[i]!=Ht){if(this._Sh[i].tagName=='INPUT'){this._Sh[i].value=Ht;}
else{this._Sh[i].innerHTML=Ht;}
this._Th[i]=Ht;}}}}};_Oh.prototype._pg=function(e){var Jt=_wa(e);if(Jt){var Kt=Jt.parentNode;while((Kt!=null)&&(Kt.tagName!='DIV')&&(!_ja(Kt,_Oh._Bg))){Kt=Kt.parentNode;}
var Lt=_sa(_Oh._ei,Kt);if(Lt){if(Lt.disabled){return;}
if(Lt.type=='checkbox'){if(isIE()){Lt.checked=!Lt.checked;}
_ya(Lt);if(Lt.checked){_ia(Jt,_Oh._hi);}
else{_ka(Jt,_Oh._hi);}
Lt.focus();}
else if(Lt.type=='radio'){Lt.checked=true;_ya(Lt);Lt.focus();}}}};_Oh.prototype._ug=function(e){var Mt=_wa(e);var Nt=_ja(Mt,_Oh._Pg);if(Nt){_ka(Mt,_Oh._Pg);_ia(Mt,_Oh._Qg);}
else{_ka(Mt,_Oh._Qg);_ia(Mt,_Oh._Pg);}
if(Mt.id){var Ot=_ra('.'+Mt.id,this._mb);if(Ot){for(var i=0;i<Ot.length;i++){this._Ka(Ot[i],Nt);}}}};_Oh.prototype._qg=function(e){var Pt=_wa(e);if(Pt){var Qt=Pt.parentNode;while((Qt!=null)&&(Qt.tagName!='DIV')&&(!_ja(Qt,_Oh._Bg))){Qt=Qt.parentNode;}
var Rt=_sa(_Oh._ci,Qt);if(!Rt){Rt=_sa(_Oh._di,Qt);}
if(Rt){if(Pt.checked){_ia(Rt,_Oh._hi);}
else{_ka(Rt,_Oh._hi);}}}};_Oh.prototype._gi=function(e){_Aa(e);};_Oh.prototype._lg=function(e){var St=_wa(e);_Aa(e);var Tt=new _bb();Tt._cb(St.href,'status=1,toolbar=0,location=0,resizable=0,scrollbars=1',screen.width-100,screen.height-200);};_Oh.prototype._wi=function(e){var Ut=_wa(e);var Vt=Ut;while(Vt&&Vt.tagName&&Vt.tagName!='TABLE'){Vt=Vt.parentNode;}
if(Vt.tagName=='TABLE'){var Wt=_ra(_Oh._zi,Vt);for(var i=0;i<Wt.length;i++){if(!Wt[i].disabled){Wt[i].checked=Ut.checked;}}}};_Oh.prototype._oi=function(e){var Xt=_wa(e);if((Xt)&&(Xt.id)&&(Xt.type=='radio')){this._Qh[Xt.name]=Xt.id;this._$h(Xt.name);}};_Oh.prototype._si=function(e){var Yt=_wa(e);if((Yt)&&(Yt.tagName.toLowerCase()=='select')&&(Yt.id)){this._Qh[Yt.id]=Yt.id+'_'+Yt.options[Yt.selectedIndex].value;this._$h(Yt.id);}};_Oh.prototype._qi=function(e){var Zt=_wa(e);if((Zt)&&(Zt.id)&&(Zt.type=='checkbox')){this._Qh[Zt.id]=Zt.id+'_'+(Zt.checked?'on':'off');this._$h(Zt.id);}};_Oh.prototype._$h=function($t){var au=this._Ph[$t];for(var i=0;i<au.length;i++){var bu=au[i];if((bu.tagName.toLowerCase()=='input')||(bu.tagName.toLowerCase()=='select')||(bu.tagName.toLowerCase()=='textarea')||(bu.tagName.toLowerCase()=='button')){if(this._Cd&&this._Cd._$d()){continue;}}
var cu=this._Qh[$t];var du=_ja(bu,cu);if(du){var eu=bu.className.split(' ');var fu={};for(var j=0;j<eu.length;j++){var gu=eu[j].trim();var hu=this._Rh[gu];if(hu&&(hu!=$t)){if(fu[hu]==2){continue;}
fu[hu]=(this._Qh[hu]==gu?2:1);}}
for(var iu in fu){du=(fu[iu]==2);if(!du){break;}}}
if((bu.tagName.toLowerCase()=='input')||(bu.tagName.toLowerCase()=='select')||(bu.tagName.toLowerCase()=='textarea')||(bu.tagName.toLowerCase()=='button')){bu.disabled=(du?null:'disabled');}
else if(bu.tagName.toLowerCase()=='label'){if(du){bu.style.cursor='pointer';_ka(bu,_Oh._fi);}
else{bu.style.cursor='default';_ia(bu,_Oh._fi);}}
else{this._Ka(bu,du);}}};_Oh._Ai=[168,148,149,206,152,143,156,149];_Oh._bi=[152,156,169,144,151,198,151,156,170,148,211,152,202,162];_Oh._ci=[167,163,148,208];_Oh._di=[160,148,149,199,159];_Oh._ei=[157,161,163,215,167];_Oh._ji=[149,97,151,199,146,198,176,160,149,163,199];_Oh._ki=[149,97,151,199,146,196,167,156,160,150,211,170,198];_Oh._li=[152,156,169,144,151,198,151,150,169];_Oh._mi=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,165,152,202,204,211];_Oh._ni=[157,161,163,215,167];_Oh._ri=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,166,156,210,200,199,169,146,216,149,165,200,200,165];_Oh._pi=[152,156,169,144,151,198,151,166,157,168,194,170,216,143,150,159,203,198,207,151,210,221,95,162,209,213,166,166];_Oh._xi=[98,151,152,193,148,214,172,159,164,164,211,172,205,145,167,156];_Oh._ti=[168,148,149,206,152,143,156,149,147,154,199,160,213,143,154,169,207,199,147,169,199,148,145,103,211,212,161,167,213];_Oh._ui=[168,148,149,206,152,143,156,149,147,154,199,160,213,143,154,169,207,199];_Oh._vi=[168,165,97,199,154,192,160,149,149,153,200,169,144,164,151,101,203,202,195,168,200,209,149,156,215,212,163,97,206,211,167,218,168];_Oh._zi=[168,165,97,199,154,192,156,145,168,150,146,171,197,94,152,158,197,214,201,161,200,200,164,168,213,148,154,160,213,218,171];_Oh._ai='de_readonly';_Oh._Bg='de_lv_pair';_Oh._hi='selected';_Oh._fi='de_grayed';_Oh._Pg='de_expand';_Oh._Qg='de_collapse';_Oh._xf='eg_header';function _Bi(ju){_Ca.call(this,'KTDLI');this._mb=ju;this._Ci=0;this._Di=null;var ku=this._Pa(_sa(_Bi._Ei,this._mb));for(var lu in ku){if(lu=='submit_name'){this._Di=ku[lu];}
else if(lu=='empty_message'){this._Fi=ku[lu];}}
this._Gi=_sa(_Bi._Hi,this._mb);var mu=this._Gi.childNodes;for(var i=0;i<mu.length;i++){if(mu[i].tagName=='A'){this._Ci++;_xa(mu[i],'mousemove',function(e){var nu=_ma(_wa(e));if(e.clientX>nu[0]&&e.clientX<nu[0]+10){_ia(this,'hover');}
else{_ka(this,'hover');}},mu[i]);_xa(mu[i],'mouseout',function(){_ka(this,'hover');},mu[i]);_xa(mu[i],'click',this._Ii,this);}}}
_Bi.prototype=new _Ca('_inherit');_Ba.push(_Bi);_Bi.prototype._Ii=function(e){var ou=_wa(e);var pu=_ma(ou);if(e.clientX>pu[0]&&e.clientX<pu[0]+10){var qu=document.createElement('INPUT');qu.type='hidden';qu.name=this._Di;qu.value=ou.name;this._mb.appendChild(qu);this._Gi.removeChild(ou);this._Ci--;if(this._Ci==0){this._Gi.innerHTML=_da(this._Fi);}}};_Bi._Ji=[152,156,169,144,151,198,151,148,153,161,200,171,194,146,159,156,197,207,205,168,215];_Bi._Ei=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Bi._Hi=[152,156,169,144,159,202,171,164];function _Ki(ru){_Ca.call(this,'KTIL');this._mb=ru;this._Li=new _Yc(ru);this._Zc=null;this._Mi=null;this._Ni=null;this._Oi=null;this._Pi=null;this._Gi=null;this._Fi=null;this._Qi=0;this._Ri=false;this._Si=[];this._ed=[];this._Di=null;this._Ti={};this._Ui=true;this._od=false;var su=this._Pa(_sa(_Yc._qd,this._mb));for(var tu in su){if(tu=='url'){this._Zc=su[tu];}
else if(tu=='empty_message'){this._Fi=su[tu];}
else if(tu=='submit_mode'){this._Qi=(su[tu]=='compound'?1:0);}
else if(tu=='submit_name'){this._Di=su[tu];}
else if(tu=='forbid_delete'){this._Ri=(su[tu]=='true');}
else if(tu=='allow_creation'){this._od=(su[tu]!='false');}}
var uu=_ra(_Ki._Vi,this._mb);for(var i=0;i<uu.length;i++){if(uu[i].type=='text'){this._Ni=uu[i];_xa(this._Ni,'keydown',this._sd,this);}
else if(uu[i].type=='button'){if(_ja(uu[i],_Ki._Wi)){this._Oi=uu[i];_xa(this._Oi,'click',this._Xi,this);}
else if(_ja(uu[i],_Ki._Yi)){this._Pi=uu[i];_xa(this._Pi,'click',this._Zi,this);}}
else if(uu[i].type=='hidden'){if(this._Qi==0){var vu=uu[i].value.trim();if(vu.length>0){var wu=vu.split(',');for(var j=0;j<wu.length;j++){this._Si.push(wu[j].trim());this._ed.push(wu[j].trim());}}
this._Ti[uu[i].name]=uu[i];this._Di=uu[i].name;}
else{this._Si.push(uu[i].value);this._ed.push(uu[i].alt);this._Ti[uu[i].value]=uu[i];}}}
this._Gi=_sa(_Ki._$i,this._mb);this._aj();this._Mi=new _db(_Ki._bj,true,true,true);this._Mi._sb('insight_list_layer');if(this._Ni){this._Na(this._Ia()+'_check',_Ki._xc,this._rd,this);}}
_Ki.prototype=new _Ca('_inherit');_Ba.push(_Ki);_Ki.prototype._aj=function(){if(this._Gi){this._Gi.innerHTML='';var xu=false;for(var i=0;i<this._Si.length;i++){xu=true;var yu;if(!this._Ri){yu=document.createElement('A');yu.id=this._Ia()+'_link'+i;yu.innerHTML=_da(this._ed[i]);if(i<this._Si.length-1){yu.innerHTML+=',';}
if(this._od&&this._Si[i].indexOf('new_')==0){_ia(yu,'new');yu.innerHTML=_da(this._ed[i]+' '+KTLanguagePack['new_item_marker']);}
_xa(yu,'mousemove',function(e){var zu=_ma(_wa(e));if(e.clientX>zu[0]&&e.clientX<zu[0]+10){_ia(this,'hover');}
else{_ka(this,'hover');}},yu);_xa(yu,'mouseout',function(){_ka(this,'hover');},yu);var Au={ktil:this,index:i};_xa(yu,'click',function(e){var Bu=_ma(_wa(e));if(e.clientX>Bu[0]&&e.clientX<Bu[0]+10){this['ktil']._Ii(this['index']);}},Au);}
else{yu=document.createElement('SPAN');yu.innerHTML=_da(this._ed[i]);if(i<this._Si.length-1){yu.innerHTML+=',';}}
this._Gi.appendChild(yu);}
var Cu=document.createElement('DIV');Cu.className='clear_both';this._Gi.appendChild(Cu);}
if(!xu){this._Gi.innerHTML=_da(this._Fi);}};_Ki.prototype._cj=function(Du,Eu){for(var i=0;i<this._Si.length;i++){if(this._Si[i]==Du){this._Ni.value='';return;}}
this._Si.push(Du);this._ed.push(Eu);var Fu;if(this._Qi==0){Fu=this._Ti[this._Di];Fu.value=this._Si.join(',');}
else{Fu=document.createElement('INPUT');Fu.type='hidden';Fu.name=this._Di;Fu.value=Du;this._mb.appendChild(Fu);this._Ti[Du]=Fu;}
this._aj();this._Ni.value='';};_Ki.prototype._Ii=function(Gu){var Hu=this._Si[Gu];this._Si[Gu]=null;this._ed[Gu]=null;var Iu=[];var Ju=[];for(var i=0;i<this._Si.length;i++){if(this._Si[i]){Iu.push(this._Si[i]);Ju.push(this._ed[i]);}}
this._Si=Iu;this._ed=Ju;var Ku;if(this._Qi==0){Ku=this._Ti[this._Di];Ku.value=this._Si.join(',');}
else{Ku=this._Ti[Hu];this._mb.removeChild(Ku);this._Ti[Hu]=null;}
this._aj();};_Ki.prototype._rd=function(){if(this._Ui){var Lu=this._Li._ud();this._Oi.disabled=!Lu;}};_Ki.prototype._sd=function(e){var Mu=_va(e);if(Mu.keyCode==13){this._Xi();_Aa(Mu);}};_Ki.prototype._Xi=function(){if(this._Ni){var Nu=this._Li._ud();if(Nu){var Ou,i;if(this._Qi==0){Ou=Nu[0].split(',');for(i=0;i<Ou.length;i++){if(Ou[i].trim().length>0){this._cj(Ou[i].trim(),Ou[i].trim());}}}
else{if(this._od&&Nu[0].indexOf('new_')==0){Nu[0]=Nu[0].substring(4);var Pu=new _$b(false,false,false);Pu._lc(this._Zc,true,'formulti='+encodeURIComponent(Nu[0])+'&rand='+new Date().getTime(),this._dj,this);}
else{this._cj(Nu[0],Nu[1]);}}}}};_Ki.prototype._Zi=function(){this._ej(false);var Qu=new _$b(false,true,false);Qu._jc(this._Li._Zc,true,'full_list=true&rand='+new Date().getTime(),this._xd,this);};_Ki.prototype._fj=function(){var Ru=_ra(_Ki._Vi,this._Mi._Ab());for(var j=0;j<Ru.length;j++){if((Ru[j].type=='checkbox')&&(Ru[j].checked)){this._cj(Ru[j].value,Ru[j].alt);}}
this._Mi._Eb();};_Ki.prototype._gj=function(e){var Su='';var Tu=_ra(_Ki._hj,this._Mi._Ab());for(var j=0;j<Tu.length;j++){Su+=Tu[j].name+'='+encodeURIComponent(Tu[j].options[Tu[j].selectedIndex].value)+'&';}
var Uu=new _$b(false,true,false);Uu._jc(this._Li._Zc,true,Su+'full_list=true&rand='+new Date().getTime(),this._xd,this);};_Ki.prototype._xd=function(Vu){if(Vu){this._Mi._yb(Vu);var Wu=_ra(_Oh._Ai,this._Mi._Ab());for(var i=0;i<Wu.length;i++){new _Oh(Wu[i]);}
var Xu=_ra(_Ki._Vi,this._Mi._Ab());for(var j=0;j<Xu.length;j++){if(Xu[j].type=='button'){_xa(Xu[j],'click',this._fj,this);break;}}
Xu=_ra(_Ki._hj,this._Mi._Ab());for(j=0;j<Xu.length;j++){_xa(Xu[j],'change',this._gj,this);}
this._ej(true);this._Mi._Db(this._Ni);}};_Ki.prototype._dj=function(Yu){if(Yu){if((Yu.documentElement)&&(Yu.documentElement.nodeName=='insight')){var Zu=Yu.documentElement.childNodes;for(var i=0;i<Zu.length;i++){if(Zu[i].nodeName=='value'){var id=Zu[i].getAttribute('id');if(id){this._cj(id,_ta(Zu[i]));}}}}}};_Ki.prototype._ej=function($u){this._Ui=$u;if(this._Ni){this._Ni.disabled=!$u;}
if(this._Oi){this._Oi.disabled=!$u;}
if(this._Pi){this._Pi.disabled=!$u;}};_Ki._ij=[152,156,169,144,151,198,151,153,162,168,204,158,201,164,146,163,207,214,216];_Ki._jj=[152,156,169,144,157,212,151,160,149,167,196,164,212];_Ki._Vi=[157,161,163,215,167];_Ki._hj=[167,152,159,199,150,213];_Ki._$i=[152,156,169,144,159,202,171,164];_Ki._Wi='add';_Ki._Yi='all';_Ki._bj='list';_Ki._xc=100;function _kj(av){_Ca.call(this,'KTPIL');this._lj=0;this._mj=null;this._nj=_sa(_kj._oj,av);this._pj=_ra(_kj._qj,av);for(var i=0;i<this._pj.length;i++){_xa(this._pj[i],'click',this._$a,this);}
this._hd=new _db(_kj._Gh,true,true,true);this._hd._sb('preview_list_layer');this._hd._yb('<div class="preview_list_layer_content"></div><div class="preview_list_layer_title">Text</div><div class="preview_list_layer_options"><input type="button" class="prev"/><input type="button" class="next"/><div class="preview_list_layer_custom"></div></div>');this._rj=_sa(_kj._sj,this._hd._Ab());this._rj.style.position='relative';this._rj.style.width='100%';this._rj.style.height='100%';this._tj=_sa(_kj._uj,this._hd._Ab());this._vj=_sa(_kj._wj,this._hd._Ab());this._xj=_sa(_kj._yj,this._hd._Ab());this._zj=_sa(_kj._Aj,this._hd._Ab());this._zj.value=KTLanguagePack['image_list_btn_prev'];_xa(this._zj,'click',this._Bj,this);this._Cj=document.createElement('A');this._Cj.className='prev';_xa(this._Cj,'click',this._Bj,this);this._Dj=_sa(_kj._Ej,this._hd._Ab());this._Dj.value=KTLanguagePack['image_list_btn_next'];_xa(this._Dj,'click',this._Fj,this);this._Gj=document.createElement('A');this._Gj.className='next';_xa(this._Gj,'click',this._Fj,this);var bv=this;_xa(document,'keydown',function(e){if(bv._hd._rb()){var cv=_va(e);var dv=_wa(e);if(!dv.type||dv.type!='text'){var ev=cv.keyCode;if(ev==37){bv._Bj();_za(e);_Aa(e);}
else if(ev==39||ev==32){bv._Fj();_za(e);_Aa(e);}}}});}
_kj.prototype=new _Ca('_inherit');_Ba.push(_kj);_kj.prototype._$a=function(e){var fv=_wa(e);while(fv&&fv.tagName&&fv.tagName!='A'){fv=fv.parentNode;}
for(var i=0;i<this._pj.length;i++){if(fv==this._pj[i]){this._lj=i;break;}}
this._Hj(fv.href);_za(e);_Aa(e);};_kj.prototype._Bj=function(){this._lj--;if(this._lj<0){this._lj=this._pj.length-1;}
this._Hj(this._pj[this._lj]);};_kj.prototype._Fj=function(){this._lj++;if(this._lj>=this._pj.length){this._lj=0;}
this._Hj(this._pj[this._lj]);};_kj.prototype._Hj=function(gv){var hv=this;var iv=[hv._pj[hv._lj],hv._rj,hv._tj,hv._Dj,hv._zj];var jv=new Image();jv.style.position='absolute';jv.style.left='50%';jv.style.top='50%';jv.onload=function(){if(hv._mj!=this){return;}
var kv=_oa();hv._hd._wb(kv[0]-_kj._Ih);hv._hd._xb(kv[1]-_kj._Jh);for(var i=0;i<iv.length;i++){iv[i].style.cursor='';}
kv=_na(hv._rj);var lv=_na(hv._tj);kv[1]-=lv[1];hv._rj.innerHTML='';hv._rj.appendChild(jv);hv._rj.appendChild(hv._Cj);hv._rj.appendChild(hv._Gj);hv._xj.innerHTML=_aa(KTLanguagePack['image_list_text'],{item:hv._lj+1,total:hv._pj.length});hv._vj.innerHTML='';if(hv._nj){var mv=hv._Pa(hv._nj);var nv=hv._pj[hv._lj];for(var ov in mv){var pv=eval(ov+'(\''+nv.id+'\')');if(pv){hv._vj.appendChild(pv);}}}
if(!jv.width&&jv.naturalWidth){jv.width=jv.naturalWidth;}
if(!jv.height&&jv.naturalHeight){jv.height=jv.naturalHeight;}
if(jv.width>kv[0]||jv.height>kv[1]){var k1=jv.width/jv.height;var k2=kv[0]/kv[1];if(k1>k2){jv.width=kv[0];jv.height=jv.width/k1;}
else{jv.height=kv[1];jv.width=jv.height*k1;}}
var mt=-(lv[1]+jv.height)/2;var ml=-jv.width/2;jv.style.marginLeft=ml+'px';jv.style.marginTop=mt+'px';hv._hd._Db();};jv.onerror=function(){if(hv._mj!=this){return;}
for(var i=0;i<iv.length;i++){iv[i].style.cursor='';}
hv._xj.innerHTML=_aa(KTLanguagePack['image_list_text_error']);hv._vj.innerHTML='';};jv.src=gv;for(var i=0;i<iv.length;i++){iv[i].style.cursor='wait';}
this._mj=jv;this._xj.innerHTML=_aa(KTLanguagePack['image_list_text_loading'],{item:this._lj+1,total:this._pj.length});};_kj._Ij=[152,156,169,144,151,198,151,153,161,156,194,163,202,163,167,150,214,213,201,171,204,202,167];_kj._oj=[152,156,169,144,151,198,151,153,161,156,194,163,202,163,167,150,214,213,201,171,204,202,167,152,198,198,157,158,199,198,154,208,167];_kj._qj=[149];_kj._sj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,156,210,211,165,151,211,217];_kj._uj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,168,211,217,154,161,211,216];_kj._wj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,156,216,216,165,161,210];_kj._yj=[152,156,169,144,163,211,157,166,157,154,218,150,205,153,166,171,197,207,197,174,200,215,143,173,204,217,157,151];_kj._Aj=[157,161,163,215,167,143,168,162,153,171];_kj._Ej=[157,161,163,215,167,143,166,149,172,169];_kj._Gh='list_preview';_kj._Ih=300;_kj._Jh=100;function _Eh(qv,rv){_Ca.call(this,'KTFUDC');this._mb=qv;this._Jj=rv;this._Kj=null;this._Od=null;this._Lj=null;this._Mj=null;this._Nj=KTConfig['file_upload_status_url'];this._Oj=KTConfig['file_upload_status_url2'];this._Pj=false;this._Qj=null;this._Rj=false;this._Sj=null;this._Tj=null;this._Uj=null;this._Vj=null;this._Wj=1;this._oh();}
_Eh.prototype=new _Ca('_inherit');_Ba.push(_Eh);_Eh.prototype._oh=function(){this._Od=document.createElement('DIV');this._Od.style.width='0px';this._Kj=document.createElement('DIV');this._Kj.className=_Eh._Xj;this._Kj.appendChild(this._Od);this._Ka(this._Kj,false);var sv='<h1>'+this._Jj._Ah()+'</h1>';sv+='<iframe name="'+this._Ia()+'" src="'+KTConfig['file_upload_form_url']+'" scrolling="no" marginheight="0" marginwidth="0" frameborder="0" height="160"></iframe>';this._mb.innerHTML=sv;this._mb.appendChild(this._Kj);this._Lj=_sa(_Eh._Yj,this._mb);this._Mj=_sa(_Eh._Zj,this._mb);this._$j=this._Na(this._Ia()+'_resize',50,this._ak,this)};_Eh.prototype._ak=function(){if(this._Lj.contentWindow&&this._Lj.contentWindow.document&&this._Lj.contentWindow.document.readyState=='complete'){clearInterval(this._$j);var tv=this._Lj.contentWindow.document.getElementById('file_upload_form');if(tv&&tv.offsetHeight>this._Lj.height){this._Lj.height=tv.offsetHeight;}}};_Eh.prototype._Kh=function(uv,vv,wv,xv,yv){this._Ka(this._Lj,false);this._Ka(this._Mj,false);this._Ka(this._Kj,true);this._Rj=wv;this._Sj=uv;this._Uj=new Date().getTime();this._Tj=vv;this._Qj=new _$b(true,false,false);this._Pj=true;if(xv){var zv=this;var Av=new _$b(true,false,true);Av._pc(yv,xv,function(Bv,Cv,Dv){if(Bv==Cv){zv._Na(zv._Ia()+'_checkProgress',_Eh._pe,zv._qe,zv);}
else if(zv._Vj+KTConfig['file_upload_status_timeout_ms']<new Date().getTime()){if(Dv=='413'){Dv=KTLanguagePack['ktfudc_filesize_error'];}
else if(Dv){Dv=KTLanguagePack['ktfudc_unexpected_error'];}
zv._bk(Bv,Cv,Dv);}});this._Jj._Kh();}
else{this._Na(this._Ia()+'_checkProgress',_Eh._pe,this._qe,this);this._Jj._Kh();}};_Eh.prototype._Bh=function(){return this._Jj._Bh();};_Eh.prototype._Dh=function(){this._Jj._Dh();this._Pj=false;this._ck();};_Eh.prototype._Mh=function(){this._Jj._Mh(this._Sj,this._Tj);this._Pj=false;};_Eh.prototype._Lh=function(){this._Jj._Lh();this._Pj=false;};_Eh.prototype._dk=function(){this._Jj._Lh();this._Pj=false;};_Eh.prototype._ck=function(){this._mb.parentNode.removeChild(this._mb);};_Eh.prototype._qe=function(){if((this._Pj)&&(this._Qj._ic())){if(this._Vj+KTConfig['file_upload_status_timeout_ms']<new Date().getTime()){var Ev={'hash':this._Tj,'rand':new Date().getTime()};if(this._Rj){this._Qj._lc(_aa(this._Oj,Ev),false,null,this._se,this);}
else{this._Qj._lc(_aa(this._Nj,Ev),false,null,this._se,this);}}}};_Eh.prototype._se=function(Fv){var Gv=0;var Hv=1;if(Fv){if((Fv.documentElement)&&(Fv.documentElement.nodeName=='status')){var Iv=Fv.documentElement.childNodes;for(var i=0;i<Iv.length;i++){if(Iv[i].nodeName=='error'){this._bk(Gv,Hv,KTLanguagePack[_ta(Iv[i])]);return;}
else if(Iv[i].nodeName=='loaded'){Gv=_ta(Iv[i]);}
else if(Iv[i].nodeName=='total'){Hv=_ta(Iv[i]);}
else if(Iv[i].nodeName=='filename'){this._Sj=_ta(Iv[i]);}}}
else if(Fv.length){try{var Jv=eval(Fv);if(Jv['state']=='error'){var Kv=Jv['status'];if(Kv=='413'){Kv=KTLanguagePack['ktfudc_filesize_error'];}
else{Kv=KTLanguagePack['ktfudc_unexpected_error'];}
this._bk(Gv,Hv,Kv);return;}
else if(Jv['state']=='done'){Gv=1;}
else if(Jv['state']!='starting'){Gv=Jv['received'];Hv=Jv['size'];}}
catch(error){}}}
this._bk(Gv,Hv);this._Vj=new Date().getTime();};_Eh.prototype._bk=function(Lv,Mv,Nv){var pc=Lv/Mv;var Ov=Lv/(new Date().getTime()-this._Uj)*1000;var Pv=(Mv-Lv)/Ov;var Qv={};Qv['loaded']=_fa(Lv);Qv['total']=_fa(Mv);Qv['speed']=_fa(Ov);Qv['timeLeft']=_ga(Pv);Qv['filename']=this._Sj;Qv['pc']=Math.floor(pc*100);if(Nv){this._Od.innerHTML=Nv;this._Od.style.width='';this._Od.style.left='';this._dk();}
else if(Lv==0){this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_preparing'],Qv);this._Od.style.width='100px';var Rv=this._Od.offsetLeft+10*this._Wj;if(this._Wj>0&&Rv+100>this._Kj.offsetWidth-10){Rv=this._Kj.offsetWidth-100;}
if(Rv+100>=this._Kj.offsetWidth){this._Wj=-1;}
if(this._Wj<0&&Rv<10){Rv=0;}
if(Rv<=0){this._Wj=1;}
this._Od.style.left=Rv+'px';}
else if(Lv==Mv){this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_finished'],Qv);this._Pj=false;this._Od.style.width='';this._Od.style.left='';this._Mh();}
else{this._Od.innerHTML=_aa(KTLanguagePack['ktfudc_uploading'],Qv);this._Od.style.width=Math.floor((this._Kj.offsetWidth-10)*pc)+'px';this._Od.style.left='';}
this._Vj=new Date().getTime();};_Eh._Xj='progress';_Eh._pe=200;_Eh._ek=13889;_Eh._Yj=[157,153,165,195,160,198];_Eh._Zj=[156,100];function _fk(Sv){_Ca.call(this,'KTFUF');this._Cd=Sv;this._gk=null;this._Xg=null;this._Yg=null;this._hk=null;this._ik=false;if(Sv){for(var i=0;i<Sv.elements.length;i++){var Tv=Sv.elements[i];if(Tv.type=='file'){this._gk=Tv;_xa(this._gk,'change',this._jk,this);}
else if(Tv.type=='text'){this._Xg=Tv;}
else if(Tv.type=='hidden'){this._Yg=Tv;}
else if(Tv.type=='button'){_xa(Tv,'click',this._kk,this);}
else if(Tv.type=='radio'){if(_ja(Tv,_fk._lk)){_xa(Tv,'click',this._mk,this);_xa(Tv,'focus',this._nk,this);}
else if(_ja(Tv,_fk._ok)){_xa(Tv,'click',this._pk,this);_xa(Tv,'focus',this._qk,this);}}
else if(Tv.type=='submit'){this._hk=Tv;}}
_xa(Sv,'submit',this._rk,this);}
_xa(document,'keydown',this._sk,this);}
_fk.prototype=new _Ca('_inherit');_Ba.push(_fk);_fk.prototype._mk=function(){if(this._gk){this._gk.disabled=null;this._gk.focus();}
if(this._Xg){this._Xg.disabled='disabled';}
this._ik=false;this._Cd.setAttribute('action',KTConfig['file_upload_form_file_submit_url']);};_fk.prototype._nk=function(){if(this._gk){this._gk.focus();}};_fk.prototype._pk=function(){if(this._gk){this._gk.disabled='disabled';}
if(this._Xg){this._Xg.disabled=null;this._Xg.focus();}
this._ik=true;this._Cd.setAttribute('action',KTConfig['file_upload_form_url_submit_url']);};_fk.prototype._qk=function(){if(this._Xg){this._Xg.focus();}};_fk.prototype._jk=function(){if(this._hk){this._hk.click();}};_fk.prototype._rk=function(e){var Uv=null;var Vv=_fk._tk(window['name']);var Wv=false;if(!this._ik){if(this._gk){Uv=this._gk.value;if((Uv==null)||(Uv.trim().length==0)){this._uk(KTLanguagePack['ktfuf_file_error']);_Aa(e);return;}
var Xv=Math.max(Uv.lastIndexOf('/'),Uv.lastIndexOf('\\'));if(Xv>=0){if(Xv==Uv.length-1){this._uk(KTLanguagePack['ktfuf_file_error']);_Aa(e);return;}
else{Uv=Uv.substring(Xv+1);}}}
var Yv='';if(Vv){Yv=Vv._Bh();}
if(Yv.length>0){var Zv=false;for(var i=0;i<Yv.length;i++){if(Uv.toLowerCase().match(new RegExp('[.]'+Yv[i].toLowerCase()+'$','gi'))){Zv=true;break;}}
if(!Zv){var $v='';var aw={};for(var j=0;j<Yv.length;j++){if(!aw[Yv[j].toLowerCase()]){$v+=Yv[j];if(j<Yv.length-1){$v+=', ';}
aw[Yv[j].toLowerCase()]=true;}}
this._uk(_aa(KTLanguagePack['ktfuf_ext_error'],{formats:$v.toLowerCase()}));_Aa(e);return;}}}
else{Wv=true;if(this._Xg){Uv=this._Xg.value;if((Uv==null)||(Uv.trim().length==0)){this._uk(KTLanguagePack['ktfuf_url_error']);_Aa(e);return;}}}
if(Uv){if(this._Yg){this._Yg.value=new _Gb()._Ib(Uv+'_'+new Date().getTime());this._Cd.setAttribute('action',this._Cd.getAttribute('action')+'?filename='+this._Yg.value+'&X-Progress-ID='+this._Yg.value);}
var bw=null;if(FormData&&!Wv){bw=new FormData(this._Cd);_Aa(e);}
if(Vv){Vv._Kh(Uv,this._Yg.value,Wv,bw,this._Cd.getAttribute('action'));}}};_fk.prototype._uk=function(cw){alert(cw);};_fk.prototype._kk=function(){var dw=_fk._tk(window['name']);if(dw){dw._Dh();}};_fk.prototype._sk=function(e){var ew=_va(e);var fw=ew.keyCode;if(fw==27){this._kk();}};_fk._tk=function(gw){if(window.parent&&window.parent['getGlobal']){var hw=window.parent['getGlobal'].call(null,_Ca._Ua);if(hw){return hw.call(null,gw);}}
return null;};_fk._lk='fuf_file';_fk._ok='fuf_url';_fk._vk=[152,156,169,133,153,202,164,149,147,170,211,163,208,145,151,150,204,210,214,162,146,203,159,171,208];function _wk(){_Ca.call(this,'FERHNOITACOLTK');}
_wk.prototype=new _Ca('_inherit');_Ba.push(_wk);function _xk(){_wk.call(this,'_inherit');var iw=[];for(var i=0;i<this._Ia().length;i++){if(this._Ia().charAt(i)=='_'){break;}
else{if(i>this._Ia().length-2){break;}
iw.push(this._Ia().charAt(i));}}
iw.pop();iw.pop();iw=iw.reverse();var a1=iw.slice(0,8);var a2=iw.slice(8,12);stub['_inherit']=this._Da[a1.join('').toLowerCase()][a2.join('').toLowerCase()];}
_xk.prototype=new _wk('_inherit');_Ba.push(_xk);_xk.prototype._yk=function(){if(this._zk){return this._zk;}
var jw=true;var kw=false;var lw=false;var mw=-1;var nw=-1;for(var i=0;i<stub['_inherit'].length;i++){var ow=stub['_inherit'].charCodeAt(i);if(jw){if(ow==_xk._Ak){jw=false;kw=true;}}
else if(kw){if(ow!=_xk._Ak){mw=i;kw=false;lw=true;}}
else if(lw){if(ow==_xk._Ak){nw=i;break;}}}
if(mw!=-1){this._zk=new _Gb()._Ib((nw!=-1?stub['_inherit'].substring(mw,nw):stub['_inherit'].substring(mw))).toArray();return this._zk;}
else{return[];}};_xk._Ak=47;function _Bk(){var pw=this._yk();for(var i=0;i<_Ba.length;i++){for(var qw in _Ba[i]){var rw=_Ba[i][qw];if(rw.reverse){var sw='';var j=0;for(var k=0;k<rw.length;k++){sw+=String.fromCharCode(rw[k]-pw[j]);j++;if(j>=pw.length){j=0;}}
_Ba[i][qw]=sw;}}}}
_Bk.prototype=new _xk('_inherit');_Ba.push(_Bk);function _Ck(){}
_Ck.prototype=new _Bk('_inherit');_Ba.push(_Ck);function _Dk(){_Ca.call(this,'KTAP');}
_Dk.prototype=new _Ca('_inherit');_Ba.push(_Dk);_Dk.prototype._Ek=function(){try{this._Fk();this._Gk();this._Hk();this._Ik();this._Jk();this._Kk();this._Lk();this._Mk();this._Nk();this._Ok();this._Pk();this._Qk();this._Rk();this._Sk();this._Tk();this._Uk();var tw=_la(_Dk._Vk);if(tw){tw.style.display='block';}
this._Wk();this._Xk();}
catch(e){alert('Fatal error occured, please try to refresh the page: '+e.message);throw e;}};_Dk.prototype._Gk=function(){var uw=_ra(_Ie._Rg,null);for(var i=0;i<uw.length;i++){new _Ie(uw[i]);}};_Dk.prototype._Hk=function(){var vw=_ra(_Oh._Ai,null);for(var i=0;i<vw.length;i++){new _Oh(vw[i]);}};_Dk.prototype._Ik=function(){var ww=_ra(_qc._zc,null);for(var i=0;i<ww.length;i++){new _qc(ww[i]);}};_Dk.prototype._Jk=function(){var xw=_ra(_Ac._Gc,null);for(var i=0;i<xw.length;i++){new _Ac(xw[i]);}};_Dk.prototype._Kk=function(){var yw=_ra(_Hc._Kc,null);for(var i=0;i<yw.length;i++){new _Hc(yw[i]);}};_Dk.prototype._Lk=function(){var zw=_ra(_Lc._Rc,null);for(var i=0;i<zw.length;i++){new _Lc(zw[i]);}};_Dk.prototype._Mk=function(){var Aw=_ra(_Sc._Vc,null);for(var i=0;i<Aw.length;i++){new _Sc(Aw[i]);}
Aw=_ra(_Sc._Wc,null);for(i=0;i<Aw.length;i++){new _Sc(Aw[i]);}
Aw=_ra(_Sc._Xc,null);for(i=0;i<Aw.length;i++){new _Sc(Aw[i]);}};_Dk.prototype._Nk=function(){var Bw=_ra(_Yc._Ad,null);for(var i=0;i<Bw.length;i++){new _Yc(Bw[i]);}};_Dk.prototype._Ok=function(){var Cw=_ra(_Bi._Ji,null);for(var i=0;i<Cw.length;i++){new _Bi(Cw[i]);}};_Dk.prototype._Pk=function(){var Dw=_ra(_Ki._ij,null);for(var i=0;i<Dw.length;i++){new _Ki(Dw[i]);}};_Dk.prototype._Qk=function(){var Ew=_ra(_kj._Ij,null);for(var i=0;i<Ew.length;i++){new _kj(Ew[i]);}};_Dk.prototype._Fk=function(){var Fw=_ra(_Bd._Ge,null);var Gw=_sa(_Bd._He,null);for(var i=0;i<Fw.length;i++){var Hw=Fw[i];new _Bd(Hw,Hw==Gw);}
if(Gw){var Iw=document.createElement('INPUT');Iw.type='hidden';Iw.name='screen';Iw.value=screen.width+'x'+screen.height;Gw.appendChild(Iw);}};_Dk.prototype._Rk=function(){var Jw=_sa(_fk._vk,null);if(Jw){new _fk(Jw);}};_Dk.prototype._Wk=function(){var Kw=_la('custom_js');if(Kw){var Lw=this._Pa(Kw);for(var Mw in Lw){var Nw=Lw[Mw];Nw=Nw.replace('call','');if(Nw==''){Nw='()';}
eval(Mw+Nw);}}};_Dk.prototype._Sk=function(){var Ow=document.getElementsByTagName('A');for(var i=0;i<Ow.length;i++){if(Ow[i].rel=='external'){Ow[i].target='_blank';}}};_Dk.prototype._Tk=function(){var Pw=document.getElementsByTagName('TEXTAREA');for(var i=0;i<Pw.length;i++){if(_ja(Pw[i],'html_code_editor')){Pw[i].setAttribute('wrap','off');}}};_Dk.prototype._Uk=function(){var Qw=_ra(_Wa._ab,null);for(var i=0;i<Qw.length;i++){var Rw=this._Pa(Qw[i]);new _Wa(Rw['id'],Rw['confirm']);}};_Dk.prototype._Xk=function(){var Sw=_Ca._Ta('KTDE');if(Sw.length>0){Sw[0]._de();}};_Dk._Vk='content';function prepareAdminPanel(){if(KTConfig['is_https']=='true'){if(window.location.protocol=='http:'){window.location=window.location.href.replace('http://','https://');}}
setTimeout(ge1+ge2+ge3,5);}
function startAdminPanel(){addGlobal(_Ca._Ua,_Ca._Sa);addGlobal(_Ca._Va,_Ca._Ta);var Tw=new _Dk();Tw._Ek();}